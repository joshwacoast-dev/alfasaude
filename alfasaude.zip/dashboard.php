<?php
// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config/database.php';
require_once 'config/auth.php';
verificarLogin();

// ============================================
// 🔐 CHAVE SECRETA (Deve ser a mesma do gerador)
// ============================================
if (!defined('CHAVE_SECRETA_LICENCA')) {
    define('CHAVE_SECRETA_LICENCA', 'ALFA@S4Ud3#2026!Ch@v3Sup3rS3cr3t@');
}

// ============================================
// PROCESSAR ATIVAÇÃO VIA MODAL (AJAX)
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'ativar_serial_dashboard') {
    header('Content-Type: application/json');
    
    $codigo = strtoupper(trim($_POST['codigo_serial'] ?? ''));
    $response = ['sucesso' => false, 'mensagem' => ''];

    // ============================================================
    // 1. VERIFICAÇÃO CRÍTICA: O código já foi usado?
    // ============================================================
    try {
        $stmt_check = $pdo->prepare("SELECT COUNT(*) as total FROM licencas_utilizadas WHERE codigo_licenca = ?");
        $stmt_check->execute([$codigo]);
        
        if ($stmt_check->fetch()['total'] > 0) {
            $response['mensagem'] = "🚫 BLOQUEADO: Este código JÁ FOI UTILIZADO anteriormente!";
            echo json_encode($response);
            exit;
        }
    } catch (Exception $e) {
        // Se a tabela não existir, avisa
        if (strpos($e->getMessage(), 'licencas_utilizadas') !== false) {
             $response['mensagem'] = "Erro de configuração: Tabela de histórico não encontrada.";
             echo json_encode($response);
             exit;
        }
    }

    // Validação Criptográfica (Compatível com o Gerador HTML)
    if (preg_match('/^ALFA-([A-F0-9]{4})-([A-F0-9]{4})-([A-F0-9]{4})-([A-F0-9]{4})$/', $codigo, $matches)) {
        $dados = $matches[1] . $matches[2] . $matches[3];
        $assinatura_calculada = strtoupper(substr(hash_hmac('sha256', $dados, CHAVE_SECRETA_LICENCA), 0, 4));
        
        if (hash_equals($assinatura_calculada, $matches[4])) {
            // Converte Hex para Dias
            $dias_hex = $matches[1];
            $dias_valor = hexdec($dias_hex);
            
            // CORREÇÃO PARA DATAS PASSADAS:
            // Se o valor for maior que 32767, assumimos que é um número negativo (complemento de 2 de 16 bits)
            if ($dias_valor > 32767) {
                $dias_valor = $dias_valor - 65536;
            }

            try {
                $pdo->beginTransaction();
                
                $stmt = $pdo->query("SELECT data_expiracao_licenca, status_licenca FROM clinica WHERE id = 1 LIMIT 1");
                $licenca_atual = $stmt->fetch(PDO::FETCH_ASSOC);
                $hoje = new DateTime();
                
                // Define a data base para cálculo
                $base_data = ($licenca_atual['status_licenca'] === 'bloqueado' || new DateTime() > new DateTime($licenca_atual['data_expiracao_licenca'])) 
                    ? clone $hoje 
                    : new DateTime($licenca_atual['data_expiracao_licenca']);
                
                // Aplica os dias (pode ser negativo se for data passada)
                $base_data->modify(($dias_valor >= 0 ? "+" : "") . "{$dias_valor} days");
                
                // VALIDAÇÃO DE DATA: Se a data resultante for menor que hoje, bloqueia
                if ($base_data < $hoje) {
                     $pdo->rollBack();
                     $response['mensagem'] = "⚠️ Código inválido: A data de validade deste código já expirou.";
                     echo json_encode($response);
                     exit;
                }

                // Atualiza a clínica
                $update = $pdo->prepare("UPDATE clinica SET 
                    data_expiracao_licenca = ?, 
                    status_licenca = 'ativo',
                    dias_licenca = GREATEST(0, dias_licenca + ?)
                WHERE id = 1");
                
                if ($update->execute([$base_data->format('Y-m-d H:i:s'), max(0, $dias_valor)])) {
                    
                    // ============================================================
                    // 2. REGISTRAR O CÓDIGO PARA NUNCA MAIS FUNCIONAR
                    // ============================================================
                    $usuario_id = $_SESSION['usuario_id'] ?? null;
                    $stmt_reg = $pdo->prepare("INSERT INTO licencas_utilizadas 
                        (codigo_licenca, clinica_id, dias_adicionados, data_uso, usuario_responsavel_id) 
                        VALUES (?, 1, ?, NOW(), ?)");
                    $stmt_reg->execute([$codigo, max(0, $dias_valor), $usuario_id]);
                    
                    $pdo->commit();
                    
                    $response['sucesso'] = true;
                    $response['mensagem'] = "✅ Licença ativada! Nova validade: " . $base_data->format('d/m/Y');
                } else {
                    $pdo->rollBack();
                    $response['mensagem'] = "Erro ao atualizar o banco de dados.";
                }
            } catch (Exception $e) {
                $pdo->rollBack();
                // Captura erro de duplicidade caso alguém tente burlar a verificação inicial
                if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
                    $response['mensagem'] = "🚫 BLOQUEADO: Código já registrado como utilizado!";
                } else {
                    $response['mensagem'] = "Erro interno: " . $e->getMessage();
                }
            }
        } else {
            $response['mensagem'] = "Assinatura inválida. Código não gerado por este sistema.";
        }
    } else {
        $response['mensagem'] = "Formato de código inválido.";
    }
    
    echo json_encode($response);
    exit;
}

// ============================================
// DADOS DA LICENÇA PARA EXIBIÇÃO
// ============================================
try {
    $licenca_stmt = $pdo->query("SELECT data_expiracao_licenca, status_licenca FROM clinica WHERE id = 1 LIMIT 1");
    $licenca = $licenca_stmt->fetch(PDO::FETCH_ASSOC);
    
    $hoje = new DateTime();
    $expiracao_licenca = $licenca && !empty($licenca['data_expiracao_licenca']) 
        ? new DateTime($licenca['data_expiracao_licenca']) 
        : new DateTime();
        
    $dias_restantes_licenca = max(0, $hoje->diff($expiracao_licenca)->days);
    $licenca_bloqueada = ($licenca['status_licenca'] === 'bloqueado' || $hoje > $expiracao_licenca);
} catch (Exception $e) {
    $dias_restantes_licenca = 0;
    $licenca_bloqueada = true;
}

// ============================================
// FUNÇÕES AUXILIARES
// ============================================

if (!function_exists('getCoresTema')) {
    function getCoresTema() {
        global $pdo;
        try {
            $stmt = $pdo->query("SELECT cor_primaria, cor_secundaria FROM clinica LIMIT 1");
            $cores = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($cores) {
                return [
                    'primaria' => $cores['cor_primaria'],
                    'secundaria' => $cores['cor_secundaria']
                ];
            }
        } catch (Exception $e) {
            // Ignora erro e usa cores padrão
        }
        return ['primaria' => '#6f42c1', 'secundaria' => '#20c997'];
    }
}

if (!function_exists('getChartData')) {
    function getChartData($pdo, $type, $period) {
        switch($type) {
            case 'sales':
                return [];
            case 'services':
                $stmt = $pdo->prepare("
                    SELECT tipo_consulta, COUNT(*) as total
                    FROM agendamentos
                    WHERE data_hora >= DATE_SUB(NOW(), INTERVAL ? DAY)
                    GROUP BY tipo_consulta
                    ORDER BY total DESC
                ");
                $stmt->execute([$period]);
                return $stmt->fetchAll();
        }
        return [];
    }
}

// ============================================
// DADOS PARA O DASHBOARD
// ============================================

$clinica_stmt = $pdo->query("SELECT nome, logo FROM clinica LIMIT 1");
$clinica = $clinica_stmt->fetch(PDO::FETCH_ASSOC);
$cores = getCoresTema();

try {
    // Estatísticas principais (Adicionado contagem da Fila de Chamadas)
    $stats = $pdo->query("
        SELECT
            (SELECT COUNT(*) FROM pacientes WHERE ativo = 1) as total_pacientes,
            (SELECT COUNT(*) FROM agendamentos WHERE DATE(data_hora) = CURDATE() AND status IN ('agendado','confirmado')) as agendamentos_hoje,
            (SELECT COUNT(*) FROM agendamentos WHERE DATE(data_hora) = CURDATE() AND status = 'concluido') as atendimentos_hoje,
            (SELECT COUNT(*) FROM agendamentos WHERE MONTH(data_hora) = MONTH(CURDATE()) AND YEAR(data_hora) = YEAR(CURDATE())) as agendamentos_mes,
            (SELECT COUNT(*) FROM usuarios WHERE ativo = 1) as total_usuarios,
            (SELECT COUNT(*) FROM fila_chamadas WHERE status IN ('aguardando', 'chamando')) as fila_espera
    ")->fetch();

    // Próximos agendamentos
    $agendamentos = $pdo->prepare("
        SELECT a.*, p.nome as paciente_nome, p.telefone, u.nome as medico_nome
        FROM agendamentos a
        JOIN pacientes p ON a.paciente_id = p.id
        JOIN usuarios u ON a.usuario_id = u.id
        WHERE DATE(a.data_hora) >= CURDATE()
        AND a.status IN ('agendado','confirmado')
        ORDER BY a.data_hora ASC
        LIMIT 8
    ");
    $agendamentos->execute();
    $proximos_agendamentos = $agendamentos->fetchAll();

    // Últimos pacientes cadastrados
    $ultimos_pacientes = $pdo->query("
        SELECT * FROM pacientes
        WHERE ativo = 1
        ORDER BY data_cadastro DESC
        LIMIT 5
    ")->fetchAll();

    // Dados para gráficos
    $servicos_grafico = getChartData($pdo, 'services', 30);
    $labels_servicos = [];
    $dados_servicos = [];
    foreach ($servicos_grafico as $s) {
        $labels_servicos[] = ucfirst($s['tipo_consulta']);
        $dados_servicos[] = $s['total'];
    }

    // Se não houver dados, usar valores genéricos
    if (empty($labels_servicos)) {
        $labels_servicos = ['Consulta', 'Retorno', 'Exame', 'Procedimento'];
        $dados_servicos = [0, 0, 0, 0];
    }

} catch (PDOException $e) {
    // Em caso de erro, definir dados vazios
    $stats = [
        'total_pacientes' => 0,
        'agendamentos_hoje' => 0,
        'atendimentos_hoje' => 0,
        'agendamentos_mes' => 0,
        'total_usuarios' => 0,
        'fila_espera' => 0
    ];
    $proximos_agendamentos = [];
    $ultimos_pacientes = [];
    $labels_servicos = ['Consulta', 'Retorno', 'Exame', 'Procedimento'];
    $dados_servicos = [0, 0, 0, 0];
}

// Dados do usuário logado (da sessão)
$usuario_nome = $_SESSION['usuario_nome'] ?? 'Usuário';
$usuario_tipo = $_SESSION['usuario_tipo'] ?? 'usuario';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | <?php echo htmlspecialchars($clinica['nome'] ?? 'Alfa Saúde'); ?></title>
    <!-- Font Awesome, Google Fonts, Chart.js -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* ===== VARIÁVEIS GLOBAIS ===== */
        :root {
            --primary: <?php echo $cores['primaria']; ?>;
            --primary-light: <?php echo $cores['primaria']; ?>dd;
            --primary-dark: <?php echo $cores['primaria']; ?>aa;
            --secondary: <?php echo $cores['secundaria']; ?>;
            --secondary-light: <?php echo $cores['secundaria']; ?>dd;
            --danger: #ff4757;
            --warning: #ff9f43;
            --info: #2e86de;
            --light: #f8f9fa;
            --dark: #343a40;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --border-radius: 12px;
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 8px 30px rgba(0, 0, 0, 0.12);
            --transition: all 0.3s ease;
            --sidebar-width: 280px;
            --topbar-height: 80px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fb 0%, #eef2f7 100%);
            color: var(--dark);
            line-height: 1.6;
            min-height: 100vh;
            overflow-x: hidden;
        }

        body.dark-theme {
            --light: #1a1d23;
            --dark: #f8f9fa;
            --gray: #adb5bd;
            --light-gray: #2d3239;
            background: linear-gradient(135deg, #121416 0%, #1a1d23 100%);
            color: #f8f9fa;
        }

        /* ===== LAYOUT PRINCIPAL ===== */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
            position: relative;
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            z-index: 1000;
            transition: var(--transition);
            box-shadow: 3px 0 20px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
        }

        .dark-theme .sidebar {
            box-shadow: 3px 0 20px rgba(0, 0, 0, 0.3);
        }

        .sidebar-header {
            padding: 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.15);
            background: rgba(255, 255, 255, 0.05);
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-icon {
            width: 45px;
            height: 45px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            flex-shrink: 0;
        }

        .logo-icon i {
            font-size: 22px;
        }

        .logo-text h2 {
            font-size: 18px;
            font-weight: 700;
            margin: 0;
            letter-spacing: 0.5px;
            line-height: 1.2;
        }

        .logo-text p {
            font-size: 12px;
            opacity: 0.9;
            margin: 3px 0 0 0;
            font-weight: 300;
        }

        .sidebar-menu {
            flex: 1;
            padding: 25px 0;
            overflow-y: auto;
        }

        .menu-section {
            margin-bottom: 25px;
            padding: 0 25px;
        }

        .menu-section h3 {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            opacity: 0.7;
            margin-bottom: 15px;
            font-weight: 600;
        }

        .menu-section ul {
            list-style: none;
        }

        .menu-section li {
            margin-bottom: 5px;
        }

        .menu-section a {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 15px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            border-radius: 8px;
            transition: var(--transition);
            position: relative;
            font-weight: 500;
            font-size: 14px;
        }

        .menu-section a:hover,
        .menu-section a.active {
            background: rgba(255, 255, 255, 0.12);
            color: white;
        }

        .menu-section a.active {
            background: rgba(255, 255, 255, 0.18);
            font-weight: 600;
        }

        .menu-section a.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 4px;
            height: 60%;
            background: var(--secondary);
            border-radius: 0 4px 4px 0;
        }

        .menu-section a i {
            font-size: 16px;
            width: 20px;
            text-align: center;
        }

        .menu-badge {
            margin-left: auto;
            background: var(--secondary);
            color: white;
            font-size: 11px;
            padding: 3px 8px;
            border-radius: 10px;
            font-weight: 600;
            min-width: 20px;
            text-align: center;
        }

        .menu-badge.new {
            background: var(--danger);
        }

        .menu-badge.alert {
            background: var(--warning);
        }

        .user-profile {
            padding: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.15);
            display: flex;
            align-items: center;
            gap: 15px;
            background: rgba(255, 255, 255, 0.05);
            position: sticky;
            bottom: 0;
        }

        .user-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            overflow: hidden;
            background: linear-gradient(135deg, var(--primary-light), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            flex-shrink: 0;
        }

        .avatar-placeholder {
            font-size: 16px;
            font-weight: 700;
            color: white;
        }

        .online-status {
            position: absolute;
            bottom: 3px;
            right: 3px;
            width: 12px;
            height: 12px;
            background: var(--secondary);
            border-radius: 50%;
            border: 2px solid var(--primary-dark);
        }

        .user-info {
            flex: 1;
            min-width: 0;
        }

        .user-info h4 {
            font-size: 14px;
            font-weight: 600;
            margin: 0 0 4px 0;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .user-info p {
            font-size: 12px;
            opacity: 0.9;
            margin: 0;
            font-weight: 400;
        }

        .user-actions a {
            color: rgba(255, 255, 255, 0.8);
            font-size: 16px;
            transition: var(--transition);
            padding: 8px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .user-actions a:hover {
            background: rgba(255, 255, 255, 0.15);
            color: white;
        }

        /* ===== CONTEÚDO PRINCIPAL ===== */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            transition: var(--transition);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        @media (max-width: 1199px) {
            .main-content {
                margin-left: 0;
            }
        }

        /* ===== TOP BAR ===== */
        .top-bar {
            background: white;
            padding: 15px 25px;
            box-shadow: var(--shadow);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 900;
            gap: 15px;
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95);
            flex-wrap: wrap;
            min-height: var(--topbar-height);
        }

        .dark-theme .top-bar {
            background: rgba(26, 29, 35, 0.95);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        }

        .top-bar-left {
            display: flex;
            align-items: center;
            gap: 15px;
            flex: 1;
            min-width: 0;
        }

        .sidebar-toggle {
            display: none;
            background: var(--primary);
            border: none;
            color: white;
            font-size: 18px;
            cursor: pointer;
            padding: 10px;
            border-radius: 8px;
            transition: var(--transition);
            flex-shrink: 0;
            width: 40px;
            height: 40px;
            align-items: center;
            justify-content: center;
        }

        .sidebar-toggle:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }

        .search-bar {
            flex: 1;
            min-width: 200px;
            max-width: 500px;
            position: relative;
        }

        .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            font-size: 14px;
            z-index: 1;
        }

        .search-bar input {
            width: 100%;
            padding: 12px 15px 12px 40px;
            border: 2px solid var(--light-gray);
            border-radius: var(--border-radius);
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            transition: var(--transition);
            background: white;
            color: var(--dark);
        }

        .dark-theme .search-bar input {
            background: var(--light);
            border-color: #3d4249;
            color: var(--dark);
        }

        .search-bar input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(111, 66, 193, 0.15);
        }

        .top-bar-right {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .notification-btn,
        .message-btn {
            position: relative;
            background: var(--light);
            border: none;
            font-size: 16px;
            color: var(--gray);
            cursor: pointer;
            padding: 10px;
            border-radius: 8px;
            transition: var(--transition);
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .dark-theme .notification-btn,
        .dark-theme .message-btn {
            background: #2d3239;
        }

        .notification-btn:hover,
        .message-btn:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-2px);
        }

        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            font-size: 10px;
            font-weight: 700;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid white;
        }

        .dark-theme .notification-badge {
            border-color: #1a1d23;
        }

        .theme-toggle {
            background: var(--light);
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
            font-size: 16px;
            color: var(--gray);
        }

        .dark-theme .theme-toggle {
            background: #2d3239;
        }

        .theme-toggle:hover {
            background: var(--primary);
            color: white;
            transform: rotate(30deg);
        }

        .quick-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .quick-action-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: none;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
            font-size: 16px;
            text-decoration: none;
        }

        .quick-action-btn:hover {
            transform: translateY(-3px) scale(1.1);
            box-shadow: 0 6px 20px rgba(111, 66, 193, 0.4);
        }

        /* ===== CONTEÚDO DO DASHBOARD ===== */
        .dashboard-content {
            padding: 25px;
            flex: 1;
            overflow-y: auto;
        }

        /* ===== ALERTA DE LICENÇA (NOVO) ===== */
        .alert-licenca { 
            margin-bottom: 25px; 
            display: flex; 
            align-items: center; 
            justify-content: space-between; 
            padding: 15px 20px; 
            border-radius: var(--border-radius); 
            border: 1px solid; 
            animation: slideDownLicenca 0.4s ease; 
        }
        .alert-licenca.warning { 
            background: rgba(255, 159, 67, 0.1); 
            color: #856404; 
            border-color: rgba(255, 159, 67, 0.3); 
        }
        .alert-licenca.danger { 
            background: rgba(255, 71, 87, 0.1); 
            color: #842029; 
            border-color: rgba(255, 71, 87, 0.3); 
        }
        .alert-licenca .alert-content { 
            display: flex; 
            align-items: center; 
            gap: 12px; 
        }
        .alert-licenca .alert-content i { 
            font-size: 22px; 
        }
        .alert-licenca strong { 
            display: block; 
            font-size: 14px; 
            margin-bottom: 2px; 
        }
        .alert-licenca span { 
            font-size: 13px; 
        }
        @keyframes slideDownLicenca { 
            from { opacity: 0; transform: translateY(-10px); } 
            to { opacity: 1; transform: translateY(0); } 
        }

        /* ===== SEÇÃO DE BOAS-VINDAS ===== */
        .welcome-section {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            border-radius: var(--border-radius);
            padding: 30px;
            color: white;
            margin-bottom: 25px;
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-lg);
        }

        .dark-theme .welcome-section {
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
        }

        .welcome-content {
            position: relative;
            z-index: 1;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
            gap: 20px;
        }

        .welcome-text {
            flex: 1;
            min-width: 300px;
        }

        .welcome-text h1 {
            font-size: 28px;
            font-weight: 800;
            margin-bottom: 10px;
            line-height: 1.2;
        }

        .welcome-text .highlight {
            color: var(--secondary);
        }

        .welcome-text p {
            font-size: 16px;
            opacity: 0.95;
            margin-bottom: 20px;
        }

        .welcome-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }

        .welcome-stat {
            text-align: center;
            padding: 15px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            backdrop-filter: blur(10px);
        }

        .welcome-stat .number {
            display: block;
            font-size: 24px;
            font-weight: 800;
            color: white;
            margin-bottom: 5px;
        }

        .welcome-stat .label {
            font-size: 12px;
            opacity: 0.9;
            font-weight: 500;
        }

        .welcome-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
            text-decoration: none;
            white-space: nowrap;
        }

        .btn-primary {
            background: white;
            color: var(--primary);
        }

        .btn-primary:hover {
            background: var(--light);
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(255, 255, 255, 0.2);
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }
        
        .btn-chamadas {
            background: var(--secondary);
            color: white;
            box-shadow: 0 4px 15px rgba(32, 201, 151, 0.4);
        }
        .btn-chamadas:hover {
            background: #1baa80;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(32, 201, 151, 0.6);
        }

        .btn-warning {
            background: var(--warning);
            color: white;
        }
        .btn-warning:hover {
            background: #e68a00;
            transform: translateY(-2px);
        }
        .btn-danger {
            background: var(--danger);
            color: white;
        }
        .btn-danger:hover {
            background: #e04050;
            transform: translateY(-2px);
        }

        /* ===== ESTATÍSTICAS ===== */
        .statistics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 25px;
            box-shadow: var(--shadow);
            display: flex;
            align-items: center;
            gap: 20px;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }

        .dark-theme .stat-card {
            background: #1a1d23;
            border-color: #2d3239;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            width: 5px;
            height: 100%;
        }

        .stat-card.pacientes::before { background: linear-gradient(to bottom, var(--primary), var(--primary-light)); }
        .stat-card.agendamentos::before { background: linear-gradient(to bottom, var(--secondary), var(--secondary-light)); }
        .stat-card.atendimentos::before { background: linear-gradient(to bottom, var(--info), #4d9ce8); }
        .stat-card.usuarios::before { background: linear-gradient(to bottom, var(--warning), #ffb15c); }
        .stat-card.fila::before { background: linear-gradient(to bottom, #fd79a8, #e84393); }
        
        /* Estilos para o card de licença */
        .stat-card.licenca::before { background: linear-gradient(to bottom, #6c757d, #adb5bd); }
        .stat-card.licenca.ok::before { background: linear-gradient(to bottom, var(--secondary), var(--secondary-light)); }
        .stat-card.licenca.alerta::before { background: linear-gradient(to bottom, var(--warning), #ffb15c); }
        .stat-card.licenca.bloqueada::before { background: linear-gradient(to bottom, var(--danger), #ff6b81); }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
            flex-shrink: 0;
        }

        .stat-card.pacientes .stat-icon { background: linear-gradient(135deg, var(--primary), var(--primary-light)); }
        .stat-card.agendamentos .stat-icon { background: linear-gradient(135deg, var(--secondary), var(--secondary-light)); }
        .stat-card.atendimentos .stat-icon { background: linear-gradient(135deg, var(--info), #4d9ce8); }
        .stat-card.usuarios .stat-icon { background: linear-gradient(135deg, var(--warning), #ffb15c); }
        .stat-card.fila .stat-icon { background: linear-gradient(135deg, #fd79a8, #e84393); }
        
        .stat-card.licenca .stat-icon { background: linear-gradient(135deg, #6c757d, #adb5bd); }
        .stat-card.licenca.ok .stat-icon { background: linear-gradient(135deg, var(--secondary), var(--secondary-light)); }
        .stat-card.licenca.alerta .stat-icon { background: linear-gradient(135deg, var(--warning), #ffb15c); }
        .stat-card.licenca.bloqueada .stat-icon { background: linear-gradient(135deg, var(--danger), #ff6b81); }

        .stat-info {
            flex: 1;
            min-width: 0;
        }

        .stat-info h3 {
            font-size: 13px;
            color: var(--gray);
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 8px;
            font-weight: 600;
        }

        .stat-value {
            font-size: 28px;
            font-weight: 800;
            color: var(--dark);
            margin-bottom: 5px;
            line-height: 1.2;
        }

        .dark-theme .stat-value {
            color: #f8f9fa;
        }

        .stat-detail {
            font-size: 13px;
            color: var(--gray);
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .stat-action-link {
            margin-top: 8px;
            display: block;
            font-size: 12px;
            font-weight: 600;
            color: var(--primary);
            text-decoration: none;
            transition: 0.2s;
        }
        .stat-action-link:hover {
            text-decoration: underline;
        }

        /* ===== GRÁFICOS ===== */
        .charts-section {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }

        @media (min-width: 1200px) {
            .charts-section {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        .chart-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 25px;
            display: flex;
            flex-direction: column;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }

        .dark-theme .chart-card {
            background: #1a1d23;
            border-color: #2d3239;
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .chart-header h3 {
            font-size: 18px;
            font-weight: 700;
            color: var(--dark);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .dark-theme .chart-header h3 {
            color: #f8f9fa;
        }

        .chart-header h3 i {
            color: var(--primary);
        }

        .chart-select {
            padding: 8px 15px;
            border: 2px solid var(--light-gray);
            border-radius: var(--border-radius);
            background: white;
            color: var(--dark);
            font-family: 'Poppins', sans-serif;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
        }

        .dark-theme .chart-select {
            background: #2d3239;
            border-color: #3d4249;
            color: #f8f9fa;
        }

        .chart-select:focus {
            outline: none;
            border-color: var(--primary);
        }

        .chart-container {
            position: relative;
            height: 250px;
            width: 100%;
            flex: 1;
        }

        /* ===== TABELAS ===== */
        .tables-section {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }

        @media (min-width: 1200px) {
            .tables-section {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        .table-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }

        .dark-theme .table-card {
            background: #1a1d23;
            border-color: #2d3239;
        }

        .table-header {
            padding: 20px;
            border-bottom: 1px solid var(--light-gray);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .dark-theme .table-header {
            border-bottom-color: #2d3239;
            background: rgba(45, 50, 57, 0.5);
        }

        .table-header h3 {
            font-size: 18px;
            font-weight: 700;
            color: var(--dark);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .dark-theme .table-header h3 {
            color: #f8f9fa;
        }

        .table-header h3 i {
            color: var(--primary);
        }

        .view-all {
            color: var(--primary);
            text-decoration: none;
            font-size: 13px;
            font-weight: 600;
            padding: 6px 12px;
            border-radius: 6px;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .view-all:hover {
            background: var(--light);
            transform: translateX(3px);
        }

        .dark-theme .view-all:hover {
            background: #2d3239;
        }

        .table-container {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .data-table {
            width: 100%;
            min-width: 600px;
            border-collapse: collapse;
        }

        .data-table th {
            padding: 15px 20px;
            text-align: left;
            font-weight: 600;
            color: var(--gray);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-bottom: 2px solid var(--light-gray);
            white-space: nowrap;
            background: #f8f9fa;
        }

        .dark-theme .data-table th {
            background: #2d3239;
            border-bottom-color: #3d4249;
        }

        .data-table td {
            padding: 15px 20px;
            border-bottom: 1px solid var(--light-gray);
            color: var(--dark);
            font-size: 13px;
            vertical-align: middle;
        }

        .dark-theme .data-table td {
            color: #f8f9fa;
            border-bottom-color: #2d3239;
        }

        .data-table tbody tr:hover {
            background: rgba(111, 66, 193, 0.02);
        }

        .dark-theme .data-table tbody tr:hover {
            background: rgba(111, 66, 193, 0.05);
        }

        .patient-cell {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .patient-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 14px;
            flex-shrink: 0;
        }

        .patient-info {
            min-width: 0;
        }

        .patient-info strong {
            font-weight: 600;
            font-size: 14px;
            display: block;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .patient-info small {
            font-size: 12px;
            color: var(--gray);
        }

        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }

        .status-agendado, .status-pending {
            background: rgba(255, 159, 67, 0.15);
            color: var(--warning);
        }

        .status-confirmado {
            background: rgba(46, 134, 222, 0.15);
            color: var(--info);
        }

        .status-em_andamento {
            background: rgba(32, 201, 151, 0.15);
            color: var(--secondary);
        }

        .status-concluido {
            background: rgba(32, 201, 151, 0.15);
            color: var(--secondary);
        }

        .status-cancelado {
            background: rgba(255, 71, 87, 0.15);
            color: var(--danger);
        }

        /* ===== RODAPÉ ===== */
        .main-footer {
            background: white;
            padding: 15px 25px;
            border-top: 1px solid var(--light-gray);
            text-align: center;
            font-size: 13px;
            color: var(--gray);
        }

        .dark-theme .main-footer {
            background: #1a1d23;
            border-top-color: #2d3239;
        }

        .footer-content {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .footer-content a {
            color: var(--primary);
            text-decoration: none;
        }

        /* ===== MODAL DE LICENÇA (NOVO) ===== */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(4px);
            z-index: 2000;
            align-items: center;
            justify-content: center;
            animation: fadeInModal 0.3s ease;
        }
        .modal-overlay.active {
            display: flex;
        }
        .modal-box {
            background: white;
            width: 90%;
            max-width: 450px;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            animation: slideUpModal 0.3s ease;
        }
        .dark-theme .modal-box {
            background: #1a1d23;
            border: 1px solid #2d3239;
        }
        .modal-header {
            padding: 20px 25px;
            border-bottom: 1px solid var(--light-gray);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .dark-theme .modal-header {
            border-bottom-color: #2d3239;
        }
        .modal-header h3 {
            font-size: 18px;
            font-weight: 700;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 0;
        }
        .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            color: var(--gray);
            cursor: pointer;
            transition: 0.2s;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }
        .modal-close:hover {
            background: var(--light-gray);
            color: var(--danger);
        }
        .modal-body {
            padding: 25px;
        }
        .modal-body p {
            color: var(--gray);
            font-size: 14px;
            margin-bottom: 20px;
            line-height: 1.5;
        }
        .modal-input {
            width: 100%;
            padding: 15px;
            border: 2px solid var(--light-gray);
            border-radius: 8px;
            font-size: 18px;
            font-weight: 700;
            text-align: center;
            letter-spacing: 2px;
            font-family: 'Courier New', monospace;
            text-transform: uppercase;
            margin-bottom: 15px;
            transition: 0.3s;
        }
        .dark-theme .modal-input {
            background: #2d3239;
            border-color: #3d4249;
            color: #f8f9fa;
        }
        .modal-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(111, 66, 193, 0.15);
        }
        .modal-message {
            margin-top: 15px;
            padding: 12px;
            border-radius: 8px;
            font-size: 13px;
            display: none;
            text-align: center;
        }
        .modal-message.success {
            background: rgba(32, 201, 151, 0.15);
            color: #0f5132;
            display: block;
        }
        .modal-message.error {
            background: rgba(255, 71, 87, 0.15);
            color: #842029;
            display: block;
        }
        @keyframes fadeInModal {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideUpModal {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* ===== RESPONSIVIDADE ===== */
        @media (max-width: 1199px) {
            .sidebar {
                transform: translateX(-100%);
                width: 300px;
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .sidebar-toggle {
                display: flex;
            }
            .sidebar-overlay.active {
                display: block;
            }
        }

        @media (max-width: 992px) {
            .dashboard-content { padding: 20px; }
            .statistics-grid { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 768px) {
            .statistics-grid { grid-template-columns: 1fr; }
            .alert-licenca { 
                flex-direction: column; 
                align-items: flex-start; 
                gap: 15px; 
            }
            .alert-licenca .btn { 
                width: 100%; 
                justify-content: center; 
            }
        }

        /* Overlay do sidebar */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 999;
        }

        /* Preloader */
        .preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            transition: opacity 0.5s;
        }
        .dark-theme .preloader {
            background: #1a1d23;
        }
        .loader {
            text-align: center;
        }
        .loader i {
            font-size: 50px;
            color: var(--primary);
            margin-bottom: 20px;
            animation: bounce 1.5s infinite;
        }
        @keyframes bounce {
            0%,100%{transform:translateY(0);}
            50%{transform:translateY(-15px);}
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader" id="preloader">
        <div class="loader">
            <i class="fas fa-stethoscope"></i>
            <div>Carregando...</div>
        </div>
    </div>

    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="fas fa-stethoscope"></i>
                    </div>
                    <div class="logo-text">
                        <h2><?php echo htmlspecialchars($clinica['nome'] ?? 'Alfa Saúde'); ?></h2>
                        <p>Gestão Clínica</p>
                    </div>
                </div>
            </div>

            <div class="sidebar-menu">
                <div class="menu-section">
                    <h3>Menu Principal</h3>
                    <ul>
                        <li><a href="dashboard.php" class="active"><i class="fas fa-home"></i> Dashboard</a></li>
                        <li><a href="agendamentos.php"><i class="fas fa-calendar-alt"></i> Agenda</a></li>
                        <li><a href="pacientes.php"><i class="fas fa-user-injured"></i> Pacientes</a></li>
                        <li><a href="usuarios.php"><i class="fas fa-user-md"></i> Usuários</a></li>
                    </ul>
                </div>
                <div class="menu-section">
                    <h3>Atendimento</h3>
                    <ul>
                        <li><a href="prontuarios.php"><i class="fas fa-notes-medical"></i> Prontuários</a></li>
                        <li><a href="receituarios.php"><i class="fas fa-prescription"></i> Receituários</a></li>
                        <li><a href="declaracoes.php"><i class="fas fa-file-medical"></i> Declarações</a></li>
                    </ul>
                </div>
                <?php if ($usuario_tipo === 'admin'): ?>
                <div class="menu-section">
                    <h3>Administração</h3>
                    <ul>
                        <li><a href="clinica.php"><i class="fas fa-hospital"></i> Clínica</a></li>
                        <li><a href="licenca.php"><i class="fas fa-cogs"></i> Gerenciar Licenças</a></li>
                        <li><a href="relatorios.php"><i class="fas fa-chart-line"></i> Relatórios</a></li>
                    </ul>
                </div>
                <?php endif; ?>
            </div>

            <div class="user-profile">
                <div class="user-avatar">
                    <div class="avatar-placeholder"><?php echo strtoupper(substr($usuario_nome, 0, 2)); ?></div>
                    <div class="online-status"></div>
                </div>
                <div class="user-info">
                    <h4><?php echo htmlspecialchars($usuario_nome); ?></h4>
                    <p><?php echo ucfirst($usuario_tipo); ?></p>
                </div>
                <div class="user-actions">
                    <a href="logout.php" title="Sair"><i class="fas fa-sign-out-alt"></i></a>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <header class="top-bar">
                <div class="top-bar-left">
                    <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <div class="search-bar">
                        <i class="fas fa-search"></i>
                        <input type="text" id="searchInput" placeholder="Pesquisar...">
                    </div>
                </div>
                <div class="top-bar-right">
                    <button class="notification-btn"><i class="fas fa-bell"></i><span class="notification-badge"><?php echo $stats['agendamentos_hoje'] ?? 0; ?></span></button>
                    <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
                    <div class="quick-actions">
                        <a href="pacientes/novo.php" class="quick-action-btn" title="Novo Paciente"><i class="fas fa-user-plus"></i></a>
                        <a href="agendamentos/novo.php" class="quick-action-btn" title="Novo Agendamento"><i class="fas fa-calendar-plus"></i></a>
                    </div>
                </div>
            </header>

            <!-- Dashboard Content -->
            <div class="dashboard-content">
                
                <!-- ALERTA DE LICENÇA (Só aparece se <= 7 dias ou bloqueada) -->
                <?php if ($licenca_bloqueada || $dias_restantes_licenca <= 7): ?>
                <div class="alert-licenca <?php echo $licenca_bloqueada ? 'danger' : 'warning'; ?>">
                    <div class="alert-content">
                        <i class="fas fa-<?php echo $licenca_bloqueada ? 'lock' : 'exclamation-triangle'; ?>"></i>
                        <div>
                            <strong><?php echo $licenca_bloqueada ? 'Sistema Bloqueado' : 'Atenção: Licença próxima do vencimento'; ?></strong>
                            <span>
                                <?php if ($licenca_bloqueada): ?>
                                    Sua licença expirou em <?php echo $expiracao_licenca->format('d/m/Y'); ?>. Insira um novo serial para reativar o sistema.
                                <?php else: ?>
                                    Sua licença expira em <?php echo $expiracao_licenca->format('d/m/Y'); ?> (<?php echo $dias_restantes_licenca; ?> dias restantes).
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                    <button type="button" onclick="abrirModalSerial()" class="btn <?php echo $licenca_bloqueada ? 'btn-danger' : 'btn-warning'; ?>">
                        <i class="fas fa-key"></i> Inserir Serial
                    </button>
                </div>
                <?php endif; ?>

                <!-- Welcome Section -->
                <div class="welcome-section">
                    <div class="welcome-content">
                        <div class="welcome-text">
                            <h1>Olá, <span class="highlight"><?php echo explode(' ', $usuario_nome)[0]; ?></span>! 👋</h1>
                            <p>Bem-vindo ao painel da <?php echo htmlspecialchars($clinica['nome'] ?? 'Alfa Saúde'); ?></p>
                            <div class="welcome-stats">
                                <div class="welcome-stat">
                                    <span class="number"><?php echo $stats['agendamentos_hoje'] ?? 0; ?></span>
                                    <span class="label">Agendamentos Hoje</span>
                                </div>
                                <div class="welcome-stat">
                                    <span class="number"><?php echo $stats['total_pacientes'] ?? 0; ?></span>
                                    <span class="label">Pacientes</span>
                                </div>
                                <div class="welcome-stat">
                                    <span class="number"><?php echo $stats['agendamentos_mes'] ?? 0; ?></span>
                                    <span class="label">Consultas no Mês</span>
                                </div>
                            </div>
                        </div>
                        <div class="welcome-actions">
                            <a href="agendamentos/novo.php" class="btn btn-primary"><i class="fas fa-plus"></i> Novo Agendamento</a>
                            <a href="chamados.php" class="btn btn-chamadas"><i class="fas fa-bullhorn"></i> Iniciar Chamadas</a>
                            <button type="button" onclick="abrirModalSerial()" class="btn btn-secondary"><i class="fas fa-key"></i> Ativar Licença</button>
                        </div>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="statistics-grid">
                    <div class="stat-card pacientes">
                        <div class="stat-icon"><i class="fas fa-user-injured"></i></div>
                        <div class="stat-info">
                            <h3>Pacientes</h3>
                            <p class="stat-value"><?php echo $stats['total_pacientes'] ?? 0; ?></p>
                            <div class="stat-detail">
                                <span>Ativos no sistema</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- NOVO CARD: FILA DE ESPERA -->
                    <div class="stat-card fila">
                        <div class="stat-icon"><i class="fas fa-users-waiting"></i></div>
                        <div class="stat-info">
                            <h3>Fila de Espera</h3>
                            <p class="stat-value"><?php echo $stats['fila_espera'] ?? 0; ?></p>
                            <div class="stat-detail">
                                <span>Aguardando atendimento</span>
                            </div>
                            <a href="chamados.php" class="stat-action-link"><i class="fas fa-arrow-right"></i> Gerenciar Chamadas</a>
                        </div>
                    </div>

                    <div class="stat-card agendamentos">
                        <div class="stat-icon"><i class="fas fa-calendar-check"></i></div>
                        <div class="stat-info">
                            <h3>Agendamentos Hoje</h3>
                            <p class="stat-value"><?php echo $stats['agendamentos_hoje'] ?? 0; ?></p>
                            <div class="stat-detail">
                                <span><?php echo $stats['agendamentos_mes'] ?? 0; ?> no mês</span>
                            </div>
                        </div>
                    </div>
                    <div class="stat-card atendimentos">
                        <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                        <div class="stat-info">
                            <h3>Atendimentos Hoje</h3>
                            <p class="stat-value"><?php echo $stats['atendimentos_hoje'] ?? 0; ?></p>
                            <div class="stat-detail">
                                <span>Concluídos</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- CARD DE LICENÇA -->
                    <div class="stat-card licenca <?php echo $licenca_bloqueada ? 'bloqueada' : ($dias_restantes_licenca <= 7 ? 'alerta' : 'ok'); ?>">
                        <div class="stat-icon"><i class="fas fa-shield-alt"></i></div>
                        <div class="stat-info">
                            <h3>Licença</h3>
                            <p class="stat-value"><?php echo $licenca_bloqueada ? '0' : $dias_restantes_licenca; ?> <span style="font-size: 14px; font-weight: 500;">dias</span></p>
                            <div class="stat-detail">
                                <span>Expira em: <?php echo $expiracao_licenca->format('d/m/Y'); ?></span>
                            </div>
                            <div style="margin-top: 10px;">
                                <button type="button" onclick="abrirModalSerial()" style="font-size: 12px; color: var(--primary); font-weight: 600; text-decoration: none; display: inline-flex; align-items: center; gap: 5px; background: none; border: none; cursor: pointer; padding: 0;">
                                    <i class="fas fa-key"></i> Renovar Serial
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Charts Section -->
                <div class="charts-section">
                    <div class="chart-card">
                        <div class="chart-header">
                            <h3><i class="fas fa-chart-pie"></i> Tipos de Consulta (30 dias)</h3>
                        </div>
                        <div class="chart-container">
                            <canvas id="servicesChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Tables Section -->
                <div class="tables-section">
                    <div class="table-card">
                        <div class="table-header">
                            <h3><i class="fas fa-calendar-alt"></i> Próximos Agendamentos</h3>
                            <a href="agendamentos.php" class="view-all">Ver todos</a>
                        </div>
                        <div class="table-container">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Paciente</th>
                                        <th>Médico</th>
                                        <th>Data/Hora</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (count($proximos_agendamentos) > 0): ?>
                                        <?php foreach ($proximos_agendamentos as $a): ?>
                                        <tr>
                                            <td>
                                                <div class="patient-cell">
                                                    <div class="patient-avatar"><?php echo strtoupper(substr($a['paciente_nome'],0,2)); ?></div>
                                                    <div class="patient-info">
                                                        <strong><?php echo htmlspecialchars($a['paciente_nome']); ?></strong>
                                                        <small><?php echo htmlspecialchars($a['telefone']); ?></small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?php echo htmlspecialchars($a['medico_nome']); ?></td>
                                            <td><?php echo date('d/m/Y H:i', strtotime($a['data_hora'])); ?></td>
                                            <td><span class="status-badge status-<?php echo $a['status']; ?>"><?php echo ucfirst($a['status']); ?></span></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr><td colspan="4" style="text-align:center;">Nenhum agendamento próximo.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="table-card">
                        <div class="table-header">
                            <h3><i class="fas fa-user-plus"></i> Últimos Pacientes</h3>
                            <a href="pacientes.php" class="view-all">Ver todos</a>
                        </div>
                        <div class="table-container">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Nome</th>
                                        <th>Telefone</th>
                                        <th>Cadastro</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (count($ultimos_pacientes) > 0): ?>
                                        <?php foreach ($ultimos_pacientes as $p): ?>
                                        <tr>
                                            <td>
                                                <div class="patient-cell">
                                                    <div class="patient-avatar"><?php echo strtoupper(substr($p['nome'],0,2)); ?></div>
                                                    <div class="patient-info">
                                                        <strong><?php echo htmlspecialchars($p['nome']); ?></strong>
                                                        <?php if ($p['email']): ?><small><?php echo $p['email']; ?></small><?php endif; ?>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?php echo htmlspecialchars($p['telefone']); ?></td>
                                            <td><?php echo date('d/m/Y', strtotime($p['data_cadastro'])); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr><td colspan="3" style="text-align:center;">Nenhum paciente cadastrado.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <footer class="main-footer">
                <div class="footer-content">
                    <p>desenvolvido por <a href="https://alfasistemas.dev.br" target="_blank">alfa sistemas s.a</a> (85) 2028-4584</p>
                    <?php if (!empty($clinica['logo'])): ?>
                        <img src="assets/img/<?php echo $clinica['logo']; ?>" alt="Logo" height="30">
                    <?php endif; ?>
                </div>
            </footer>
        </main>
    </div>

    <!-- ========================================== -->
    <!-- MODAL DE INSERÇÃO DE SERIAL -->
    <!-- ========================================== -->
    <div id="modalSerial" class="modal-overlay">
        <div class="modal-box">
            <div class="modal-header">
                <h3><i class="fas fa-key" style="color: var(--primary);"></i> Ativar Licença</h3>
                <button type="button" class="modal-close" onclick="fecharModalSerial()">&times;</button>
            </div>
            <div class="modal-body">
                <p>Insira o código de ativação fornecido pelo administrador do sistema para renovar sua licença.</p>
                <form id="formSerial" onsubmit="enviarSerial(event)">
                    <input type="hidden" name="acao" value="ativar_serial_dashboard">
                    <input type="text" name="codigo_serial" id="inputSerial" class="modal-input" placeholder="ALFA-XXXX-XXXX-XXXX-XXXX" required oninput="this.value = this.value.toUpperCase()">
                    <button type="submit" id="btnEnviarSerial" class="btn btn-primary" style="width: 100%; justify-content: center; background: var(--primary); color: white;">
                        <i class="fas fa-check-circle"></i> Validar e Ativar
                    </button>
                </form>
                <div id="modalMessage" class="modal-message"></div>
            </div>
        </div>
    </div>

    <script>
        // Preloader
        window.addEventListener('load', function() {
            setTimeout(() => {
                document.getElementById('preloader').style.opacity = '0';
                setTimeout(() => document.getElementById('preloader').style.display = 'none', 500);
            }, 800);
        });

        // Sidebar toggle
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('active');
                overlay.classList.toggle('active');
            });
            overlay.addEventListener('click', () => {
                sidebar.classList.remove('active');
                overlay.classList.remove('active');
            });
        }

        // Theme toggle
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark-theme');
                const icon = themeToggle.querySelector('i');
                if (document.body.classList.contains('dark-theme')) {
                    icon.className = 'fas fa-sun';
                    localStorage.setItem('theme', 'dark');
                } else {
                    icon.className = 'fas fa-moon';
                    localStorage.setItem('theme', 'light');
                }
            });
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-theme');
                themeToggle.querySelector('i').className = 'fas fa-sun';
            }
        }

        // Gráficos
        document.addEventListener('DOMContentLoaded', function() {
            const servicesCtx = document.getElementById('servicesChart');
            if (servicesCtx) {
                new Chart(servicesCtx, {
                    type: 'doughnut',
                    data: {
                        labels: <?php echo json_encode($labels_servicos); ?>,
                        datasets: [{
                            data: <?php echo json_encode($dados_servicos); ?>,
                            backgroundColor: ['#6f42c1', '#20c997', '#2e86de', '#ff9f43'],
                            borderWidth: 2,
                            borderColor: document.body.classList.contains('dark-theme') ? '#1a1d23' : '#ffffff'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { position: 'bottom' }
                        }
                    }
                });
            }
        });

        // ==========================================
        // LÓGICA DO MODAL DE LICENÇA
        // ==========================================
        function abrirModalSerial() {
            document.getElementById('modalSerial').classList.add('active');
            setTimeout(() => {
                document.getElementById('inputSerial').focus();
            }, 100);
            document.getElementById('modalMessage').style.display = 'none';
            document.getElementById('modalMessage').className = 'modal-message';
            document.getElementById('btnEnviarSerial').disabled = false;
            document.getElementById('btnEnviarSerial').innerHTML = '<i class="fas fa-check-circle"></i> Validar e Ativar';
        }

        function fecharModalSerial() {
            document.getElementById('modalSerial').classList.remove('active');
            document.getElementById('formSerial').reset();
            document.getElementById('modalMessage').style.display = 'none';
        }

        // Fechar modal ao clicar fora dele
        document.getElementById('modalSerial').addEventListener('click', function(e) {
            if (e.target === this) fecharModalSerial();
        });

        // Fechar com tecla ESC
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') fecharModalSerial();
        });

        // Enviar serial via AJAX (Fetch)
        function enviarSerial(event) {
            event.preventDefault();
            const form = event.target;
            const formData = new FormData(form);
            const btn = document.getElementById('btnEnviarSerial');
            const msgBox = document.getElementById('modalMessage');

            // Estado de carregamento
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verificando...';
            msgBox.style.display = 'none';

            fetch('dashboard.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.sucesso) {
                    msgBox.className = 'modal-message success';
                    msgBox.innerHTML = '<i class="fas fa-check-circle"></i> ' + data.mensagem;
                    msgBox.style.display = 'block';
                    
                    // Recarrega a página após 2 segundos para atualizar os cards
                    setTimeout(() => {
                        window.location.reload();
                    }, 2000);
                } else {
                    msgBox.className = 'modal-message error';
                    msgBox.innerHTML = '<i class="fas fa-exclamation-circle"></i> ' + data.mensagem;
                    msgBox.style.display = 'block';
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-check-circle"></i> Validar e Ativar';
                }
            })
            .catch(error => {
                msgBox.className = 'modal-message error';
                msgBox.innerHTML = '<i class="fas fa-exclamation-circle"></i> Erro de conexão. Tente novamente.';
                msgBox.style.display = 'block';
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-check-circle"></i> Validar e Ativar';
            });
        }
    </script>
</body>
</html>