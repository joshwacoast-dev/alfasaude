<?php
// ============================================
// ARQUIVO: prontuarios/visualizar.php
// DESCRIÇÃO: Exibe os detalhes de um prontuário
// ============================================

// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/database.php';
require_once '../config/auth.php';
verificarLogin();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'ID inválido.'];
    header('Location: ../prontuarios.php');
    exit;
}

// Buscar dados do prontuário com informações do paciente e médico
$stmt = $pdo->prepare("
    SELECT p.*,
           pac.nome as paciente_nome, pac.data_nascimento as paciente_data_nascimento,
           pac.cpf as paciente_cpf, pac.telefone as paciente_telefone,
           pac.email as paciente_email, pac.convenio as paciente_convenio,
           u.nome as medico_nome, u.crm as medico_crm, u.especialidade as medico_especialidade
    FROM prontuarios p
    JOIN pacientes pac ON p.paciente_id = pac.id
    JOIN usuarios u ON p.usuario_id = u.id
    WHERE p.id = ?
");
$stmt->execute([$id]);
$prontuario = $stmt->fetch();

if (!$prontuario) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Prontuário não encontrado.'];
    header('Location: ../prontuarios.php');
    exit;
}

// Buscar agendamento vinculado, se existir
$agendamento = null;
if ($prontuario['agendamento_id']) {
    $stmt = $pdo->prepare("SELECT * FROM agendamentos WHERE id = ?");
    $stmt->execute([$prontuario['agendamento_id']]);
    $agendamento = $stmt->fetch();
}

// ============================================
// DADOS DO USUÁRIO LOGADO (para sidebar)
// ============================================
$usuario_logado_nome  = $_SESSION['usuario_nome']  ?? 'Usuário';
$usuario_logado_tipo  = $_SESSION['usuario_tipo']  ?? 'usuario';
$usuario_logado_iniciais = strtoupper(substr($usuario_logado_nome, 0, 2));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prontuário | Alfa Saúde</title>
    <!-- Font Awesome, Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ===== TEMA ORIGINAL (copiado do dashboard) ===== */
        :root {
            --primary: #6f42c1;
            --primary-light: #6f42c1dd;
            --primary-dark: #6f42c1aa;
            --secondary: #20c997;
            --secondary-light: #20c997dd;
            --danger: #ff4757;
            --warning: #ff9f43;
            --info: #2e86de;
            --light: #f8f9fa;
            --dark: #343a40;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --border-radius: 12px;
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 8px 30px rgba(0, 0, 0, 0.12);
            --transition: all 0.3s ease;
            --sidebar-width: 280px;
            --topbar-height: 80px;
        }

        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family:'Poppins',sans-serif;
            background:linear-gradient(135deg,#f5f7fb 0%,#eef2f7 100%);
            color:var(--dark);
            line-height:1.6;
            min-height:100vh;
            overflow-x:hidden;
        }
        body.dark-theme {
            --light:#1a1d23;
            --dark:#f8f9fa;
            --gray:#adb5bd;
            --light-gray:#2d3239;
            background:linear-gradient(135deg,#121416 0%,#1a1d23 100%);
            color:#f8f9fa;
        }

        .dashboard-container { display:flex; min-height:100vh; position:relative; }
        .sidebar {
            width:var(--sidebar-width);
            background:linear-gradient(180deg,var(--primary) 0%,var(--primary-dark) 100%);
            color:white;
            display:flex; flex-direction:column; position:fixed; height:100vh; z-index:1000;
            transition:var(--transition); box-shadow:3px 0 20px rgba(0,0,0,0.1); overflow-y:auto;
        }
        .dark-theme .sidebar { box-shadow:3px 0 20px rgba(0,0,0,0.3); }
        .sidebar-header { padding:25px; border-bottom:1px solid rgba(255,255,255,0.15); background:rgba(255,255,255,0.05); position:sticky; top:0; }
        .logo { display:flex; align-items:center; gap:15px; }
        .logo-icon { width:45px; height:45px; background:rgba(255,255,255,0.2); border-radius:10px; display:flex; align-items:center; justify-content:center; }
        .logo-text h2 { font-size:18px; font-weight:700; }
        .logo-text p { font-size:12px; opacity:0.9; }
        .sidebar-menu { flex:1; padding:25px 0; }
        .menu-section { margin-bottom:25px; padding:0 25px; }
        .menu-section h3 { font-size:11px; text-transform:uppercase; letter-spacing:1.5px; opacity:0.7; margin-bottom:15px; font-weight:600; }
        .menu-section ul { list-style:none; }
        .menu-section a { display:flex; align-items:center; gap:15px; padding:12px 15px; color:rgba(255,255,255,0.85); text-decoration:none; border-radius:8px; transition:var(--transition); font-size:14px; }
        .menu-section a:hover, .menu-section a.active { background:rgba(255,255,255,0.12); color:white; }
        .menu-section a.active { background:rgba(255,255,255,0.18); font-weight:600; }
        .menu-section a.active::before { content:''; position:absolute; left:0; top:50%; transform:translateY(-50%); width:4px; height:60%; background:var(--secondary); border-radius:0 4px 4px 0; }
        .menu-section a i { font-size:16px; width:20px; text-align:center; }
        .user-profile { padding:20px; border-top:1px solid rgba(255,255,255,0.15); display:flex; align-items:center; gap:15px; background:rgba(255,255,255,0.05); position:sticky; bottom:0; }
        .user-avatar { width:45px; height:45px; border-radius:50%; background:linear-gradient(135deg,var(--primary-light),var(--secondary)); display:flex; align-items:center; justify-content:center; position:relative; }
        .avatar-placeholder { font-size:16px; font-weight:700; color:white; }
        .online-status { position:absolute; bottom:3px; right:3px; width:12px; height:12px; background:var(--secondary); border-radius:50%; border:2px solid var(--primary-dark); }
        .user-info h4 { font-size:14px; font-weight:600; }
        .user-info p { font-size:12px; opacity:0.9; }
        .user-actions a { color:rgba(255,255,255,0.8); font-size:16px; padding:8px; border-radius:6px; }
        .user-actions a:hover { background:rgba(255,255,255,0.15); color:white; }

        .main-content { flex:1; margin-left:var(--sidebar-width); transition:var(--transition); min-height:100vh; display:flex; flex-direction:column; }
        @media (max-width:1199px) { .main-content { margin-left:0; } }

        .top-bar {
            background:white; padding:15px 25px; box-shadow:var(--shadow); display:flex;
            justify-content:space-between; align-items:center; position:sticky; top:0; z-index:900;
            gap:15px; backdrop-filter:blur(10px); background:rgba(255,255,255,0.95); flex-wrap:wrap; min-height:var(--topbar-height);
        }
        .dark-theme .top-bar { background:rgba(26,29,35,0.95); }
        .top-bar-left { display:flex; align-items:center; gap:15px; flex:1; min-width:0; }
        .sidebar-toggle { display:none; background:var(--primary); border:none; color:white; font-size:18px; cursor:pointer; padding:10px; border-radius:8px; width:40px; height:40px; align-items:center; justify-content:center; }
        .sidebar-toggle:hover { background:var(--primary-dark); }
        @media (max-width:1199px) { .sidebar-toggle { display:flex; } }
        .search-bar { flex:1; min-width:200px; max-width:500px; position:relative; }
        .search-bar i { position:absolute; left:15px; top:50%; transform:translateY(-50%); color:var(--gray); z-index:1; }
        .search-bar input { width:100%; padding:12px 15px 12px 40px; border:2px solid var(--light-gray); border-radius:var(--border-radius); font-size:14px; font-family:'Poppins',sans-serif; transition:var(--transition); background:white; color:var(--dark); }
        .dark-theme .search-bar input { background:var(--light); border-color:#3d4249; }
        .search-bar input:focus { outline:none; border-color:var(--primary); }
        .top-bar-right { display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
        .notification-btn, .message-btn { position:relative; background:var(--light); border:none; font-size:16px; color:var(--gray); cursor:pointer; padding:10px; border-radius:8px; width:40px; height:40px; }
        .dark-theme .notification-btn, .dark-theme .message-btn { background:#2d3239; }
        .notification-btn:hover, .message-btn:hover { background:var(--primary); color:white; transform:translateY(-2px); }
        .notification-badge { position:absolute; top:-5px; right:-5px; background:var(--danger); color:white; font-size:10px; width:18px; height:18px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:2px solid white; }
        .theme-toggle { background:var(--light); border:none; width:40px; height:40px; border-radius:50%; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:var(--transition); font-size:16px; color:var(--gray); }
        .dark-theme .theme-toggle { background:#2d3239; }
        .theme-toggle:hover { background:var(--primary); color:white; transform:rotate(30deg); }
        .quick-actions { display:flex; gap:8px; flex-wrap:wrap; }
        .quick-action-btn { width:40px; height:40px; border-radius:50%; background:linear-gradient(135deg,var(--primary),var(--primary-light)); color:white; display:flex; align-items:center; justify-content:center; transition:var(--transition); font-size:16px; text-decoration:none; }
        .quick-action-btn:hover { transform:translateY(-3px) scale(1.1); box-shadow:0 6px 20px rgba(111,66,193,0.4); }

        .dashboard-content { padding:25px; flex:1; overflow-y:auto; }
        .page-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:30px; flex-wrap:wrap; gap:15px; }
        .page-header h1 { font-size:24px; font-weight:700; color:var(--dark); display:flex; align-items:center; gap:10px; }
        .dark-theme .page-header h1 { color:#f8f9fa; }

        .btn-primary, .btn-secondary, .btn-success, .btn-danger {
            padding:12px 20px; border:none; border-radius:var(--border-radius); font-size:14px; font-weight:600;
            cursor:pointer; display:inline-flex; align-items:center; gap:8px; transition:var(--transition); text-decoration:none;
        }
        .btn-primary { background:var(--primary); color:white; }
        .btn-primary:hover { background:var(--primary-dark); transform:translateY(-2px); box-shadow:0 4px 15px rgba(111,66,193,0.4); }
        .btn-secondary { background:var(--light-gray); color:var(--dark); }
        .btn-secondary:hover { background:var(--gray); color:white; }
        .btn-success { background:var(--secondary); color:white; }
        .btn-success:hover { background:var(--secondary-light); transform:translateY(-2px); }
        .btn-danger { background:var(--danger); color:white; }
        .btn-danger:hover { background:#ff1a2e; transform:translateY(-2px); }
        .dark-theme .btn-secondary { background:#2d3239; color:#f8f9fa; }
        .dark-theme .btn-secondary:hover { background:#3d4249; }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .info-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 25px;
            box-shadow: var(--shadow);
            border: 1px solid rgba(0, 0, 0, 0.05);
        }
        .dark-theme .info-card {
            background: #1a1d23;
            border-color: #2d3239;
        }

        .info-card h3 {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 20px;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .dark-theme .info-card h3 { color: #f8f9fa; }
        .info-card h3 i { color: var(--primary); }

        .info-row {
            display: flex;
            margin-bottom: 12px;
            border-bottom: 1px dashed var(--light-gray);
            padding-bottom: 8px;
        }
        .info-label {
            width: 140px;
            font-weight: 600;
            color: var(--gray);
        }
        .info-value {
            flex: 1;
            color: var(--dark);
        }
        .dark-theme .info-value { color: #f8f9fa; }

        .content-box {
            background: var(--light-gray);
            border-radius: 8px;
            padding: 15px;
            margin-top: 10px;
            white-space: pre-wrap;
        }
        .dark-theme .content-box { background: #2d3239; }

        .main-footer {
            background: white; padding:15px 25px; border-top:1px solid var(--light-gray);
            text-align:center; font-size:13px; color:var(--gray); margin-top:20px;
        }
        .dark-theme .main-footer { background:#1a1d23; border-top-color:#2d3239; }
        .footer-content { display:flex; align-items:center; justify-content:center; gap:10px; }
        .footer-content a { color:var(--primary); text-decoration:none; }

        .sidebar-overlay { display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:999; }
        .preloader { position:fixed; top:0; left:0; width:100%; height:100%; background:white; display:flex; align-items:center; justify-content:center; z-index:9999; transition:opacity 0.5s; }
        .dark-theme .preloader { background:#1a1d23; }
        .loader { text-align:center; }
        .loader i { font-size:50px; color:var(--primary); margin-bottom:20px; animation:bounce 1.5s infinite; }
        @keyframes bounce { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-15px);} }
        @media (max-width:1199px) {
            .sidebar { transform:translateX(-100%); width:300px; }
            .sidebar.active { transform:translateX(0); }
            .sidebar-toggle { display:flex; }
            .sidebar-overlay.active { display:block; }
        }
        @media (max-width:992px) { .info-grid { grid-template-columns:1fr; } }
    </style>
</head>
<body>
    <div class="preloader" id="preloader"><div class="loader"><i class="fas fa-stethoscope"></i><div>Carregando...</div></div></div>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo"><div class="logo-icon"><i class="fas fa-stethoscope"></i></div><div class="logo-text"><h2>Alfa Saúde</h2><p>Gestão Clínica</p></div></div>
            </div>
            <div class="sidebar-menu">
                <div class="menu-section"><h3>Menu Principal</h3>
                    <ul>
                        <li><a href="../dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                        <li><a href="../agendamentos.php"><i class="fas fa-calendar-alt"></i> Agenda</a></li>
                        <li><a href="../pacientes.php"><i class="fas fa-user-injured"></i> Pacientes</a></li>
                        <li><a href="../usuarios.php"><i class="fas fa-user-md"></i> Usuários</a></li>
                    </ul>
                </div>
                <div class="menu-section"><h3>Atendimento</h3>
                    <ul>
                        <li><a href="../prontuarios.php" class="active"><i class="fas fa-notes-medical"></i> Prontuários</a></li>
                        <li><a href="../receituarios.php"><i class="fas fa-prescription"></i> Receituários</a></li>
                        <li><a href="../declaracoes.php"><i class="fas fa-file-medical"></i> Declarações</a></li>
                    </ul>
                </div>
                <div class="menu-section"><h3>Administração</h3>
                    <ul>
                        <li><a href="../clinica.php"><i class="fas fa-hospital"></i> Clínica</a></li>
                        <li><a href="../relatorios.php"><i class="fas fa-chart-line"></i> Relatórios</a></li>
                    </ul>
                </div>
            </div>
            <div class="user-profile">
                <div class="user-avatar"><div class="avatar-placeholder"><?php echo $usuario_logado_iniciais; ?></div><div class="online-status"></div></div>
                <div class="user-info"><h4><?php echo htmlspecialchars($usuario_logado_nome); ?></h4><p><?php echo ucfirst($usuario_logado_tipo); ?></p></div>
                <div class="user-actions"><a href="../logout.php" title="Sair"><i class="fas fa-sign-out-alt"></i></a></div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <header class="top-bar">
                <div class="top-bar-left">
                    <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <div class="search-bar"><i class="fas fa-search"></i><input type="text" placeholder="Pesquisar..."></div>
                </div>
                <div class="top-bar-right">
                    <button class="notification-btn"><i class="fas fa-bell"></i><span class="notification-badge">0</span></button>
                    <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
                    <div class="quick-actions">
                        <a href="novo.php" class="quick-action-btn" title="Novo Prontuário"><i class="fas fa-notes-medical"></i></a>
                    </div>
                </div>
            </header>

            <!-- Conteúdo -->
            <div class="dashboard-content">
                <div class="page-header">
                    <h1><i class="fas fa-notes-medical" style="color:var(--primary);"></i> Prontuário #<?php echo $id; ?></h1>
                    <div>
                        <a href="../prontuarios.php" class="btn-secondary"><i class="fas fa-arrow-left"></i> Voltar</a>
                        <?php if (hasPermissao('medico') && $_SESSION['usuario_id'] == $prontuario['usuario_id']): ?>
                            <a href="editar.php?id=<?php echo $id; ?>" class="btn-primary"><i class="fas fa-edit"></i> Editar</a>
                            <a href="excluir.php?id=<?php echo $id; ?>" class="btn-danger" onclick="return confirm('Excluir este prontuário?')"><i class="fas fa-trash"></i> Excluir</a>
                        <?php endif; ?>
                        <a href="pdf.php?id=<?php echo $id; ?>" class="btn-success" target="_blank"><i class="fas fa-file-pdf"></i> PDF</a>
                    </div>
                </div>

                <!-- Cards de informação -->
                <div class="info-grid">
                    <div class="info-card">
                        <h3><i class="fas fa-user-injured"></i> Paciente</h3>
                        <div class="info-row"><span class="info-label">Nome:</span><span class="info-value"><strong><?php echo htmlspecialchars($prontuario['paciente_nome']); ?></strong></span></div>
                        <?php if ($prontuario['paciente_data_nascimento']): ?>
                        <div class="info-row"><span class="info-label">Data Nasc.:</span><span class="info-value"><?php echo date('d/m/Y', strtotime($prontuario['paciente_data_nascimento'])); ?></span></div>
                        <?php endif; ?>
                        <?php if ($prontuario['paciente_cpf']): ?>
                        <div class="info-row"><span class="info-label">CPF:</span><span class="info-value"><?php echo htmlspecialchars($prontuario['paciente_cpf']); ?></span></div>
                        <?php endif; ?>
                        <?php if ($prontuario['paciente_telefone']): ?>
                        <div class="info-row"><span class="info-label">Telefone:</span><span class="info-value"><?php echo htmlspecialchars($prontuario['paciente_telefone']); ?></span></div>
                        <?php endif; ?>
                        <?php if ($prontuario['paciente_email']): ?>
                        <div class="info-row"><span class="info-label">E-mail:</span><span class="info-value"><?php echo htmlspecialchars($prontuario['paciente_email']); ?></span></div>
                        <?php endif; ?>
                        <div class="info-row"><span class="info-label">Convênio:</span><span class="info-value"><?php echo htmlspecialchars($prontuario['paciente_convenio'] ?? 'Particular'); ?></span></div>
                    </div>

                    <div class="info-card">
                        <h3><i class="fas fa-user-md"></i> Médico</h3>
                        <div class="info-row"><span class="info-label">Nome:</span><span class="info-value"><strong><?php echo htmlspecialchars($prontuario['medico_nome']); ?></strong></span></div>
                        <?php if ($prontuario['medico_crm']): ?>
                        <div class="info-row"><span class="info-label">CRM:</span><span class="info-value"><?php echo htmlspecialchars($prontuario['medico_crm']); ?></span></div>
                        <?php endif; ?>
                        <?php if ($prontuario['medico_especialidade']): ?>
                        <div class="info-row"><span class="info-label">Especialidade:</span><span class="info-value"><?php echo htmlspecialchars($prontuario['medico_especialidade']); ?></span></div>
                        <?php endif; ?>
                    </div>

                    <div class="info-card">
                        <h3><i class="fas fa-clock"></i> Atendimento</h3>
                        <div class="info-row"><span class="info-label">Data/Hora:</span><span class="info-value"><?php echo date('d/m/Y H:i', strtotime($prontuario['data_atendimento'])); ?></span></div>
                        <?php if ($agendamento): ?>
                        <div class="info-row"><span class="info-label">Agendamento:</span><span class="info-value"><a href="../agendamentos/visualizar.php?id=<?php echo $agendamento['id']; ?>" style="color:var(--primary);">#<?php echo $agendamento['id']; ?></a></span></div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Seções de texto -->
                <div class="info-card" style="margin-bottom:20px;">
                    <h3><i class="fas fa-notes-medical"></i> Anamnese</h3>
                    <div class="content-box"><?php echo nl2br(htmlspecialchars($prontuario['anamnese'] ?? '')); ?></div>
                </div>

                <?php if (!empty($prontuario['exame_fisico'])): ?>
                <div class="info-card" style="margin-bottom:20px;">
                    <h3><i class="fas fa-heartbeat"></i> Exame Físico</h3>
                    <div class="content-box"><?php echo nl2br(htmlspecialchars($prontuario['exame_fisico'])); ?></div>
                </div>
                <?php endif; ?>

                <?php if (!empty($prontuario['hipotese_diagnostica'])): ?>
                <div class="info-card" style="margin-bottom:20px;">
                    <h3><i class="fas fa-question-circle"></i> Hipótese Diagnóstica</h3>
                    <div class="content-box"><?php echo nl2br(htmlspecialchars($prontuario['hipotese_diagnostica'])); ?></div>
                </div>
                <?php endif; ?>

                <?php if (!empty($prontuario['diagnostico_final'])): ?>
                <div class="info-card" style="margin-bottom:20px;">
                    <h3><i class="fas fa-check-circle"></i> Diagnóstico Final</h3>
                    <div class="content-box"><?php echo nl2br(htmlspecialchars($prontuario['diagnostico_final'])); ?></div>
                </div>
                <?php endif; ?>

                <?php if (!empty($prontuario['conduta'])): ?>
                <div class="info-card" style="margin-bottom:20px;">
                    <h3><i class="fas fa-stethoscope"></i> Conduta</h3>
                    <div class="content-box"><?php echo nl2br(htmlspecialchars($prontuario['conduta'])); ?></div>
                </div>
                <?php endif; ?>

                <?php if (!empty($prontuario['observacoes'])): ?>
                <div class="info-card" style="margin-bottom:20px;">
                    <h3><i class="fas fa-comment"></i> Observações</h3>
                    <div class="content-box"><?php echo nl2br(htmlspecialchars($prontuario['observacoes'])); ?></div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Footer -->
            <footer class="main-footer">
                <div class="footer-content"><p>desenvolvido por <a href="https://alfasistemas.dev.br" target="_blank">alfa sistemas s.a</a> (85) 2028-4584</p></div>
            </footer>
        </main>
    </div>

    <script>
        window.addEventListener('load', function() { setTimeout(() => { document.getElementById('preloader').style.opacity = '0'; setTimeout(() => document.getElementById('preloader').style.display = 'none', 500); }, 800); });
        const sidebarToggle = document.getElementById('sidebarToggle'), sidebar = document.getElementById('sidebar'), overlay = document.getElementById('sidebarOverlay');
        if (sidebarToggle) { sidebarToggle.addEventListener('click', () => { sidebar.classList.toggle('active'); overlay.classList.toggle('active'); }); overlay.addEventListener('click', () => { sidebar.classList.remove('active'); overlay.classList.remove('active'); }); }
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => { document.body.classList.toggle('dark-theme'); const icon = themeToggle.querySelector('i'); if (document.body.classList.contains('dark-theme')) { icon.className = 'fas fa-sun'; localStorage.setItem('theme', 'dark'); } else { icon.className = 'fas fa-moon'; localStorage.setItem('theme', 'light'); } });
            if (localStorage.getItem('theme') === 'dark') { document.body.classList.add('dark-theme'); themeToggle.querySelector('i').className = 'fas fa-sun'; }
        }
    </script>
</body>
</html>