<?php
// ============================================
// ARQUIVO: prontuarios/imprimir.php
// DESCRIÇÃO: Versão para impressão do prontuário
// ============================================

// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/database.php';
require_once '../config/auth.php';
verificarLogin();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    die('ID inválido.');
}

// Buscar dados do prontuário com informações do paciente e médico
$stmt = $pdo->prepare("
    SELECT p.*,
           pac.nome as paciente_nome, pac.data_nascimento as paciente_data_nascimento,
           pac.cpf as paciente_cpf, pac.telefone as paciente_telefone,
           pac.email as paciente_email, pac.convenio as paciente_convenio,
           u.nome as medico_nome, u.crm as medico_crm, u.especialidade as medico_especialidade
    FROM prontuarios p
    JOIN pacientes pac ON p.paciente_id = pac.id
    JOIN usuarios u ON p.usuario_id = u.id
    WHERE p.id = ?
");
$stmt->execute([$id]);
$prontuario = $stmt->fetch();

if (!$prontuario) {
    die('Prontuário não encontrado.');
}

// Buscar dados da clínica
$stmt = $pdo->query("SELECT * FROM clinica LIMIT 1");
$clinica = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prontuário #<?php echo $id; ?> | <?php echo htmlspecialchars($clinica['nome'] ?? 'Alfa Saúde'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background: white;
            color: #333;
            line-height: 1.6;
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #6f42c1;
            padding-bottom: 15px;
        }
        .logo {
            max-height: 80px;
            margin-bottom: 10px;
        }
        h1 {
            color: #6f42c1;
            font-size: 24px;
            margin-bottom: 5px;
        }
        .clinica-info {
            color: #666;
            font-size: 14px;
        }
        h2 {
            font-size: 18px;
            margin: 20px 0 10px;
            color: #6f42c1;
            border-left: 4px solid #20c997;
            padding-left: 10px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 20px;
        }
        .info-card {
            background: #f9f9f9;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 15px;
        }
        .info-card h3 {
            font-size: 16px;
            color: #6f42c1;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .info-row {
            display: flex;
            margin-bottom: 8px;
            border-bottom: 1px dashed #ddd;
            padding-bottom: 5px;
        }
        .label {
            width: 120px;
            font-weight: 600;
            color: #555;
        }
        .value {
            flex: 1;
            color: #333;
        }
        .content-box {
            background: #f9f9f9;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
            white-space: pre-wrap;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            font-size: 12px;
            color: #888;
            border-top: 1px solid #ccc;
            padding-top: 15px;
        }
        .assinatura {
            margin-top: 40px;
            text-align: right;
        }
        .assinatura p {
            margin-bottom: 5px;
        }
        @media print {
            body {
                padding: 0.5cm;
            }
            .no-print {
                display: none;
            }
        }
        .btn-print {
            background: #6f42c1;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            margin-bottom: 20px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-print:hover {
            background: #4a1e8a;
        }
    </style>
</head>
<body>
    <button class="btn-print no-print" onclick="window.print()">
        <i class="fas fa-print"></i> Imprimir / Salvar PDF
    </button>

    <div class="header">
        <?php if (!empty($clinica['logo']) && file_exists('../assets/img/' . $clinica['logo'])): ?>
            <img src="../assets/img/<?php echo htmlspecialchars($clinica['logo']); ?>" alt="Logo" class="logo">
        <?php endif; ?>
        <h1><?php echo htmlspecialchars($clinica['nome'] ?? 'Alfa Saúde'); ?></h1>
        <div class="clinica-info">
            <?php echo htmlspecialchars($clinica['endereco'] ?? ''); ?><br>
            Tel: <?php echo htmlspecialchars($clinica['telefone'] ?? ''); ?> | E-mail: <?php echo htmlspecialchars($clinica['email'] ?? ''); ?>
        </div>
    </div>

    <h2>Prontuário #<?php echo $id; ?></h2>

    <div class="info-grid">
        <div class="info-card">
            <h3><i class="fas fa-user-injured"></i> Paciente</h3>
            <div class="info-row"><span class="label">Nome:</span><span class="value"><strong><?php echo htmlspecialchars($prontuario['paciente_nome']); ?></strong></span></div>
            <?php if ($prontuario['paciente_data_nascimento']): ?>
            <div class="info-row"><span class="label">Data Nasc.:</span><span class="value"><?php echo date('d/m/Y', strtotime($prontuario['paciente_data_nascimento'])); ?></span></div>
            <?php endif; ?>
            <?php if ($prontuario['paciente_cpf']): ?>
            <div class="info-row"><span class="label">CPF:</span><span class="value"><?php echo htmlspecialchars($prontuario['paciente_cpf']); ?></span></div>
            <?php endif; ?>
            <?php if ($prontuario['paciente_telefone']): ?>
            <div class="info-row"><span class="label">Telefone:</span><span class="value"><?php echo htmlspecialchars($prontuario['paciente_telefone']); ?></span></div>
            <?php endif; ?>
            <?php if ($prontuario['paciente_email']): ?>
            <div class="info-row"><span class="label">E-mail:</span><span class="value"><?php echo htmlspecialchars($prontuario['paciente_email']); ?></span></div>
            <?php endif; ?>
            <div class="info-row"><span class="label">Convênio:</span><span class="value"><?php echo htmlspecialchars($prontuario['paciente_convenio'] ?? 'Particular'); ?></span></div>
        </div>

        <div class="info-card">
            <h3><i class="fas fa-user-md"></i> Médico</h3>
            <div class="info-row"><span class="label">Nome:</span><span class="value"><strong><?php echo htmlspecialchars($prontuario['medico_nome']); ?></strong></span></div>
            <?php if ($prontuario['medico_crm']): ?>
            <div class="info-row"><span class="label">CRM:</span><span class="value"><?php echo htmlspecialchars($prontuario['medico_crm']); ?></span></div>
            <?php endif; ?>
            <?php if ($prontuario['medico_especialidade']): ?>
            <div class="info-row"><span class="label">Especialidade:</span><span class="value"><?php echo htmlspecialchars($prontuario['medico_especialidade']); ?></span></div>
            <?php endif; ?>
        </div>
    </div>

    <div class="info-card" style="grid-column: span 2; margin-bottom:20px;">
        <div class="info-row"><span class="label">Data atendimento:</span><span class="value"><?php echo date('d/m/Y H:i', strtotime($prontuario['data_atendimento'])); ?></span></div>
    </div>

    <h2>Anamnese</h2>
    <div class="content-box"><?php echo nl2br(htmlspecialchars($prontuario['anamnese'])); ?></div>

    <?php if (!empty($prontuario['exame_fisico'])): ?>
    <h2>Exame Físico</h2>
    <div class="content-box"><?php echo nl2br(htmlspecialchars($prontuario['exame_fisico'])); ?></div>
    <?php endif; ?>

    <?php if (!empty($prontuario['hipotese_diagnostica'])): ?>
    <h2>Hipótese Diagnóstica</h2>
    <div class="content-box"><?php echo nl2br(htmlspecialchars($prontuario['hipotese_diagnostica'])); ?></div>
    <?php endif; ?>

    <?php if (!empty($prontuario['diagnostico_final'])): ?>
    <h2>Diagnóstico Final</h2>
    <div class="content-box"><?php echo nl2br(htmlspecialchars($prontuario['diagnostico_final'])); ?></div>
    <?php endif; ?>

    <?php if (!empty($prontuario['conduta'])): ?>
    <h2>Conduta</h2>
    <div class="content-box"><?php echo nl2br(htmlspecialchars($prontuario['conduta'])); ?></div>
    <?php endif; ?>

    <?php if (!empty($prontuario['observacoes'])): ?>
    <h2>Observações</h2>
    <div class="content-box"><?php echo nl2br(htmlspecialchars($prontuario['observacoes'])); ?></div>
    <?php endif; ?>

    <div class="assinatura">
        <p>_________________________________</p>
        <p>Dr(a). <?php echo htmlspecialchars($prontuario['medico_nome']); ?><br><?php echo htmlspecialchars($prontuario['medico_crm'] ?? ''); ?></p>
    </div>

    <div class="footer">
        Documento gerado em <?php echo date('d/m/Y H:i:s'); ?> - Válido apenas com assinatura digital.<br>
        desenvolvido por <a href="https://alfasistemas.dev.br" target="_blank">alfa sistemas s.a</a> (85) 2028-4584
    </div>

    <!-- Font Awesome para ícones (opcional, apenas para o botão) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</body>
</html>