<?php
// ============================================
// ARQUIVO: prontuarios/excluir.php
// DESCRIÇÃO: Exclui (fisicamente) um prontuário
// ============================================

// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Iniciar sessão se necessário
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';
require_once '../config/auth.php';
verificarLogin();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'ID inválido.'];
    header('Location: ../prontuarios.php');
    exit;
}

// Buscar dados do prontuário para verificar permissão e existência
$stmt = $pdo->prepare("SELECT usuario_id FROM prontuarios WHERE id = ?");
$stmt->execute([$id]);
$prontuario = $stmt->fetch();

if (!$prontuario) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Prontuário não encontrado.'];
    header('Location: ../prontuarios.php');
    exit;
}

// Verificar permissão: apenas o médico que criou ou administrador podem excluir
if (!hasPermissao('admin') && $_SESSION['usuario_id'] != $prontuario['usuario_id']) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Você não tem permissão para excluir este prontuário.'];
    header('Location: ../prontuarios.php');
    exit;
}

// Confirmar exclusão via GET? (opcional, mas já temos confirmação no link)
// Se desejar, pode adicionar uma verificação extra com um token, mas não é necessário.

try {
    $stmt = $pdo->prepare("DELETE FROM prontuarios WHERE id = ?");
    if ($stmt->execute([$id])) {
        $_SESSION['flash'] = ['tipo' => 'success', 'msg' => 'Prontuário excluído com sucesso!'];
    } else {
        $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Erro ao excluir prontuário.'];
    }
} catch (PDOException $e) {
    // Se houver erro de chave estrangeira, informar
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Erro no banco de dados: ' . $e->getMessage()];
}

header('Location: ../prontuarios.php');
exit;