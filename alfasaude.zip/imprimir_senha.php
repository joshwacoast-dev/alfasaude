<?php
session_start();
require_once 'config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id == 0) {
    die('ID da senha não informado.');
}

$stmt = $pdo->prepare("SELECT * FROM fila_chamadas WHERE id = ?");
$stmt->execute([$id]);
$dados = $stmt->fetch();

if (!$dados) {
    die('Senha não encontrada.');
}

$stmt_pac = $pdo->prepare("SELECT nome FROM pacientes WHERE UPPER(nome) = ?");
$stmt_pac->execute([strtoupper(trim($dados['nome_paciente']))]);
$pac = $stmt_pac->fetch();
$nome_paciente = $pac ? $pac['nome'] : $dados['nome_paciente'];

$local = $dados['sala'] ?? $dados['guiche'] ?? 'Guichê 1';
$gravidade = $dados['gravidade'] ?? 'verde';
$senha = $dados['senha'];
$data_hora = date('d/m/Y H:i', strtotime($dados['data_hora']));

$nomes_gravidade = [
    'verde' => 'Baixa Complexidade',
    'azul' => 'Média Complexidade', 
    'amarelo' => 'Alta Complexidade',
    'vermelho' => 'Emergência / Urgência'
];

$pref_labels = [
    'idoso' => 'IDOSO (60+)',
    'gestante' => 'GESTANTE',
    'deficiente' => 'PESSOA COM DEFICIÊNCIA',
    'lactante' => 'LACTANTE'
];

$preferencial = $dados['preferencial'] ?? 'nenhum';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Senha <?= $senha ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        @page { 
            margin: 0; 
            size: 80mm auto;
        }
        
        body { 
            margin: 0; 
            padding: 0; 
            font-family: 'Courier New', monospace;
            background: white;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        
        .cupom {
            max-width: 80mm;
            width: 100%;
            padding: 8px 10px;
            background: white;
            font-size: 12px;
        }
        
        .cupom .header {
            text-align: center;
            border-bottom: 2px dashed #333;
            padding-bottom: 8px;
            margin-bottom: 10px;
        }
        
        .cupom .header h2 {
            font-size: 20px;
            margin: 5px 0;
            text-transform: uppercase;
            letter-spacing: 4px;
            color: #6f42c1;
        }
        
        .cupom .header .sub {
            font-size: 10px;
            color: #666;
            letter-spacing: 1px;
        }
        
        .cupom .senha-box {
            text-align: center;
            padding: 15px 0;
            margin: 10px 0;
            border: 4px double #333;
            border-radius: 8px;
            background: #f8f9fa;
        }
        
        .cupom .senha-box .senha-label {
            font-size: 10px;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 3px;
            font-weight: 700;
        }
        
        .cupom .senha-box .senha-numero {
            font-size: 52px;
            font-weight: 900;
            letter-spacing: 8px;
            font-family: 'Courier New', monospace;
            color: #6f42c1;
            display: block;
            margin: 2px 0;
            line-height: 1.2;
        }
        
        .cupom .info-row {
            display: flex;
            justify-content: space-between;
            padding: 4px 0;
            border-bottom: 1px dotted #ddd;
            font-size: 13px;
        }
        
        .cupom .info-row .label {
            color: #666;
            font-weight: 400;
        }
        
        .cupom .info-row .value {
            font-weight: 700;
            text-align: right;
        }
        
        .cupom .gravidade-box {
            text-align: center;
            padding: 10px;
            margin: 12px 0;
            border-radius: 6px;
            font-weight: 800;
            text-transform: uppercase;
            color: white;
            font-size: 14px;
            letter-spacing: 2px;
        }
        
        .cupom .gravidade-box.verde { background: #20c997; }
        .cupom .gravidade-box.azul { background: #2e86de; }
        .cupom .gravidade-box.amarelo { background: #ff9f43; }
        .cupom .gravidade-box.vermelho { background: #ff4757; }
        
        .cupom .preferencial-box {
            text-align: center;
            padding: 8px;
            margin: 10px 0;
            background: #fff3cd;
            border-radius: 6px;
            font-weight: 700;
            font-size: 12px;
            border: 2px solid #ffc107;
        }
        
        .cupom .footer {
            text-align: center;
            border-top: 2px dashed #333;
            padding-top: 10px;
            margin-top: 12px;
            font-size: 9px;
            color: #999;
        }
        
        .cupom .footer .linha {
            letter-spacing: 2px;
        }
        
        /* Esconde os botões na impressão */
        .no-print {
            display: none;
        }
        
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                margin: 0;
                padding: 0;
            }
            .cupom {
                padding: 5px 8px;
            }
        }
    </style>
</head>
<body>
    <!-- CUPOM -->
    <div class="cupom" id="cupomParaImprimir">
        <div class="header">
            <h2>🏥 Alfa Saúde</h2>
            <div class="sub">Sistema de Atendimento</div>
            <div class="sub"><?= date('d/m/Y H:i') ?></div>
        </div>
        
        <div class="senha-box">
            <div class="senha-label">SENHA</div>
            <div class="senha-numero"><?= $senha ?></div>
        </div>
        
        <div class="info-row">
            <span class="label">Paciente:</span>
            <span class="value"><?= htmlspecialchars($nome_paciente) ?></span>
        </div>
        
        <div class="info-row">
            <span class="label">Local:</span>
            <span class="value"><?= htmlspecialchars($local) ?></span>
        </div>
        
        <div class="info-row">
            <span class="label">Data/Hora:</span>
            <span class="value"><?= $data_hora ?></span>
        </div>
        
        <div class="gravidade-box <?= $gravidade ?>">
            <?= strtoupper($gravidade) ?> - <?= $nomes_gravidade[$gravidade] ?>
        </div>
        
        <?php if ($preferencial !== 'nenhum'): ?>
        <div class="preferencial-box">
            ⭐ ATENDIMENTO PREFERENCIAL - <?= $pref_labels[$preferencial] ?>
        </div>
        <?php endif; ?>
        
        <div class="footer">
            <div class="linha">_________________________________</div>
            <div>Senha válida para o dia de hoje</div>
            <div>Apresente esta senha no atendimento</div>
            <br>
            <div>Obrigado pela preferência!</div>
        </div>
    </div>
    
    <!-- Script que imprime automaticamente e fecha -->
    <script>
        // Força a impressão assim que a página carregar
        window.onload = function() {
            // Pequeno delay para garantir que tudo foi renderizado
            setTimeout(function() {
                window.print();
            }, 500);
        };
        
        // Após a impressão (ou cancelamento), fecha a janela
        window.onafterprint = function() {
            window.close();
        };
        
        // Fallback: se o usuário demorar muito, fecha após 30 segundos
        setTimeout(function() {
            window.close();
        }, 30000);
    </script>
</body>
</html>