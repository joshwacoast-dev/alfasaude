<?php
// ============================================
// ARQUIVO: chamados.php
// DESCRIÇÃO: Painel de Controle (Apenas Gerencia, não toca som)
// ============================================

session_start();
require_once 'config/database.php';
require_once 'config/auth.php';
verificarLogin();

$msg = $_GET['msg'] ?? '';
$nome_busca = $_GET['nome_busca'] ?? '';
$alerta = '';

if ($msg === 'erro_paciente') {
    $alerta = '<div class="alert alert-error">
        <i class="fas fa-exclamation-triangle"></i>
        <div>
            Paciente "<strong>' . htmlspecialchars($nome_busca) . '</strong>" não encontrado. 
            <a href="pacientes/novo.php?nome_previo=' . urlencode($nome_busca) . '" class="btn btn-sm" style="background: white; color: var(--danger); margin-left: 10px; padding: 6px 15px; font-size: 13px; text-decoration: none; display: inline-flex; align-items: center; gap: 5px; border-radius: 6px;">
                <i class="fas fa-user-plus"></i> Cadastrar este Paciente
            </a>
        </div>
    </div>';
} elseif ($msg === 'adicionado') {
    $alerta = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Paciente adicionado à fila!</div>';
} elseif ($msg === 'chamando') {
    $alerta = '<div class="alert alert-info"><i class="fas fa-volume-up"></i> Enviando chamada para a TV...</div>';
} elseif ($msg === 'chamando_novamente') {
    $alerta = '<div class="alert alert-info"><i class="fas fa-redo"></i> Repetindo chamada na TV...</div>';
} elseif ($msg === 'atendido') {
    $alerta = '<div class="alert alert-success"><i class="fas fa-check"></i> Paciente atendido.</div>';
} elseif ($msg === 'config') {
    $alerta = '<div class="alert alert-success"><i class="fas fa-magic"></i> Configurações salvas!</div>';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';
    
    if ($acao === 'adicionar') {
        $nome_digitado = strtoupper(trim($_POST['nome_paciente']));
        $nome_url = urlencode($nome_digitado);
        
        $stmt_pac = $pdo->prepare("SELECT id, nome FROM pacientes WHERE UPPER(nome) LIKE ? AND ativo = 1");
        $stmt_pac->execute(['%' . $nome_digitado . '%']);
        $paciente = $stmt_pac->fetch();
        
        if (!$paciente) {
            header('Location: chamados.php?msg=erro_paciente&nome_busca=' . $nome_url);
            exit;
        }
        
        $local = trim($_POST['local_atendimento'] ?? 'Guichê 1');
        $gravidade = $_POST['gravidade'] ?? 'verde';
        $preferencial = $_POST['preferencial'] ?? 'nenhum';
        $especialidade = trim($_POST['especialidade'] ?? 'Clínico Geral');
        
        // Gera senha baseada no total do dia
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM fila_chamadas WHERE DATE(data_hora) = CURDATE()");
        $senha = 'A' . str_pad(($stmt->fetch()['total'] + 1), 3, '0', STR_PAD_LEFT);
        
        try {
            // Tenta inserir incluindo a coluna especialidade
            $pdo->prepare("INSERT INTO fila_chamadas (nome_paciente, senha, sala, gravidade, preferencial, especialidade, status) VALUES (?, ?, ?, ?, ?, ?, 'aguardando')")
                ->execute([$paciente['nome'], $senha, $local, $gravidade, $preferencial, $especialidade]);
        } catch (PDOException $e) {
            // Fallback caso a tabela antiga não tenha a coluna especialidade ou use 'guiche'
            try {
                $pdo->prepare("INSERT INTO fila_chamadas (nome_paciente, senha, guiche, gravidade, preferencial, especialidade, status) VALUES (?, ?, ?, ?, ?, ?, 'aguardando')")
                    ->execute([$paciente['nome'], $senha, $local, $gravidade, $preferencial, $especialidade]);
            } catch (PDOException $e2) {
                 // Fallback final sem especialidade se o banco for muito antigo
                $pdo->prepare("INSERT INTO fila_chamadas (nome_paciente, senha, guiche, gravidade, preferencial, status) VALUES (?, ?, ?, ?, ?, 'aguardando')")
                    ->execute([$paciente['nome'], $senha, $local, $gravidade, $preferencial]);
            }
        }
        
        // Não chama automaticamente aqui, apenas adiciona
        header('Location: chamados.php?msg=adicionado');
        exit;
    }
    
    if ($acao === 'chamar' || $acao === 'chamar_novamente') {
        // Apenas muda o status. A TV vai detectar essa mudança e tocar o som.
        $pdo->prepare("UPDATE fila_chamadas SET status = 'chamando', data_ultima_chamada = NOW() WHERE id = ?")->execute([$_POST['id']]);
        $redirect = ($acao === 'chamar') ? 'chamando' : 'chamando_novamente';
        header('Location: chamados.php?msg=' . $redirect);
        exit;
    }
    
    if ($acao === 'atendido') {
        $pdo->prepare("UPDATE fila_chamadas SET status = 'atendido' WHERE id = ?")->execute([$_POST['id']]);
        header('Location: chamados.php?msg=atendido');
        exit;
    }
    
    if ($acao === 'config') {
        $pdo->prepare("UPDATE config_chamada SET mensagem_base = ?, video_fundo = ? WHERE id = 1")->execute([$_POST['mensagem'], $_POST['video']]);
        header('Location: chamados.php?msg=config');
        exit;
    }
}

$pacientes_cadastrados = $pdo->query("SELECT id, nome FROM pacientes WHERE ativo = 1 ORDER BY nome ASC")->fetchAll();
$ultimo_chamado = $pdo->query("SELECT * FROM fila_chamadas WHERE status = 'chamando' ORDER BY data_ultima_chamada DESC LIMIT 1")->fetch();

$fila = $pdo->query("
    SELECT *, TIMESTAMPDIFF(MINUTE, data_hora, NOW()) as tempo_espera_minutos
    FROM fila_chamadas 
    WHERE status IN ('aguardando', 'chamando') 
    ORDER BY FIELD(gravidade, 'vermelho', 'amarelo', 'azul', 'verde'), 
             FIELD(status, 'chamando', 'aguardando'), 
             data_hora ASC
")->fetchAll();

$historico = $pdo->query("
    SELECT *, TIMESTAMPDIFF(MINUTE, data_hora, COALESCE(data_ultima_chamada, NOW())) as tempo_espera_minutos
    FROM fila_chamadas 
    WHERE status = 'atendido' 
    ORDER BY data_ultima_chamada DESC 
    LIMIT 15
")->fetchAll();

$config = $pdo->query("SELECT * FROM config_chamada LIMIT 1")->fetch();

$usuario_nome  = $_SESSION['usuario_nome']  ?? 'Usuário';
$usuario_tipo  = $_SESSION['usuario_tipo']  ?? 'usuario';
$usuario_iniciais = strtoupper(substr($usuario_nome, 0, 2));

$especialidades = [
    "Clínico Geral", "Pediatria", "Cardiologia", "Ginecologia e Obstetrícia", 
    "Ortopedia", "Dermatologia", "Oftalmologia", "Otorrinolaringologia", 
    "Neurologia", "Psiquiatria", "Urologia", "Gastroenterologia", 
    "Endocrinologia", "Reumatologia", "Nefrologia", "Pneumologia", 
    "Hematologia", "Oncologia", "Geriatria", "Nutrologia", 
    "Medicina do Trabalho", "Vacinação", "Enfermagem", "Triagem"
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Controle de Chamadas | Alfa Saúde</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ===== MANTENDO O MESMO CSS DO TEMA ANTERIOR ===== */
        :root {
            --primary: #6f42c1; --primary-light: #6f42c1dd; --primary-dark: #6f42c1aa;
            --secondary: #20c997; --danger: #ff4757; --warning: #ff9f43; --info: #2e86de;
            --light: #f8f9fa; --dark: #343a40; --gray: #6c757d; --light-gray: #e9ecef;
            --border-radius: 12px; --shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            --transition: all 0.3s ease; --sidebar-width: 280px; --topbar-height: 80px;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background: linear-gradient(135deg, #f5f7fb 0%, #eef2f7 100%); color: var(--dark); min-height: 100vh; }
        body.dark-theme { --light: #1a1d23; --dark: #f8f9fa; --gray: #adb5bd; --light-gray: #2d3239; background: linear-gradient(135deg, #121416 0%, #1a1d23 100%); }
        .dashboard-container { display: flex; min-height: 100vh; position: relative; }
        .sidebar { width: var(--sidebar-width); background: linear-gradient(180deg, var(--primary) 0%, var(--primary-dark) 100%); color: white; display: flex; flex-direction: column; position: fixed; height: 100vh; z-index: 1000; transition: var(--transition); box-shadow: 3px 0 20px rgba(0, 0, 0, 0.1); }
        .sidebar-header { padding: 25px; border-bottom: 1px solid rgba(255, 255, 255, 0.15); background: rgba(255, 255, 255, 0.05); }
        .logo { display: flex; align-items: center; gap: 15px; }
        .logo-icon { width: 45px; height: 45px; background: rgba(255, 255, 255, 0.2); border-radius: 10px; display: flex; align-items: center; justify-content: center; }
        .logo-text h2 { font-size: 18px; font-weight: 700; margin: 0; }
        .logo-text p { font-size: 12px; opacity: 0.9; margin: 3px 0 0 0; }
        .sidebar-menu { flex: 1; padding: 25px 0; overflow-y: auto; }
        .menu-section { margin-bottom: 25px; padding: 0 25px; }
        .menu-section h3 { font-size: 11px; text-transform: uppercase; letter-spacing: 1.5px; opacity: 0.7; margin-bottom: 15px; font-weight: 600; }
        .menu-section ul { list-style: none; }
        .menu-section li { margin-bottom: 5px; }
        .menu-section a { display: flex; align-items: center; gap: 15px; padding: 12px 15px; color: rgba(255, 255, 255, 0.85); text-decoration: none; border-radius: 8px; transition: var(--transition); font-weight: 500; font-size: 14px; }
        .menu-section a:hover, .menu-section a.active { background: rgba(255, 255, 255, 0.12); color: white; }
        .menu-section a.active { background: rgba(255, 255, 255, 0.18); font-weight: 600; }
        .menu-section a.active::before { content: ''; position: absolute; left: 0; top: 50%; transform: translateY(-50%); width: 4px; height: 60%; background: var(--secondary); border-radius: 0 4px 4px 0; }
        .menu-section a i { font-size: 16px; width: 20px; text-align: center; }
        .user-profile { padding: 20px; border-top: 1px solid rgba(255, 255, 255, 0.15); display: flex; align-items: center; gap: 15px; background: rgba(255, 255, 255, 0.05); }
        .user-avatar { width: 45px; height: 45px; border-radius: 50%; background: linear-gradient(135deg, var(--primary-light), var(--secondary)); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .avatar-placeholder { font-size: 16px; font-weight: 700; color: white; }
        .user-info { flex: 1; min-width: 0; }
        .user-info h4 { font-size: 14px; font-weight: 600; margin: 0 0 4px 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .user-info p { font-size: 12px; opacity: 0.9; margin: 0; }
        .user-actions a { color: rgba(255, 255, 255, 0.8); font-size: 16px; transition: var(--transition); padding: 8px; border-radius: 6px; display: flex; align-items: center; justify-content: center; text-decoration: none;}
        .user-actions a:hover { background: rgba(255, 255, 255, 0.15); color: white; }
        .main-content { flex: 1; margin-left: var(--sidebar-width); transition: var(--transition); min-height: 100vh; display: flex; flex-direction: column; }
        @media (max-width: 1199px) { .main-content { margin-left: 0; } .sidebar { transform: translateX(-100%); width: 300px; } .sidebar.active { transform: translateX(0); } }
        .top-bar { background: rgba(255, 255, 255, 0.95); padding: 15px 25px; box-shadow: var(--shadow); display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 900; backdrop-filter: blur(10px); min-height: var(--topbar-height); }
        .dark-theme .top-bar { background: rgba(26, 29, 35, 0.95); }
        .top-bar-left { display: flex; align-items: center; gap: 15px; flex: 1; }
        .sidebar-toggle { display: none; background: var(--primary); border: none; color: white; font-size: 18px; cursor: pointer; padding: 10px; border-radius: 8px; width: 40px; height: 40px; align-items: center; justify-content: center; }
        @media (max-width: 1199px) { .sidebar-toggle { display: flex; } }
        .theme-toggle { background: var(--light); border: none; width: 40px; height: 40px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: var(--transition); font-size: 16px; color: var(--gray); }
        .dark-theme .theme-toggle { background: #2d3239; }
        .theme-toggle:hover { background: var(--primary); color: white; transform: rotate(30deg); }
        .dashboard-content { padding: 25px; flex: 1; overflow-y: auto; }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; flex-wrap: wrap; gap: 15px; }
        .page-header h1 { font-size: 24px; font-weight: 700; color: var(--dark); display: flex; align-items: center; gap: 10px; }
        .dark-theme .page-header h1 { color: #f8f9fa; }
        .btn { padding: 12px 20px; border: none; border-radius: var(--border-radius); font-size: 14px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: var(--transition); text-decoration: none; white-space: nowrap; }
        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-dark); transform: translateY(-2px); box-shadow: 0 4px 15px rgba(111, 66, 193, 0.4); }
        .btn-secondary { background: var(--light-gray); color: var(--dark); }
        .btn-secondary:hover { background: var(--gray); color: white; }
        .dark-theme .btn-secondary { background: #2d3239; color: #f8f9fa; }
        .btn-sm { padding: 8px 12px; font-size: 12px; width: auto; }
        .btn-success { background: var(--secondary); color: white; }
        .btn-success:hover { background: #1ba87e; }
        .btn-warning { background: var(--warning); color: white; }
        .btn-warning:hover { background: #e08e3b; }
        .btn-danger { background: var(--danger); color: white; }
        .btn-danger:hover { background: #e03d4b; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 25px; }
        @media (max-width: 1100px) { .grid { grid-template-columns: 1fr; } }
        .form-card { background: white; border-radius: var(--border-radius); padding: 25px; box-shadow: var(--shadow); margin-bottom: 25px; }
        .dark-theme .form-card { background: #1a1d23; }
        .form-card h3 { margin-top: 0; color: var(--primary); border-bottom: 2px solid var(--light-gray); padding-bottom: 10px; font-size: 18px; display: flex; align-items: center; gap: 8px; }
        .dark-theme .form-card h3 { border-bottom-color: #2d3239; color: #f8f9fa; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 600; font-size: 14px; color: var(--dark); }
        .dark-theme .form-group label { color: #f8f9fa; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 12px; border: 2px solid var(--light-gray); border-radius: 8px; font-family: 'Poppins', sans-serif; font-size: 14px; transition: var(--transition); background: white; color: var(--dark); }
        .dark-theme .form-group input, .dark-theme .form-group select, .dark-theme .form-group textarea { background: #2d3239; border-color: #3d4249; color: #f8f9fa; }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline: none; border-color: var(--primary); }
        .alert { padding: 15px 20px; border-radius: 8px; margin-bottom: 25px; font-size: 14px; font-weight: 500; display: flex; align-items: center; gap: 10px; animation: slideDown 0.3s ease; }
        .alert-success { background: rgba(32, 201, 151, 0.15); color: #0f5132; border: 1px solid rgba(32, 201, 151, 0.3); }
        .alert-info { background: rgba(46, 134, 222, 0.15); color: #0c5460; border: 1px solid rgba(46, 134, 222, 0.3); }
        .alert-error { background: rgba(255, 71, 87, 0.15); color: #842029; border: 1px solid rgba(255, 71, 87, 0.3); }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
        .queue-item { display: flex; justify-content: space-between; align-items: center; padding: 15px; background: var(--light); border-radius: 8px; margin-bottom: 10px; border-left: 5px solid var(--gray); transition: var(--transition); }
        .dark-theme .queue-item { background: #2d3239; }
        .queue-item.urgencia-vermelho { border-left-color: var(--danger); background: rgba(255, 71, 87, 0.05); }
        .queue-item.urgencia-amarelo { border-left-color: var(--warning); background: rgba(255, 159, 67, 0.05); }
        .queue-item.urgencia-azul { border-left-color: var(--info); background: rgba(46, 134, 222, 0.05); }
        .queue-item.urgencia-verde { border-left-color: var(--secondary); background: rgba(32, 201, 151, 0.05); }
        .queue-item.chamando { border-left-width: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .senha-badge { background: var(--primary); color: white; padding: 4px 10px; border-radius: 6px; font-weight: 700; font-family: monospace; font-size: 16px; display: inline-block; margin-right: 8px; }
        .tempo-espera { display: inline-block; background: rgba(108, 117, 125, 0.1); color: var(--gray); padding: 3px 8px; border-radius: 6px; font-size: 11px; font-weight: 600; margin-left: 8px; }
        .badge-preferencial { display: inline-flex; align-items: center; gap: 4px; padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: 700; margin-left: 8px; text-transform: uppercase; }
        .badge-preferencial.idoso { background: #e3f2fd; color: #1976d2; }
        .badge-preferencial.gestante { background: #fce4ec; color: #c2185b; }
        .badge-preferencial.deficiente { background: #f3e5f5; color: #7b1fa2; }
        .badge-preferencial.lactante { background: #fff3e0; color: #f57c00; }
        .badge-especialidade { display: inline-block; background: var(--light-gray); color: var(--primary); padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; margin-left: 8px; }
        .dark-theme .badge-especialidade { background: #3d4249; color: #f8f9fa; }
        .actions { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
        .gravidade-selector { display: flex; gap: 10px; margin-bottom: 15px; flex-wrap: wrap; }
        .gravidade-option { flex: 1; padding: 12px; border: 2px solid var(--light-gray); border-radius: 8px; text-align: center; cursor: pointer; transition: var(--transition); font-weight: 600; min-width: 60px; font-size: 13px; }
        .gravidade-option:hover { transform: translateY(-2px); }
        .gravidade-option input { display: none; }
        .gravidade-option.verde { border-color: var(--secondary); color: var(--secondary); }
        .gravidade-option.verde.selected { background: var(--secondary); color: white; }
        .gravidade-option.azul { border-color: var(--info); color: var(--info); }
        .gravidade-option.azul.selected { background: var(--info); color: white; }
        .gravidade-option.amarelo { border-color: var(--warning); color: var(--warning); }
        .gravidade-option.amarelo.selected { background: var(--warning); color: white; }
        .gravidade-option.vermelho { border-color: var(--danger); color: var(--danger); }
        .gravidade-option.vermelho.selected { background: var(--danger); color: white; }
        .history-scroll { max-height: 450px; overflow-y: auto; padding-right: 5px; }
        .history-scroll::-webkit-scrollbar { width: 6px; }
        .history-scroll::-webkit-scrollbar-track { background: var(--light-gray); border-radius: 3px; }
        .history-scroll::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 3px; }
        .preloader { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: white; display: flex; align-items: center; justify-content: center; z-index: 9999; transition: opacity 0.5s; }
        .dark-theme .preloader { background: #1a1d23; }
        .loader { text-align: center; }
        .loader i { font-size: 50px; color: var(--primary); margin-bottom: 20px; animation: bounce 1.5s infinite; }
        @keyframes bounce { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-15px);} }
        .sidebar-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 999; }
        .sidebar-overlay.active { display: block; }
        .ai-assistant-box { background: linear-gradient(135deg, rgba(111, 66, 193, 0.1), rgba(32, 201, 151, 0.1)); border: 1px solid var(--primary-light); border-radius: 8px; padding: 15px; margin-top: 10px; font-size: 13px; color: var(--dark); display: none; animation: fadeIn 0.5s ease; }
        .dark-theme .ai-assistant-box { background: rgba(111, 66, 193, 0.2); border-color: var(--primary); color: #f8f9fa; }
        .ai-assistant-box h5 { margin: 0 0 8px 0; color: var(--primary); display: flex; align-items: center; gap: 8px; font-size: 14px; }
        .ai-suggestion-btn { display: inline-block; background: white; border: 1px solid var(--primary); color: var(--primary); padding: 4px 10px; border-radius: 15px; font-size: 11px; margin-top: 8px; margin-right: 5px; cursor: pointer; transition: 0.2s; }
        .dark-theme .ai-suggestion-btn { background: #2d3239; color: #f8f9fa; border-color: #4d5259; }
        .ai-suggestion-btn:hover { background: var(--primary); color: white; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(-5px); } to { opacity: 1; transform: translateY(0); } }
        .quick-return-card { background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: white; border-radius: var(--border-radius); padding: 20px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(111, 66, 193, 0.3); display: flex; justify-content: space-between; align-items: center; }
        .quick-return-info h4 { margin: 0 0 5px 0; font-size: 16px; }
        .quick-return-info p { margin: 0; opacity: 0.9; font-size: 13px; }
        .quick-return-btn { background: white; color: var(--primary); border: none; padding: 10px 20px; border-radius: 8px; font-weight: 700; cursor: pointer; transition: var(--transition); display: flex; align-items: center; gap: 8px; }
        .quick-return-btn:hover { transform: scale(1.05); box-shadow: 0 4px 10px rgba(0,0,0,0.2); }
    </style>
</head>
<body>
    <div class="preloader" id="preloader">
        <div class="loader"><i class="fas fa-stethoscope"></i><div>Carregando...</div></div>
    </div>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="dashboard-container">
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon"><i class="fas fa-stethoscope"></i></div>
                    <div class="logo-text"><h2>Alfa Saúde</h2><p>Gestão Clínica</p></div>
                </div>
            </div>
            <div class="sidebar-menu">
                <div class="menu-section">
                    <h3>Menu Principal</h3>
                    <ul>
                        <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                        <li><a href="agendamentos.php"><i class="fas fa-calendar-alt"></i> Agenda</a></li>
                        <li><a href="pacientes.php"><i class="fas fa-user-injured"></i> Pacientes</a></li>
                        <li><a href="chamados.php" class="active"><i class="fas fa-bullhorn"></i> Chamadas</a></li>
                    </ul>
                </div>
            </div>
            <div class="user-profile">
                <div class="user-avatar"><div class="avatar-placeholder"><?php echo $usuario_iniciais; ?></div></div>
                <div class="user-info">
                    <h4><?php echo htmlspecialchars($usuario_nome); ?></h4>
                    <p><?php echo ucfirst($usuario_tipo); ?></p>
                </div>
                <div class="user-actions">
                    <a href="logout.php" title="Sair"><i class="fas fa-sign-out-alt"></i></a>
                </div>
            </div>
        </aside>

        <main class="main-content">
            <header class="top-bar">
                <div class="top-bar-left">
                    <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <h2 style="font-size: 18px; font-weight: 600; color: var(--dark);">Painel de Chamadas</h2>
                </div>
                <div class="top-bar-right">
                    <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
                    <a href="tv_chamadas.php" target="_blank" class="btn btn-secondary" style="margin-left: 10px;">
                        <i class="fas fa-tv"></i> Abrir Painel da TV
                    </a>
                </div>
            </header>

            <div class="dashboard-content">
                <?php if ($alerta) echo $alerta; ?>

                <?php if ($ultimo_chamado): ?>
                    <div class="quick-return-card">
                        <div class="quick-return-info">
                            <h4><i class="fas fa-redo"></i> Último Chamado: <?= htmlspecialchars($ultimo_chamado['nome_paciente']) ?></h4>
                            <p>Senha: <strong><?= $ultimo_chamado['senha'] ?></strong> • Local: <?= htmlspecialchars($ultimo_chamado['sala'] ?? $ultimo_chamado['guiche']) ?></p>
                        </div>
                        <form method="POST">
                            <input type="hidden" name="acao" value="chamar_novamente">
                            <input type="hidden" name="id" value="<?= $ultimo_chamado['id'] ?>">
                            <button type="submit" class="quick-return-btn">
                                <i class="fas fa-volume-up"></i> Chamar Novamente
                            </button>
                        </form>
                    </div>
                <?php endif; ?>

                <div class="grid">
                    <div>
                        <div class="form-card">
                            <h3><i class="fas fa-user-plus"></i> Adicionar à Fila</h3>
                            <form method="POST">
                                <input type="hidden" name="acao" value="adicionar">
                                
                                <div class="form-group">
                                    <label>Buscar Paciente na Base de Dados <span style="color:var(--danger)">*</span></label>
                                    <div style="display: flex; gap: 10px;">
                                        <input type="text" list="pacientes-list" name="nome_paciente" placeholder="Digite o nome do paciente..." required autocomplete="off" style="flex: 1;">
                                        <a href="pacientes/novo.php" class="btn btn-secondary" style="width: auto; white-space: nowrap; padding: 12px 15px;" title="Cadastrar novo paciente">
                                            <i class="fas fa-user-plus"></i> Novo
                                        </a>
                                    </div>
                                    <datalist id="pacientes-list">
                                        <?php foreach ($pacientes_cadastrados as $p): ?>
                                            <option value="<?= htmlspecialchars($p['nome']) ?>">
                                        <?php endforeach; ?>
                                    </datalist>
                                </div>
                                
                                <div class="form-group">
                                    <label>Especialidade Médica</label>
                                    <select name="especialidade" required>
                                        <?php foreach ($especialidades as $esp): ?>
                                            <option value="<?= $esp ?>" <?= ($esp == 'Clínico Geral') ? 'selected' : '' ?>><?= $esp ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>Sala ou Guichê</label>
                                    <input type="text" name="local_atendimento" placeholder="Ex: Sala 02" required>
                                </div>
                                
                                <div class="form-group">
                                    <label>Classificação de Risco</label>
                                    <div class="gravidade-selector">
                                        <label class="gravidade-option verde selected">
                                            <input type="radio" name="gravidade" value="verde" checked>
                                            <i class="fas fa-circle"></i> Verde
                                        </label>
                                        <label class="gravidade-option azul">
                                            <input type="radio" name="gravidade" value="azul">
                                            <i class="fas fa-circle"></i> Azul
                                        </label>
                                        <label class="gravidade-option amarelo">
                                            <input type="radio" name="gravidade" value="amarelo">
                                            <i class="fas fa-circle"></i> Amarelo
                                        </label>
                                        <label class="gravidade-option vermelho">
                                            <input type="radio" name="gravidade" value="vermelho">
                                            <i class="fas fa-circle"></i> Vermelho
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label>Atendimento Preferencial</label>
                                    <select name="preferencial">
                                        <option value="nenhum">Nenhum</option>
                                        <option value="idoso">👴 Idoso (60+)</option>
                                        <option value="gestante">🤰 Gestante</option>
                                        <option value="deficiente">♿ Pessoa com Deficiência</option>
                                        <option value="lactante">👶 Lactante (com bebê)</option>
                                    </select>
                                </div>
                                
                                <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center;">
                                    <i class="fas fa-plus"></i> Adicionar à Fila
                                </button>
                            </form>
                        </div>

                        <div class="form-card">
                            <h3><i class="fas fa-list"></i> Fila de Espera</h3>
                            <?php if (count($fila) > 0): ?>
                                <?php foreach ($fila as $item): ?>
                                    <?php 
                                    $local = $item['sala'] ?? $item['guiche'] ?? 'Guichê';
                                    $gravidade = $item['gravidade'] ?? 'verde';
                                    $preferencial = $item['preferencial'] ?? 'nenhum';
                                    $especialidade = $item['especialidade'] ?? '';
                                    $tempo_espera = $item['tempo_espera_minutos'] ?? 0;
                                    ?>
                                    <div class="queue-item urgencia-<?= $gravidade ?> <?= $item['status'] === 'chamando' ? 'chamando' : '' ?>">
                                        <div>
                                            <strong style="font-size: 16px;"><?= htmlspecialchars($item['nome_paciente']) ?></strong>
                                            <?php if ($especialidade): ?>
                                                <span class="badge-especialidade"><?= htmlspecialchars($especialidade) ?></span>
                                            <?php endif; ?>
                                            <?php if ($preferencial !== 'nenhum'): ?>
                                                <span class="badge-preferencial <?= $preferencial ?>">
                                                    <?php 
                                                    $icones = ['idoso' => '👴', 'gestante' => '🤰', 'deficiente' => '♿', 'lactante' => '👶'];
                                                    echo $icones[$preferencial] . ' PREFERENCIAL';
                                                    ?>
                                                </span>
                                            <?php endif; ?>
                                            <span class="tempo-espera"><i class="fas fa-clock"></i> <?= $tempo_espera ?> min</span>
                                            <br>
                                            <span class="senha-badge"><?= $item['senha'] ?></span> 
                                            <small style="color: var(--gray);">• <?= htmlspecialchars($local) ?> • <?= date('H:i', strtotime($item['data_hora'])) ?></small>
                                        </div>
                                        <div class="actions">
                                            <?php if ($item['status'] === 'aguardando'): ?>
                                                <form method="POST"><input type="hidden" name="acao" value="chamar"><input type="hidden" name="id" value="<?= $item['id'] ?>"><button class="btn btn-success btn-sm"><i class="fas fa-volume-up"></i> Chamar na TV</button></form>
                                            <?php else: ?>
                                                <form method="POST"><input type="hidden" name="acao" value="chamar_novamente"><input type="hidden" name="id" value="<?= $item['id'] ?>"><button class="btn btn-warning btn-sm"><i class="fas fa-redo"></i> Retorno</button></form>
                                                <form method="POST"><input type="hidden" name="acao" value="atendido"><input type="hidden" name="id" value="<?= $item['id'] ?>"><button class="btn btn-danger btn-sm"><i class="fas fa-check"></i> Atendido</button></form>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p style="text-align: center; color: var(--gray); padding: 20px;">Nenhum paciente na fila.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div>
                        <div class="form-card" style="position: relative;">
                            <h3><i class="fas fa-cog"></i> Configuração da TV <i class="fas fa-robot" style="margin-left: auto; color: var(--secondary); font-size: 16px;" title="IA Assistente Ativa"></i></h3>
                            
                            <div id="aiAssistantBox" class="ai-assistant-box">
                                <h5><i class="fas fa-magic"></i> Sugestão da IA Qwen</h5>
                                <div id="aiAssistantText">Analisando sua configuração...</div>
                                <div id="aiAssistantActions"></div>
                            </div>

                            <form method="POST" id="configForm">
                                <input type="hidden" name="acao" value="config">
                                <div class="form-group">
                                    <label>Mensagem de Voz (Use [NOME], [SALA] e [ESPECIALIDADE])</label>
                                    <textarea name="mensagem" id="msgInput" rows="3" required><?= htmlspecialchars($config['mensagem_base'] ?? 'O paciente [NOME], da especialidade [ESPECIALIDADE], por favor, dirigir-se ao [SALA].') ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label>URL do Vídeo de Fundo (Opcional)</label>
                                    <input type="text" name="video" id="videoInput" value="<?= htmlspecialchars($config['video_fundo'] ?? '') ?>" placeholder="Ex: https://exemplo.com/video.mp4">
                                </div>
                                <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center;">
                                    <i class="fas fa-save"></i> Salvar Configurações
                                </button>
                            </form>
                        </div>

                        <div class="form-card">
                            <h3><i class="fas fa-history"></i> Histórico de Atendimentos</h3>
                            <?php if (count($historico) > 0): ?>
                                <div class="history-scroll">
                                    <?php foreach ($historico as $item): ?>
                                        <?php 
                                        $local = $item['sala'] ?? $item['guiche'] ?? 'Guichê';
                                        $gravidade = $item['gravidade'] ?? 'verde';
                                        $preferencial = $item['preferencial'] ?? 'nenhum';
                                        $especialidade = $item['especialidade'] ?? '';
                                        $tempo_espera = $item['tempo_espera_minutos'] ?? 0;
                                        $hora_atend = $item['data_ultima_chamada'] ?? $item['data_hora'];
                                        ?>
                                        <div class="queue-item urgencia-<?= $gravidade ?>" style="opacity: 0.75;">
                                            <div>
                                                <strong style="font-size: 15px;"><?= htmlspecialchars($item['nome_paciente']) ?></strong>
                                                <?php if ($especialidade): ?>
                                                    <span class="badge-especialidade"><?= htmlspecialchars($especialidade) ?></span>
                                                <?php endif; ?>
                                                <?php if ($preferencial !== 'nenhum'): ?>
                                                    <span class="badge-preferencial <?= $preferencial ?>">
                                                        <?php 
                                                        $icones = ['idoso' => '👴', 'gestante' => '🤰', 'deficiente' => '♿', 'lactante' => '👶'];
                                                        echo $icones[$preferencial] . ' PREFERENCIAL';
                                                        ?>
                                                    </span>
                                                <?php endif; ?>
                                                <span class="tempo-espera"><i class="fas fa-clock"></i> <?= $tempo_espera ?> min</span>
                                                <br>
                                                <span class="senha-badge" style="background: var(--gray);"><?= $item['senha'] ?></span> 
                                                <small style="color: var(--gray);">• <?= htmlspecialchars($local) ?> • Atendido às <?= date('H:i', strtotime($hora_atend)) ?></small>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <p style="text-align: center; color: var(--gray); padding: 20px;">Nenhum atendimento registrado hoje.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        window.addEventListener('load', function() {
            setTimeout(() => {
                document.getElementById('preloader').style.opacity = '0';
                setTimeout(() => document.getElementById('preloader').style.display = 'none', 500);
            }, 800);
        });

        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('active');
                overlay.classList.toggle('active');
            });
            overlay.addEventListener('click', () => {
                sidebar.classList.remove('active');
                overlay.classList.remove('active');
            });
        }

        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark-theme');
                const icon = themeToggle.querySelector('i');
                if (document.body.classList.contains('dark-theme')) {
                    icon.className = 'fas fa-sun';
                    localStorage.setItem('theme', 'dark');
                } else {
                    icon.className = 'fas fa-moon';
                    localStorage.setItem('theme', 'light');
                }
            });
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-theme');
                themeToggle.querySelector('i').className = 'fas fa-sun';
            }
        }

        document.querySelectorAll('.gravidade-option').forEach(option => {
            option.addEventListener('click', function() {
                document.querySelectorAll('.gravidade-option').forEach(o => o.classList.remove('selected'));
                this.classList.add('selected');
            });
        });

        // IA Assistente
        const msgInput = document.getElementById('msgInput');
        const videoInput = document.getElementById('videoInput');
        const aiBox = document.getElementById('aiAssistantBox');
        const aiText = document.getElementById('aiAssistantText');
        const aiActions = document.getElementById('aiAssistantActions');

        function updateAiAssistance() {
            const msg = msgInput.value.toLowerCase();
            let suggestion = "";
            let actionsHtml = "";

            // Verifica marcadores essenciais
            if (!msg.includes('[nome]') || !msg.includes('[sala]')) {
                suggestion = "Notei que faltam os marcadores [NOME] ou [SALA].";
                actionsHtml = `<button class="ai-suggestion-btn" onclick="applyTemplate()">Usar Modelo Padrão</button>`;
            } 
            // Verifica marcador de especialidade (agora padronizado como [ESPECIALIDADE])
            else if (!msg.includes('[especialidade]')) {
                 suggestion = "Dica: Adicione [ESPECIALIDADE] para anunciar a área médica (ex: Cardiologia).";
                 actionsHtml = `<button class="ai-suggestion-btn" onclick="addEsp()">Adicionar Especialidade</button>`;
            } else {
                suggestion = "Configuração ótima! Mensagem clara e completa.";
                actionsHtml = `<button class="ai-suggestion-btn" style="background:var(--secondary); color:white; border:none;" onclick="document.getElementById('configForm').submit()">Salvar Agora</button>`;
            }

            if (suggestion) {
                aiBox.style.display = 'block';
                aiText.textContent = suggestion;
                aiActions.innerHTML = actionsHtml;
            } else {
                aiBox.style.display = 'none';
            }
        }

        window.applyTemplate = function() {
            msgInput.value = "O paciente [NOME], da especialidade [ESPECIALIDADE], por favor, dirigir-se ao [SALA].";
            updateAiAssistance();
        };
        
        window.addEsp = function() {
             // Adiciona o marcador completo se não existir
             if(!msgInput.value.toUpperCase().includes('[ESPECIALIDADE]')) {
                 msgInput.value += " Especialidade [ESPECIALIDADE].";
             }
             updateAiAssistance();
        }

        msgInput.addEventListener('input', updateAiAssistance);
        videoInput.addEventListener('input', updateAiAssistance);
        updateAiAssistance();
    </script>
</body>
</html>