<?php
// ============================================
// ARQUIVO: licenca.php (Painel do Administrador)
// DESCRIÇÃO: Gerenciamento de licenças com PIN seguro e Bloqueio de Reuso
// ============================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config/database.php';
require_once 'config/auth.php';
verificarLogin();

if (!hasPermissao('admin')) {
    header('Location: dashboard.php?erro=permissao');
    exit;
}

// ============================================
// 🔐 GARANTIR A EXISTÊNCIA DA COLUNA pin_hash E PIN PADRÃO
// ============================================
try {
    $check = $pdo->query("SHOW COLUMNS FROM clinica LIKE 'pin_hash'");
    if ($check->rowCount() == 0) {
        $pdo->exec("ALTER TABLE clinica ADD COLUMN pin_hash VARCHAR(255) DEFAULT NULL");
    }

    $stmt = $pdo->prepare("SELECT pin_hash FROM clinica WHERE id = 1");
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Define PIN padrão se não existir
    if (!$row || empty($row['pin_hash'])) {
        $pin_padrao = '20415490000102';
        $hash = password_hash($pin_padrao, PASSWORD_DEFAULT);
        $update = $pdo->prepare("UPDATE clinica SET pin_hash = ? WHERE id = 1");
        $update->execute([$hash]);
        
        $stmt = $pdo->prepare("SELECT pin_hash FROM clinica WHERE id = 1");
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    $pinHashDB = $row['pin_hash'];
} catch (PDOException $e) {
    die('Erro ao configurar PIN: ' . $e->getMessage());
}

// ============================================
// 🔐 VERIFICAÇÃO DE DESBLOQUEIO (sessão)
// ============================================
$mostrar_overlay = true;
if (isset($_SESSION['pin_verified']) && $_SESSION['pin_verified'] === true) {
    $mostrar_overlay = false;
}

// ============================================
// 🔐 ENDPOINT AJAX PARA VALIDAR PIN
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'verificar_pin') {
    $pin_digitado = $_POST['pin'] ?? '';
    $resposta = ['sucesso' => false];
    if (password_verify($pin_digitado, $pinHashDB)) {
        $_SESSION['pin_verified'] = true;
        $resposta['sucesso'] = true;
    }
    header('Content-Type: application/json');
    echo json_encode($resposta);
    exit;
}

// ============================================
// 🔐 CHAVE SECRETA PARA LICENÇAS
// ============================================
if (!defined('CHAVE_SECRETA_LICENCA')) {
    define('CHAVE_SECRETA_LICENCA', 'ALFA@S4Ud3#2026!Ch@v3Sup3rS3cr3t@');
}

// ============================================
// FUNÇÕES CRIPTOGRÁFICAS ATUALIZADAS
// ============================================
function gerarCodigoLicenca($dias) {
    // Gera código único verificando colisões no histórico
    $tentativas = 0;
    do {
        $parte_dias = strtoupper(str_pad(dechex($dias), 4, '0', STR_PAD_LEFT));
        $parte_time = strtoupper(substr(dechex(time() + rand(0, 9999)), -4));
        $parte_seed = strtoupper(substr(bin2hex(random_bytes(2)), 0, 4));
        
        $dados = $parte_dias . $parte_time . $parte_seed;
        $assinatura = strtoupper(substr(hash_hmac('sha256', $dados, CHAVE_SECRETA_LICENCA), 0, 4));
        
        $codigo = "ALFA-{$parte_dias}-{$parte_time}-{$parte_seed}-{$assinatura}";
        
        global $pdo;
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM licencas_utilizadas WHERE codigo_licenca = ?");
        $stmt->execute([$codigo]);
        $existe = $stmt->fetchColumn() > 0;
        
        $tentativas++;
    } while ($existe && $tentativas < 10);
    
    return $codigo;
}

function validarCodigoLicenca($codigo) {
    $codigo = strtoupper(trim($codigo));
    if (!preg_match('/^ALFA-([A-F0-9]{4})-([A-F0-9]{4})-([A-F0-9]{4})-([A-F0-9]{4})$/', $codigo, $matches)) {
        return ['valido' => false, 'dias' => 0, 'erro' => 'Formato inválido.'];
    }
    
    $dados = $matches[1] . $matches[2] . $matches[3];
    $assinatura_calculada = strtoupper(substr(hash_hmac('sha256', $dados, CHAVE_SECRETA_LICENCA), 0, 4));
    
    if (!hash_equals($assinatura_calculada, $matches[4])) {
        return ['valido' => false, 'dias' => 0, 'erro' => 'Assinatura inválida.'];
    }
    
    return ['valido' => true, 'dias' => hexdec($matches[1]), 'erro' => ''];
}

// ============================================
// DADOS ATUAIS DA LICENÇA
// ============================================
$stmt = $pdo->query("SELECT id, nome, dias_licenca, data_expiracao_licenca, status_licenca FROM clinica WHERE id = 1 LIMIT 1");
$clinica = $stmt->fetch(PDO::FETCH_ASSOC);

$hoje = new DateTime();
try {
    $expiracao = new DateTime($clinica['data_expiracao_licenca']);
} catch (Exception $e) {
    $expiracao = new DateTime();
}

$dias_restantes = max(0, $hoje->diff($expiracao)->days);
$expirou = ($hoje > $expiracao || $clinica['status_licenca'] === 'bloqueado');

$mensagem = '';
$tipo_msg = '';
$codigo_gerado = '';
$dias_gerados_info = 0;

// Verifica mensagens de sessão (ex: após bloqueio manual)
if (isset($_SESSION['msg_sistema'])) {
    $mensagem = $_SESSION['msg_sistema'];
    $tipo_msg = $_SESSION['tipo_msg_sistema'];
    unset($_SESSION['msg_sistema']);
    unset($_SESSION['tipo_msg_sistema']);
}

// ============================================
// PROCESSAR AÇÕES (gerar/ativar/bloquear)
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';
    
    if ($acao === 'gerar_codigo') {
        $dias = isset($_POST['dias_gerar']) ? intval($_POST['dias_gerar']) : 0;
        
        if ($dias > 0 && $dias <= 3650) {
            $codigo_gerado = gerarCodigoLicenca($dias);
            $dias_gerados_info = $dias;
            $mensagem = "✅ Código gerado com sucesso para <strong>{$dias} dias</strong>! Copie e entregue ao cliente.";
            $tipo_msg = 'success';
        } else {
            $mensagem = "❌ Informe uma quantidade válida de dias (entre 1 e 3650).";
            $tipo_msg = 'error';
        }
    }
    
    if ($acao === 'ativar_codigo') {
        $codigo_digitado = strtoupper(trim($_POST['codigo_digitado']));
        $resultado = validarCodigoLicenca($codigo_digitado);
        
        if ($resultado['valido']) {
            // 1. VERIFICAR SE JÁ FOI USADO NO HISTÓRICO
            try {
                $stmt_check = $pdo->prepare("SELECT COUNT(*) as total FROM licencas_utilizadas WHERE codigo_licenca = ?");
                $stmt_check->execute([$codigo_digitado]);
                
                if ($stmt_check->fetch()['total'] > 0) {
                    throw new Exception("🚫 BLOQUEADO: Este código já foi utilizado anteriormente!");
                }
            } catch (Exception $e) {
                $mensagem = $e->getMessage();
                $tipo_msg = 'error';
                $resultado['valido'] = false;
            }

            // Se passou pela verificação, continua
            if ($resultado['valido']) {
                try {
                    $pdo->beginTransaction();
                    
                    $dias_para_adicionar = $resultado['dias'];
                    $base_data = $expirou ? clone $hoje : clone $expiracao;
                    $base_data->modify("+{$dias_para_adicionar} days");
                    $nova_expiracao = $base_data->format('Y-m-d H:i:s');
                    
                    // Atualiza a clínica
                    $update = $pdo->prepare("UPDATE clinica SET 
                        data_expiracao_licenca = ?, 
                        status_licenca = 'ativo', 
                        dias_licenca = GREATEST(0, dias_licenca + ?) 
                    WHERE id = 1");
                    $update->execute([$nova_expiracao, $dias_para_adicionar]);
                    
                    // REGISTRA O USO NO BANCO (IMPEDE REUSO)
                    $usuario_id = $_SESSION['usuario_id'] ?? null;
                    $stmt_reg = $pdo->prepare("INSERT INTO licencas_utilizadas 
                        (codigo_licenca, clinica_id, dias_adicionados, data_uso, usuario_responsavel_id) 
                        VALUES (?, 1, ?, NOW(), ?)");
                    $stmt_reg->execute([$codigo_digitado, $dias_para_adicionar, $usuario_id]);
                    
                    $pdo->commit();
                    
                    $mensagem = "✅ Licença ativada com sucesso! +{$dias_para_adicionar} dias adicionados. Nova expiração: " . $base_data->format('d/m/Y');
                    $tipo_msg = 'success';
                    
                    // Recarrega dados atualizados
                    $stmt = $pdo->query("SELECT id, nome, dias_licenca, data_expiracao_licenca, status_licenca FROM clinica WHERE id = 1 LIMIT 1");
                    $clinica = $stmt->fetch(PDO::FETCH_ASSOC);
                    $expiracao = new DateTime($clinica['data_expiracao_licenca']);
                    $dias_restantes = max(0, $hoje->diff($expiracao)->days);
                    $expirou = false;
                    
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $mensagem = "❌ Erro ao processar: " . $e->getMessage();
                    $tipo_msg = 'error';
                }
            }
        } else {
            $mensagem = "❌ " . $resultado['erro'];
            $tipo_msg = 'error';
        }
    }

    if ($acao === 'bloquear_manual') {
        // BLOQUEIO SEGURO: Muda apenas o status, NÃO APAGA NADA
        $pdo->prepare("UPDATE clinica SET status_licenca = 'bloqueado' WHERE id = 1")->execute();
        
        $_SESSION['msg_sistema'] = "⚠️ Sistema bloqueado manualmente. O acesso dos usuários foi travado.";
        $_SESSION['tipo_msg_sistema'] = 'warning';
        
        header('Location: licenca.php');
        exit;
    }
}

$usuario_nome  = $_SESSION['usuario_nome']  ?? 'Usuário';
$usuario_iniciais = strtoupper(substr($usuario_nome, 0, 2));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Licença do Sistema | Alfa Saúde</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root { --primary: #6f42c1; --primary-dark: #5a32a3; --secondary: #20c997; --danger: #ff4757; --warning: #ff9f43; --light: #f8f9fa; --dark: #343a40; --gray: #6c757d; --light-gray: #e9ecef; --border-radius: 12px; --shadow: 0 4px 20px rgba(0, 0, 0, 0.08); }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:'Poppins',sans-serif; background:linear-gradient(135deg,#f5f7fb 0%,#eef2f7 100%); color:var(--dark); min-height:100vh; }
        body.dark-theme { --light:#1a1d23; --dark:#f8f9fa; --gray:#adb5bd; --light-gray:#2d3239; background:linear-gradient(135deg,#121416 0%,#1a1d23 100%); }
        
        #security-pin-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(15, 23, 42, 0.98); z-index: 9999;
            display: <?php echo $mostrar_overlay ? 'flex' : 'none'; ?>;
            align-items: center; justify-content: center; flex-direction: column;
            backdrop-filter: blur(10px);
        }
        .pin-box {
            background: white; padding: 40px; border-radius: 16px; text-align: center;
            box-shadow: 0 20px 50px rgba(0,0,0,0.5); max-width: 400px; width: 90%;
        }
        .pin-box h2 { color: var(--primary); margin-bottom: 10px; }
        .pin-box p { color: var(--gray); margin-bottom: 20px; font-size: 14px; }
        .pin-input {
            width: 100%; padding: 15px; font-size: 18px; text-align: center;
            border: 2px solid var(--light-gray); border-radius: 8px; margin-bottom: 20px;
            outline: none; letter-spacing: 2px;
        }
        .pin-input:focus { border-color: var(--primary); }
        .pin-error { color: var(--danger); font-size: 13px; margin-top: 10px; display: none; }
        
        .dashboard-container { display:flex; min-height:100vh; }
        .sidebar { width:280px; background:linear-gradient(180deg,var(--primary) 0%,var(--primary-dark) 100%); color:white; padding:25px; position:fixed; height:100vh; overflow-y: auto; }
        .logo { display:flex; align-items:center; gap:15px; margin-bottom:40px; }
        .logo-icon { width:45px; height:45px; background:rgba(255,255,255,0.2); border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:20px; }
        .menu-section a { display:flex; align-items:center; gap:15px; padding:12px 15px; color:rgba(255,255,255,0.85); text-decoration:none; border-radius:8px; margin-bottom:5px; transition:0.3s; }
        .menu-section a:hover, .menu-section a.active { background:rgba(255,255,255,0.15); color:white; }
        
        .main-content { flex:1; margin-left:280px; display:flex; flex-direction:column; }
        .top-bar { background:white; padding:15px 30px; box-shadow:var(--shadow); display:flex; align-items:center; min-height:70px; position: sticky; top: 0; z-index: 10; }
        .dark-theme .top-bar { background:#1a1d23; }
        .dashboard-content { padding:30px; flex:1; }
        
        .license-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 25px; margin-bottom: 30px; }
        .card { background: white; border-radius: var(--border-radius); padding: 30px; box-shadow: var(--shadow); text-align: center; position: relative; overflow: hidden; }
        .dark-theme .card { background: #1a1d23; }
        .card::before { content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 4px; background: var(--primary); }
        .card.warning::before { background: var(--warning); }
        .card.danger::before { background: var(--danger); }
        .card.success::before { background: var(--secondary); }
        
        .card-icon { width: 60px; height: 60px; border-radius: 50%; background: rgba(111,66,193,0.1); color: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 24px; margin: 0 auto 15px; }
        .card.warning .card-icon { background: rgba(255,159,67,0.1); color: var(--warning); }
        .card.danger .card-icon { background: rgba(255,71,87,0.1); color: var(--danger); }
        .card.success .card-icon { background: rgba(32,201,151,0.1); color: var(--secondary); }
        
        .card-value { font-size: 32px; font-weight: 700; color: var(--dark); margin-bottom: 5px; }
        .dark-theme .card-value { color: #f8f9fa; }
        .card-label { font-size: 14px; color: var(--gray); font-weight: 500; }
        
        .action-box { background: white; border-radius: var(--border-radius); padding: 30px; box-shadow: var(--shadow); margin-bottom: 25px; }
        .dark-theme .action-box { background: #1a1d23; }
        .action-box h3 { font-size: 18px; font-weight: 600; margin-bottom: 15px; display: flex; align-items: center; gap: 10px; }
        .action-box p { color: var(--gray); font-size: 14px; margin-bottom: 20px; line-height: 1.5; }
        
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 500; color: var(--gray); font-size: 14px; }
        .form-group input { width: 100%; padding: 12px 15px; border: 2px solid var(--light-gray); border-radius: 8px; font-family: 'Poppins', sans-serif; font-size: 16px; text-transform: uppercase; letter-spacing: 2px; font-weight: 600; transition: 0.3s; }
        .dark-theme .form-group input { background: #2d3239; border-color: #3d4249; color: #f8f9fa; }
        .form-group input:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(111,66,193,0.15); }
        
        .btn { padding: 12px 24px; border: none; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: 0.3s; text-decoration: none; width: 100%; justify-content: center; }
        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-dark); transform: translateY(-2px); }
        .btn-danger { background: var(--danger); color: white; }
        .btn-danger:hover { background: #e04050; transform: translateY(-2px); }
        .btn-success { background: var(--secondary); color: white; }
        .btn-success:hover { background: #1baa80; transform: translateY(-2px); }
        
        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; display: flex; align-items: center; gap: 10px; }
        .alert-success { background: rgba(32,201,151,0.15); color: #0f5132; border: 1px solid rgba(32,201,151,0.3); }
        .alert-error { background: rgba(255,71,87,0.15); color: #842029; border: 1px solid rgba(255,71,87,0.3); }
        .alert-warning { background: rgba(255,159,67,0.15); color: #856404; border: 1px solid rgba(255,159,67,0.3); }
        
        .code-display { 
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); 
            border: 3px dashed var(--primary); 
            padding: 20px; 
            border-radius: 8px; 
            font-size: 22px; 
            font-weight: 700; 
            color: var(--primary); 
            text-align: center; 
            margin: 15px 0; 
            letter-spacing: 3px; 
            font-family: 'Courier New', monospace;
            user-select: all;
        }
        .dark-theme .code-display { background: #2d3239; }

        .info-box {
            background: rgba(46,134,222,0.08);
            border-left: 4px solid #2e86de;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            font-size: 13px;
            color: #0c5460;
            display: flex;
            align-items: flex-start;
            gap: 10px;
        }
        .info-box i { color: #2e86de; margin-top: 2px; }
    </style>
</head>
<body>
    
    <!-- OVERLAY DE SEGURANÇA -->
    <div id="security-pin-overlay">
        <div class="pin-box">
            <i class="fas fa-shield-alt" style="font-size: 40px; color: var(--primary); margin-bottom: 15px;"></i>
            <h2>Acesso Restrito</h2>
            <p>Digite o PIN de segurança administrativo para visualizar esta área.</p>
            <input type="password" id="pinInput" class="pin-input" placeholder="Digite o CNPJ Master" onkeypress="handleEnter(event)">
            <button onclick="checkPin()" class="btn btn-primary"><i class="fas fa-lock-open"></i> Desbloquear</button>
            <div id="pinError" class="pin-error"><i class="fas fa-exclamation-circle"></i> PIN Incorreto!</div>
        </div>
    </div>

    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-stethoscope"></i></div>
                <div><h2 style="font-size:18px;">Alfa Saúde</h2><p style="font-size:12px; opacity:0.8;">Painel Admin</p></div>
            </div>
            <div class="menu-section">
                <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
                <a href="usuarios.php"><i class="fas fa-user-md"></i> Usuários</a>
                <a href="licenca.php" class="active"><i class="fas fa-cogs"></i> Gerenciar Licenças</a>
                <a href="logout.php" style="margin-top: 30px; color: #ff4757;"><i class="fas fa-sign-out-alt"></i> Sair</a>
            </div>
        </aside>

        <main class="main-content">
            <header class="top-bar">
                <h2 style="font-size:18px; font-weight:600;"><i class="fas fa-shield-alt" style="color:var(--primary);"></i> Gerenciamento de Licença Criptográfica</h2>
            </header>

            <div class="dashboard-content">
                <?php if ($mensagem): ?>
                    <div class="alert alert-<?php echo $tipo_msg; ?>">
                        <i class="fas fa-<?php echo $tipo_msg === 'success' ? 'check-circle' : ($tipo_msg === 'warning' ? 'exclamation-triangle' : 'exclamation-circle'); ?>"></i> 
                        <span><?php echo $mensagem; ?></span>
                    </div>
                <?php endif; ?>

                <div class="info-box">
                    <i class="fas fa-info-circle"></i>
                    <div>
                        <strong>Como funciona:</strong> Digite a quantidade de dias desejada e clique em gerar. O sistema criará um código único. Ao ativar, o código será registrado no banco e <u>não poderá ser usado novamente</u>. O botão de bloquear apenas trava o acesso, sem apagar históricos.
                    </div>
                </div>

                <div class="license-grid">
                    <div class="card <?php echo $expirou ? 'danger' : ($dias_restantes <= 7 ? 'warning' : 'success'); ?>">
                        <div class="card-icon"><i class="fas fa-<?php echo $expirou ? 'lock' : 'shield-check'; ?>"></i></div>
                        <div class="card-value"><?php echo $expirou ? 'BLOQUEADO' : 'ATIVO'; ?></div>
                        <div class="card-label">Status do Sistema</div>
                    </div>

                    <div class="card <?php echo $dias_restantes <= 7 ? 'warning' : 'success'; ?>">
                        <div class="card-icon"><i class="fas fa-hourglass-half"></i></div>
                        <div class="card-value"><?php echo $expirou ? '0' : $dias_restantes; ?></div>
                        <div class="card-label">Dias Restantes</div>
                    </div>

                    <div class="card">
                        <div class="card-icon"><i class="fas fa-calendar-alt"></i></div>
                        <div class="card-value" style="font-size: 22px;"><?php echo $expiracao->format('d/m/Y'); ?></div>
                        <div class="card-label">Data de Expiração</div>
                    </div>
                </div>

                <div class="license-grid">
                    <!-- GERAR CÓDIGO -->
                    <div class="action-box">
                        <h3><i class="fas fa-magic" style="color:var(--primary);"></i> 1. Gerar Código de Licença</h3>
                        <p>Digite a quantidade de dias desejada. O código gerado será válido exatamente por esse período.</p>
                        <form method="POST">
                            <input type="hidden" name="acao" value="gerar_codigo">
                            <div class="form-group">
                                <label>Quantidade de dias para adicionar:</label>
                                <input type="number" name="dias_gerar" min="1" max="3650" placeholder="Ex: 90" required style="text-transform: none; letter-spacing: normal; font-family: 'Poppins', sans-serif;">
                            </div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-key"></i> Gerar Código Criptográfico</button>
                        </form>
                        
                        <?php if (!empty($codigo_gerado)): ?>
                            <div class="code-display">
                                <?php echo $codigo_gerado; ?>
                            </div>
                            <p style="font-size:13px; color:var(--primary); text-align:center; margin-top: 10px; font-weight: 600;">
                                <i class="fas fa-check-circle"></i> Este código foi gerado para <u><?php echo $dias_gerados_info; ?> dias</u>.
                            </p>
                            <p style="font-size:12px; color:var(--gray); text-align:center; margin-top: 5px;">
                                <i class="fas fa-copy" style="margin-right: 5px;"></i> Clique no código acima para selecionar e copiar
                            </p>
                        <?php endif; ?>
                    </div>

                    <!-- TESTAR/ATIVAR COM CÓDIGO -->
                    <div class="action-box">
                        <h3><i class="fas fa-vial" style="color:var(--warning);"></i> 2. Testar ou Ativar Código</h3>
                        <p>Use este campo para validar se um código gerado está correto antes de enviar ao cliente, ou para ativar manualmente nesta máquina.</p>
                        <form method="POST">
                            <input type="hidden" name="acao" value="ativar_codigo">
                            <div class="form-group">
                                <label>Código de Licença:</label>
                                <input type="text" name="codigo_digitado" placeholder="ALFA-XXXX-XXXX-XXXX-XXXX" required>
                            </div>
                            <button type="submit" class="btn btn-success"><i class="fas fa-check-circle"></i> Validar e Ativar</button>
                        </form>
                    </div>
                </div>

                <!-- ZONA DE PERIGO -->
                <div class="action-box" style="border-left: 4px solid var(--danger);">
                    <h3><i class="fas fa-exclamation-triangle" style="color:var(--danger);"></i> Zona de Perigo</h3>
                    <p>Use esta opção apenas em emergências para travar o acesso de todos os usuários da clínica imediatamente. <strong>Isso não apaga licenças já utilizadas.</strong></p>
                    <form method="POST" onsubmit="return confirm('⚠️ ATENÇÃO: Isso bloqueará o sistema para TODOS os usuários imediatamente. Deseja continuar?');">
                        <input type="hidden" name="acao" value="bloquear_manual">
                        <button type="submit" class="btn btn-danger"><i class="fas fa-lock"></i> Bloquear Sistema Agora</button>
                    </form>
                </div>

            </div>
        </main>
    </div>

    <script>
        async function checkPin() {
            const input = document.getElementById('pinInput').value;
            const errorDiv = document.getElementById('pinError');
            
            if (!input.trim()) {
                errorDiv.style.display = 'block';
                errorDiv.textContent = 'Digite o PIN antes de continuar.';
                return;
            }
            
            try {
                const formData = new FormData();
                formData.append('acao', 'verificar_pin');
                formData.append('pin', input);
                
                const response = await fetch(window.location.href, {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                
                if (data.sucesso) {
                    sessionStorage.setItem('licenca_unlocked', 'true');
                    const overlay = document.getElementById('security-pin-overlay');
                    overlay.style.opacity = '0';
                    setTimeout(() => {
                        overlay.style.display = 'none';
                        location.reload();
                    }, 500);
                } else {
                    errorDiv.style.display = 'block';
                    errorDiv.textContent = '❌ PIN incorreto! Tente novamente.';
                    document.getElementById('pinInput').value = '';
                    document.getElementById('pinInput').focus();
                }
            } catch (error) {
                errorDiv.style.display = 'block';
                errorDiv.textContent = 'Erro na comunicação com o servidor.';
            }
        }

        function handleEnter(e) {
            if (e.key === 'Enter') checkPin();
        }

        window.addEventListener('load', function() {
            <?php if (!$mostrar_overlay) : ?>
                document.getElementById('security-pin-overlay').style.display = 'none';
                sessionStorage.setItem('licenca_unlocked', 'true');
            <?php endif; ?>
        });

        if (localStorage.getItem('theme') === 'dark') { 
            document.body.classList.add('dark-theme'); 
        }
    </script>
</body>
</html>