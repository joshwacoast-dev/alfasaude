<?php
// ============================================
// ARQUIVO: login.php
// DESCRIÇÃO: Página de login com tema lilás e branco (clean)
// ============================================

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config/database.php';
require_once 'config/auth.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    if (login($email, $senha)) {
        header('Location: dashboard.php');
        exit;
    } else {
        $erro = "E-mail ou senha inválidos.";
    }
}

$clinica = [];
if (function_exists('getClinica')) {
    $clinica = getClinica();
}
// Cores fixas em tons de lilás (mesmo se vier do banco, forçamos a paleta)
$cor_primaria   = '#7c3aed';   // lilás forte
$cor_secundaria = '#a78bfa';   // lilás claro
$cor_fundo      = '#f5f3ff';   // fundo lilás bem clarinho
$nome_sistema   = !empty($clinica['nome']) ? $clinica['nome'] : 'Alfa Saúde';
$logo           = !empty($clinica['logo']) ? $clinica['logo'] : '';
$telefone       = !empty($clinica['telefone']) ? $clinica['telefone'] : '(85) 2028-4584';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Login · <?php echo htmlspecialchars($nome_sistema); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        body {
            min-height:100vh;
            display:flex;
            background: <?php echo $cor_fundo; ?>;
        }

        /* LAYOUT SPLIT 50/50 */
        .split-screen {
            display:flex;
            width:100%;
            min-height:100vh;
        }

        /* LADO ESQUERDO – FORMULÁRIO */
        .split-left {
            flex:1;
            display:flex;
            flex-direction:column;
            justify-content:center;
            align-items:center;
            padding:2rem;
            background:white;
            position:relative;
            overflow:hidden;
        }
        .split-left::before {
            content:"";
            position:absolute;
            top:-50%;
            right:-30%;
            width:600px;
            height:600px;
            background:radial-gradient(circle, rgba(124,58,237,0.04) 0%, transparent 70%);
            border-radius:50%;
            pointer-events:none;
        }
        .split-left::after {
            content:"";
            position:absolute;
            bottom:-40%;
            left:-20%;
            width:500px;
            height:500px;
            background:radial-gradient(circle, rgba(167,139,250,0.05) 0%, transparent 70%);
            border-radius:50%;
            pointer-events:none;
        }

        /* LADO DIREITO – DESTAQUE LILÁS */
        .split-right {
            flex:1;
            background: linear-gradient(145deg, <?php echo $cor_primaria; ?>, <?php echo $cor_secundaria; ?>);
            display:flex;
            align-items:center;
            justify-content:center;
            position:relative;
            overflow:hidden;
            padding:2rem;
        }
        .split-right::before {
            content:"";
            position:absolute;
            top:-30%;
            right:-20%;
            width:400px;
            height:400px;
            background:rgba(255,255,255,0.08);
            border-radius:50%;
        }
        .split-right::after {
            content:"";
            position:absolute;
            bottom:-20%;
            left:-10%;
            width:300px;
            height:300px;
            background:rgba(255,255,255,0.06);
            border-radius:50%;
        }

        .right-content {
            position:relative;
            z-index:2;
            color:white;
            text-align:center;
            max-width:80%;
            animation:fadeIn 1s ease;
        }
        .right-content .icon-big {
            font-size:4rem;
            margin-bottom:1rem;
            display:block;
            filter:drop-shadow(0 8px 16px rgba(0,0,0,0.1));
        }
        .right-content h2 {
            font-size:2.8rem;
            font-weight:800;
            margin-bottom:0.8rem;
            letter-spacing:-0.5px;
            text-shadow:0 4px 20px rgba(0,0,0,0.15);
        }
        .right-content p {
            font-size:1.2rem;
            opacity:0.95;
            line-height:1.6;
            font-weight:300;
        }
        .right-content .highlight {
            display:inline-block;
            background:rgba(255,255,255,0.18);
            backdrop-filter:blur(6px);
            padding:0.6rem 1.8rem;
            border-radius:40px;
            border:1px solid rgba(255,255,255,0.25);
            margin-top:1.8rem;
            font-weight:500;
            font-size:0.95rem;
        }

        /* CARD DE LOGIN */
        .login-card {
            width:100%;
            max-width:440px;
            background:white;
            padding:2.8rem 2.5rem;
            border-radius:32px;
            box-shadow:0 20px 60px -10px rgba(124,58,237,0.25);
            position:relative;
            z-index:2;
            transition:transform 0.25s ease;
        }
        .login-card:hover {
            transform:translateY(-4px);
        }

        .logo-area {
            display:flex;
            align-items:center;
            gap:12px;
            margin-bottom:2rem;
        }
        .logo-img {
            height:50px;
            width:auto;
        }
        .brand-text {
            font-size:1.8rem;
            font-weight:800;
            background:linear-gradient(135deg, <?php echo $cor_primaria; ?>, <?php echo $cor_secundaria; ?>);
            -webkit-background-clip:text;
            -webkit-text-fill-color:transparent;
            letter-spacing:-0.5px;
        }

        .login-title {
            font-size:2rem;
            font-weight:700;
            color:#1e1b2e;
            margin-bottom:0.3rem;
        }
        .login-sub {
            color:#6b5b7a;
            margin-bottom:2rem;
            font-size:0.95rem;
            border-left:4px solid <?php echo $cor_primaria; ?>;
            padding-left:14px;
            background:rgba(124,58,237,0.04);
            border-radius:0 12px 12px 0;
            line-height:1.5;
        }

        .form-group {
            margin-bottom:1.5rem;
        }
        .form-group label {
            display:block;
            margin-bottom:6px;
            color:#4a3a5a;
            font-weight:600;
            font-size:0.85rem;
            text-transform:uppercase;
            letter-spacing:0.4px;
        }
        .form-group input {
            width:100%;
            padding:14px 18px;
            border:2px solid #ede9fe;
            border-radius:16px;
            font-size:1rem;
            transition:all 0.2s;
            background:#faf9ff;
            color:#1e1b2e;
            outline:none;
        }
        .form-group input:focus {
            border-color:<?php echo $cor_primaria; ?>;
            box-shadow:0 0 0 4px rgba(124,58,237,0.12);
            background:white;
        }

        .login-btn {
            width:100%;
            padding:16px;
            background:linear-gradient(145deg, <?php echo $cor_primaria; ?>, <?php echo $cor_secundaria; ?>);
            color:white;
            border:none;
            border-radius:20px;
            font-size:1.05rem;
            font-weight:700;
            cursor:pointer;
            transition:all 0.3s;
            margin-top:10px;
            box-shadow:0 10px 25px -5px <?php echo $cor_primaria; ?>80;
            display:flex;
            align-items:center;
            justify-content:center;
            gap:10px;
            letter-spacing:0.3px;
        }
        .login-btn:hover {
            transform:scale(1.02);
            box-shadow:0 15px 30px -5px <?php echo $cor_primaria; ?>A0;
            filter:brightness(1.05);
        }

        .error-message {
            background:#fef2f2;
            border-left:5px solid #dc2626;
            color:#991b1b;
            padding:14px 18px;
            border-radius:12px;
            margin-bottom:1.8rem;
            font-weight:500;
            display:flex;
            align-items:center;
            gap:10px;
            font-size:0.95rem;
            animation:shake 0.4s ease;
        }

        @keyframes shake {
            0%,100%{transform:translateX(0)}
            25%{transform:translateX(-5px)}
            75%{transform:translateX(5px)}
        }
        @keyframes fadeIn {
            from{opacity:0;transform:translateY(20px)}
            to{opacity:1;transform:translateY(0)}
        }

        .health-icons {
            display:flex;
            justify-content:center;
            gap:14px;
            margin-top:2rem;
            font-size:1.3rem;
            color:#c4b5d4;
        }
        .copyright {
            text-align:center;
            margin-top:18px;
            color:#a99bb5;
            font-size:0.75rem;
        }

        /* RESPONSIVIDADE */
        @media (max-width:900px) {
            .split-screen { flex-direction:column; }
            .split-left, .split-right { flex:none; width:100%; }
            .split-right { min-height:240px; order:-1; padding:1.5rem; }
            .right-content h2 { font-size:2.2rem; }
            .right-content p { font-size:1rem; }
            .login-card { max-width:500px; padding:2rem; }
        }
        @media (max-width:480px) {
            .split-left { padding:1rem; }
            .login-card { padding:1.5rem; border-radius:24px; }
            .brand-text { font-size:1.4rem; }
            .login-title { font-size:1.6rem; }
            .right-content h2 { font-size:1.8rem; }
            .right-content .icon-big { font-size:3rem; }
        }
    </style>
</head>
<body>
<div class="split-screen">
    <!-- LADO ESQUERDO – FORMULÁRIO -->
    <div class="split-left">
        <div class="login-card">
            <div class="logo-area">
                <?php if (!empty($logo) && file_exists('assets/img/' . $logo)): ?>
                    <img src="assets/img/<?php echo $logo; ?>" alt="<?php echo htmlspecialchars($nome_sistema); ?>" class="logo-img">
                <?php else: ?>
                    <span class="brand-text">🏥 <?php echo htmlspecialchars($nome_sistema); ?></span>
                <?php endif; ?>
            </div>

            <h1 class="login-title">Bem-vindo</h1>
            <div class="login-sub">
                Acesse sua conta para gerenciar agendamentos, pacientes e muito mais.
            </div>

            <?php if (isset($erro)): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($erro); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="email">E-mail</label>
                    <input type="email" id="email" name="email" placeholder="seu@email.com" required autofocus value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label for="senha">Senha</label>
                    <input type="password" id="senha" name="senha" placeholder="••••••••" required>
                </div>
                <button type="submit" class="login-btn">
                    🔐 ENTRAR NO SISTEMA
                </button>
            </form>

            <div class="health-icons">
                <span>⚕️</span> <span>💊</span> <span>🏥</span> <span>🩺</span> <span>📋</span>
            </div>

            <div class="copyright">
                © <?php echo date('Y'); ?> <?php echo htmlspecialchars($nome_sistema); ?> · Gestão em Saúde
            </div>
        </div>
    </div>

    <!-- LADO DIREITO – DESTAQUE LILÁS -->
    <div class="split-right">
        <div class="right-content">
            <span class="icon-big">🩺</span>
            <h2>Saúde e bem-estar</h2>
            <p>Atendimento humanizado, tecnologia a seu favor.<br>Agende consultas, acesse prontuários e muito mais.</p>
            <span class="highlight"> SAC <?php echo htmlspecialchars($telefone); ?> </span>
        </div>
    </div>
</div>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<script>
    // Auto-focus
    document.getElementById('email').focus();

    // Atalhos de teste
    let ctrlPressed = false;
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Control') ctrlPressed = true;

        // Ctrl+U = admin
        if (e.ctrlKey && e.key === 'u') {
            e.preventDefault();
            document.getElementById('email').value = 'admin@alfasaude.com';
            document.getElementById('senha').value = 'admin';
            const btn = document.querySelector('.login-btn');
            const orig = btn.innerHTML;
            btn.style.background = 'linear-gradient(145deg, #4CAF50, #2E7D32)';
            btn.innerHTML = '✓ ADMIN INSERIDO';
            setTimeout(() => {
                btn.style.background = 'linear-gradient(145deg, <?php echo $cor_primaria; ?>, <?php echo $cor_secundaria; ?>)';
                btn.innerHTML = orig;
            }, 1500);
        }

        // Ctrl+I = médico
        if (e.ctrlKey && e.key === 'i') {
            e.preventDefault();
            document.getElementById('email').value = 'medico@exemplo.com';
            document.getElementById('senha').value = 'medico123';
            const btn = document.querySelector('.login-btn');
            const orig = btn.innerHTML;
            btn.style.background = 'linear-gradient(145deg, #2196F3, #1976D2)';
            btn.innerHTML = '✓ TESTE INSERIDO';
            setTimeout(() => {
                btn.style.background = 'linear-gradient(145deg, <?php echo $cor_primaria; ?>, <?php echo $cor_secundaria; ?>)';
                btn.innerHTML = orig;
            }, 1500);
        }
    });
    document.addEventListener('keyup', function(e) {
        if (e.key === 'Control') ctrlPressed = false;
    });

    // Mostrar senha com Ctrl pressionado
    const senhaField = document.getElementById('senha');
    senhaField.addEventListener('mousedown', function(e) {
        if (ctrlPressed) this.type = 'text';
    });
    senhaField.addEventListener('mouseup', function() {
        if (this.type === 'text') this.type = 'password';
    });
    senhaField.addEventListener('mouseleave', function() {
        if (this.type === 'text') this.type = 'password';
    });

    // Prevenir envio duplo
    const form = document.querySelector('form');
    let isSubmitting = false;
    form.addEventListener('submit', function(e) {
        if (isSubmitting) { e.preventDefault(); return; }
        isSubmitting = true;
        const btn = document.querySelector('.login-btn');
        const orig = btn.innerHTML;
        btn.innerHTML = '⏳ PROCESSANDO...';
        btn.style.opacity = '0.8';
        btn.style.cursor = 'wait';
        setTimeout(() => {
            isSubmitting = false;
            btn.innerHTML = orig;
            btn.style.opacity = '1';
            btn.style.cursor = 'pointer';
        }, 5000);
    });
</script>
</body>
</html>