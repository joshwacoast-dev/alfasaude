<?php
// ============================================
// ARQUIVO: pacientes.php (Versão Aprimorada)
// DESCRIÇÃO: Listagem com chamada direta, paginação e design responsivo
// ============================================

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config/database.php';
require_once 'config/auth.php';
verificarLogin();

// ============================================
// CONFIGURAÇÕES DE PAGINAÇÃO
// ============================================
$itens_por_pagina = 10;
$pagina_atual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$offset = ($pagina_atual - 1) * $itens_por_pagina;

// ============================================
// PROCESSAR CHAMADA DIRETA
// ============================================
$msg_chamada = '';
$tipo_chamada = '';

// Geração de token CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao_chamar'])) {
    // Verifica CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $msg_chamada = 'Erro de segurança. Tente novamente.';
        $tipo_chamada = 'error';
    } else {
        $nome_paciente = trim($_POST['nome_paciente'] ?? '');
        $especialidade_chamada = trim($_POST['especialidade_chamada'] ?? 'Clínico Geral');

        if (empty($nome_paciente)) {
            $msg_chamada = 'Nome do paciente não informado.';
            $tipo_chamada = 'error';
        } else {
            // Verifica se já está na fila
            $stmt_check = $pdo->prepare("SELECT id FROM fila_chamadas WHERE UPPER(nome_paciente) = ? AND status IN ('aguardando', 'chamando')");
            $stmt_check->execute([strtoupper($nome_paciente)]);
            $fila_record = $stmt_check->fetch();

            if ($fila_record) {
                // Atualiza status e especialidade
                $pdo->prepare("UPDATE fila_chamadas SET status = 'chamando', data_ultima_chamada = NOW(), especialidade = ? WHERE id = ?")
                    ->execute([$especialidade_chamada, $fila_record['id']]);
                $msg_chamada = "Paciente <strong>" . htmlspecialchars($nome_paciente) . "</strong> chamado para <strong>" . htmlspecialchars($especialidade_chamada) . "</strong>!";
                $tipo_chamada = 'success';
            } else {
                // Adiciona novo na fila com status 'chamando'
                $stmt_count = $pdo->query("SELECT COUNT(*) as total FROM fila_chamadas WHERE DATE(data_hora) = CURDATE()");
                $senha = 'A' . str_pad(($stmt_count->fetch()['total'] + 1), 3, '0', STR_PAD_LEFT);

                try {
                    $pdo->prepare("INSERT INTO fila_chamadas (nome_paciente, senha, sala, gravidade, preferencial, especialidade, status, data_ultima_chamada) 
                                   VALUES (?, ?, 'Consultório', 'verde', 'nenhum', ?, 'chamando', NOW())")
                                   ->execute([$nome_paciente, $senha, $especialidade_chamada]);
                    $msg_chamada = "Paciente <strong>" . htmlspecialchars($nome_paciente) . "</strong> adicionado e chamado para <strong>" . htmlspecialchars($especialidade_chamada) . "</strong>!";
                    $tipo_chamada = 'success';
                } catch (PDOException $e) {
                    $msg_chamada = 'Erro ao adicionar paciente: ' . $e->getMessage();
                    $tipo_chamada = 'error';
                }
            }
        }
    }
}

// ============================================
// FILTROS E BUSCA
// ============================================
$busca = $_GET['busca'] ?? '';
$filtro_ativo = $_GET['filtro_ativo'] ?? '1';

// Consulta com contagem total (para paginação)
$sql_count = "SELECT COUNT(*) as total FROM pacientes p WHERE p.ativo = :ativo";
$params_count = [':ativo' => $filtro_ativo];
if (!empty($busca)) {
    $sql_count .= " AND (p.nome LIKE :busca OR p.cpf LIKE :busca OR p.telefone LIKE :busca OR p.email LIKE :busca)";
    $params_count[':busca'] = "%$busca%";
}
$stmt_count = $pdo->prepare($sql_count);
$stmt_count->execute($params_count);
$total_registros = $stmt_count->fetch()['total'];
$total_paginas = ceil($total_registros / $itens_por_pagina);

// Consulta principal com paginação
$sql = "SELECT p.*, f.fila_status, f.fila_gravidade, f.fila_senha, f.especialidade as fila_especialidade
        FROM pacientes p 
        LEFT JOIN (
            SELECT nome_paciente, status as fila_status, gravidade as fila_gravidade, senha as fila_senha, especialidade
            FROM fila_chamadas 
            WHERE status IN ('aguardando', 'chamando')
        ) f ON UPPER(p.nome) = UPPER(f.nome_paciente)
        WHERE p.ativo = :ativo";
$params = [':ativo' => $filtro_ativo];

if (!empty($busca)) {
    $sql .= " AND (p.nome LIKE :busca OR p.cpf LIKE :busca OR p.telefone LIKE :busca OR p.email LIKE :busca)";
    $params[':busca'] = "%$busca%";
}

$sql .= " ORDER BY p.nome ASC LIMIT :limit OFFSET :offset";
$params[':limit'] = $itens_por_pagina;
$params[':offset'] = $offset;

$stmt = $pdo->prepare($sql);
$stmt->bindValue(':limit', $itens_por_pagina, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
foreach ($params as $key => &$val) {
    if ($key !== ':limit' && $key !== ':offset') {
        $stmt->bindValue($key, $val);
    }
}
$stmt->execute();
$pacientes = $stmt->fetchAll();

// ============================================
// DADOS DO USUÁRIO
// ============================================
$usuario_nome  = $_SESSION['usuario_nome']  ?? 'Usuário';
$usuario_tipo  = $_SESSION['usuario_tipo']  ?? 'usuario';
$usuario_iniciais = strtoupper(substr($usuario_nome, 0, 2));

// Contagem de pacientes na fila para exibição
$fila_contagem = $pdo->query("SELECT COUNT(*) FROM fila_chamadas WHERE status IN ('aguardando', 'chamando')")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pacientes | Alfa Saúde</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ===== RESET E VARIÁVEIS ===== */
        :root {
            --primary: #6f42c1; --primary-dark: #5a32a3; --primary-light: #8b5cf6;
            --secondary: #20c997; --danger: #ff4757; --warning: #ff9f43; --info: #2e86de;
            --light: #f8f9fa; --dark: #343a40; --gray: #6c757d; --light-gray: #e9ecef;
            --border-radius: 12px; --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --sidebar-width: 280px; --topbar-height: 70px;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:'Poppins',sans-serif; background:#f5f7fb; color:var(--dark); line-height:1.6; min-height:100vh; }
        body.dark-theme { --light:#1a1d23; --dark:#f8f9fa; --gray:#adb5bd; --light-gray:#2d3239; background:#121416; color:#f8f9fa; }

        /* ===== SIDEBAR ===== */
        .dashboard-container { display:flex; min-height:100vh; }
        .sidebar {
            width:var(--sidebar-width); background:linear-gradient(180deg,var(--primary),var(--primary-dark));
            color:white; position:fixed; height:100vh; z-index:1000;
            transition:transform 0.3s ease; overflow-y:auto;
            box-shadow:3px 0 20px rgba(0,0,0,0.1);
        }
        .sidebar-header { padding:25px; border-bottom:1px solid rgba(255,255,255,0.15); }
        .logo { display:flex; align-items:center; gap:15px; }
        .logo-icon { width:45px; height:45px; background:rgba(255,255,255,0.2); border-radius:10px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
        .logo-text h2 { font-size:18px; font-weight:700; margin:0; }
        .logo-text p { font-size:12px; opacity:0.9; margin:0; }
        .sidebar-menu { padding:20px 0; }
        .menu-section { margin-bottom:25px; padding:0 20px; }
        .menu-section h3 { font-size:11px; text-transform:uppercase; letter-spacing:1.5px; opacity:0.7; margin-bottom:15px; }
        .menu-section ul { list-style:none; }
        .menu-section a {
            display:flex; align-items:center; gap:15px; padding:12px 15px;
            color:rgba(255,255,255,0.85); text-decoration:none; border-radius:8px;
            transition:0.3s; font-size:14px; font-weight:500;
        }
        .menu-section a:hover, .menu-section a.active { background:rgba(255,255,255,0.15); color:white; }
        .menu-section a.active { background:rgba(255,255,255,0.2); }
        .menu-section a i { width:20px; text-align:center; }
        .user-profile {
            padding:20px; border-top:1px solid rgba(255,255,255,0.15);
            display:flex; align-items:center; gap:15px; background:rgba(255,255,255,0.05);
            position:sticky; bottom:0;
        }
        .user-avatar { width:45px; height:45px; border-radius:50%; background:linear-gradient(135deg,var(--primary-light),var(--secondary)); display:flex; align-items:center; justify-content:center; position:relative; flex-shrink:0; }
        .avatar-placeholder { font-size:16px; font-weight:700; color:white; }
        .online-status { position:absolute; bottom:3px; right:3px; width:12px; height:12px; background:var(--secondary); border-radius:50%; border:2px solid var(--primary-dark); }
        .user-info { flex:1; min-width:0; }
        .user-info h4 { font-size:14px; font-weight:600; margin:0 0 2px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .user-info p { font-size:12px; opacity:0.8; margin:0; }
        .user-actions a { color:rgba(255,255,255,0.8); font-size:16px; padding:8px; border-radius:6px; transition:0.3s; }
        .user-actions a:hover { background:rgba(255,255,255,0.15); color:white; }

        /* ===== MAIN CONTENT ===== */
        .main-content { flex:1; margin-left:var(--sidebar-width); transition:margin 0.3s; display:flex; flex-direction:column; min-height:100vh; }
        .sidebar-overlay { display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:999; }

        /* ===== TOPBAR ===== */
        .top-bar {
            background:white; padding:12px 25px; box-shadow:var(--shadow);
            display:flex; justify-content:space-between; align-items:center;
            position:sticky; top:0; z-index:900; gap:15px; flex-wrap:wrap;
            min-height:var(--topbar-height);
        }
        .dark-theme .top-bar { background:rgba(26,29,35,0.95); box-shadow:0 4px 20px rgba(0,0,0,0.3); }
        .top-bar-left { display:flex; align-items:center; gap:15px; flex:1; min-width:0; }
        .sidebar-toggle {
            display:none; background:var(--primary); border:none; color:white;
            font-size:18px; cursor:pointer; padding:10px; border-radius:8px;
            width:40px; height:40px; align-items:center; justify-content:center;
            transition:0.3s; flex-shrink:0;
        }
        .sidebar-toggle:hover { background:var(--primary-dark); transform:translateY(-2px); }
        .search-bar { flex:1; min-width:200px; max-width:500px; position:relative; }
        .search-bar i { position:absolute; left:15px; top:50%; transform:translateY(-50%); color:var(--gray); }
        .search-bar input {
            width:100%; padding:10px 15px 10px 40px; border:2px solid var(--light-gray);
            border-radius:var(--border-radius); font-size:14px; font-family:'Poppins',sans-serif;
            background:white; color:var(--dark); transition:0.3s;
        }
        .dark-theme .search-bar input { background:var(--light); border-color:#3d4249; color:var(--dark); }
        .search-bar input:focus { outline:none; border-color:var(--primary); box-shadow:0 0 0 3px rgba(111,66,193,0.15); }

        .top-bar-right { display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
        .notification-btn { position:relative; background:var(--light); border:none; width:40px; height:40px; border-radius:50%; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:0.3s; }
        .dark-theme .notification-btn { background:#2d3239; color:var(--gray); }
        .notification-btn:hover { background:var(--primary); color:white; }
        .notification-badge { position:absolute; top:-5px; right:-5px; background:var(--danger); color:white; font-size:10px; font-weight:700; width:18px; height:18px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:2px solid white; }
        .theme-toggle { background:var(--light); border:none; width:40px; height:40px; border-radius:50%; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:0.3s; color:var(--gray); }
        .dark-theme .theme-toggle { background:#2d3239; }
        .theme-toggle:hover { background:var(--primary); color:white; transform:rotate(30deg); }
        .quick-actions { display:flex; gap:8px; }
        .quick-action-btn { width:40px; height:40px; border-radius:50%; border:none; background:linear-gradient(135deg,var(--primary),var(--primary-light)); color:white; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:0.3s; text-decoration:none; font-size:16px; }
        .quick-action-btn:hover { transform:translateY(-3px) scale(1.1); box-shadow:0 6px 20px rgba(111,66,193,0.4); }

        /* ===== DASHBOARD CONTENT ===== */
        .dashboard-content { padding:25px; flex:1; }
        .page-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:25px; flex-wrap:wrap; gap:15px; }
        .page-header h1 { font-size:24px; font-weight:700; display:flex; align-items:center; gap:10px; }
        .page-header h1 i { color:var(--primary); }

        /* ===== TOAST NOTIFICATION ===== */
        .toast-notification {
            position:fixed; top:20px; right:20px; z-index:9999;
            padding:16px 24px; border-radius:var(--border-radius);
            background:white; box-shadow:0 8px 30px rgba(0,0,0,0.2);
            display:flex; align-items:center; gap:12px;
            transform:translateX(120%); transition:transform 0.5s ease;
            max-width:450px; border-left:5px solid;
        }
        .toast-notification.show { transform:translateX(0); }
        .toast-notification.success { border-color:var(--secondary); }
        .toast-notification.error { border-color:var(--danger); }
        .toast-notification i { font-size:24px; }
        .toast-notification.success i { color:var(--secondary); }
        .toast-notification.error i { color:var(--danger); }
        .toast-notification .toast-close { margin-left:auto; background:none; border:none; font-size:20px; cursor:pointer; color:var(--gray); }

        /* ===== FILTROS ===== */
        .filters-card { background:white; border-radius:var(--border-radius); padding:20px; margin-bottom:20px; box-shadow:var(--shadow); }
        .dark-theme .filters-card { background:#1a1d23; }
        .filters-form { display:grid; grid-template-columns:repeat(auto-fit, minmax(180px,1fr)); gap:15px; align-items:flex-end; }
        .form-group label { display:block; margin-bottom:5px; font-weight:500; color:var(--gray); font-size:13px; }
        .form-group input, .form-group select { width:100%; padding:10px; border:2px solid var(--light-gray); border-radius:8px; font-family:'Poppins',sans-serif; background:white; color:var(--dark); transition:0.3s; }
        .dark-theme .form-group input, .dark-theme .form-group select { background:#2d3239; border-color:#3d4249; color:#f8f9fa; }
        .form-group input:focus, .form-group select:focus { outline:none; border-color:var(--primary); }
        .btn-filter { background:var(--primary); color:white; border:none; padding:10px 20px; border-radius:8px; cursor:pointer; font-weight:600; height:42px; transition:0.3s; }

        /* ===== TABELA ===== */
        .table-card { background:white; border-radius:var(--border-radius); box-shadow:var(--shadow); overflow:hidden; border:1px solid rgba(0,0,0,0.05); }
        .dark-theme .table-card { background:#1a1d23; border-color:#2d3239; }
        .table-header { padding:20px; border-bottom:1px solid var(--light-gray); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:15px; }
        .dark-theme .table-header { border-bottom-color:#2d3239; }
        .table-header h3 { font-size:18px; font-weight:700; display:flex; align-items:center; gap:10px; }
        .table-header h3 i { color:var(--primary); }
        .view-all { color:var(--primary); text-decoration:none; font-size:13px; font-weight:600; padding:6px 12px; border-radius:6px; transition:0.3s; }
        .view-all:hover { background:var(--light); transform:translateX(3px); }
        .dark-theme .view-all:hover { background:#2d3239; }

        .table-container { overflow-x:auto; -webkit-overflow-scrolling:touch; }
        .data-table { width:100%; min-width:800px; border-collapse:collapse; }
        .data-table th { padding:12px 15px; text-align:left; font-weight:600; color:var(--gray); font-size:11px; text-transform:uppercase; letter-spacing:1px; border-bottom:2px solid var(--light-gray); background:#f8f9fa; }
        .dark-theme .data-table th { background:#2d3239; border-bottom-color:#3d4249; }
        .data-table td { padding:12px 15px; border-bottom:1px solid var(--light-gray); color:var(--dark); font-size:13px; vertical-align:middle; }
        .dark-theme .data-table td { color:#f8f9fa; border-bottom-color:#2d3239; }
        .data-table tbody tr:hover { background:rgba(111,66,193,0.02); }
        .dark-theme .data-table tbody tr:hover { background:rgba(111,66,193,0.05); }

        .data-table tbody tr.chamando-pulsing {
            background:rgba(32,201,151,0.1) !important;
            animation:pulse-row 2s infinite;
            border-left:4px solid var(--secondary);
        }
        @keyframes pulse-row {
            0% { background:rgba(32,201,151,0.08); }
            50% { background:rgba(32,201,151,0.25); }
            100% { background:rgba(32,201,151,0.08); }
        }

        /* ===== RESPONSIVO (tabela vira cards) ===== */
        @media (max-width: 768px) {
            .data-table, .data-table thead, .data-table tbody, .data-table tr, .data-table td, .data-table th { display:block; }
            .data-table thead { display:none; }
            .data-table tr { margin-bottom:15px; border-radius:var(--border-radius); box-shadow:0 2px 8px rgba(0,0,0,0.05); border:1px solid var(--light-gray); padding:15px; }
            .dark-theme .data-table tr { border-color:#2d3239; }
            .data-table td { border:none; padding:8px 0; position:relative; }
            .data-table td:before { content:attr(data-label); font-weight:600; color:var(--gray); display:inline-block; width:100px; }
            .data-table td .patient-cell { display:flex; align-items:center; gap:10px; }
            .data-table td .patient-cell .patient-avatar { width:35px; height:35px; font-size:12px; }
            .data-table td .actions { display:flex; gap:5px; flex-wrap:wrap; }
            .data-table td .actions .btn-chamar { font-size:12px; padding:6px 12px; }
        }

        /* ===== BADGES E BOTÕES ===== */
        .status-badge { display:inline-block; padding:4px 12px; border-radius:15px; font-size:11px; font-weight:700; text-transform:uppercase; }
        .status-ativo { background:rgba(32,201,151,0.15); color:var(--secondary); }
        .status-inativo { background:rgba(255,71,87,0.15); color:var(--danger); }
        .gravidade-badge { display:inline-flex; align-items:center; gap:5px; padding:3px 10px; border-radius:6px; font-size:11px; font-weight:700; text-transform:uppercase; }
        .gravidade-badge.verde { background:rgba(32,201,151,0.15); color:#20c997; }
        .gravidade-badge.azul { background:rgba(46,134,222,0.15); color:#2e86de; }
        .gravidade-badge.amarelo { background:rgba(255,159,67,0.15); color:#ff9f43; }
        .gravidade-badge.vermelho { background:rgba(255,71,87,0.15); color:#ff4757; }
        .gravidade-badge.nenhuma { background:rgba(108,117,125,0.1); color:var(--gray); }
        .badge-especialidade { display:inline-block; background:var(--light-gray); color:var(--primary); padding:2px 8px; border-radius:4px; font-size:10px; font-weight:600; margin-left:5px; }
        .dark-theme .badge-especialidade { background:#3d4249; color:#f8f9fa; }

        /* ===== BOTÕES - SEM SUBLINHADO ===== */
        .btn-chamar,
        .btn-icon,
        .btn-filter,
        .btn-primary,
        .btn-secondary,
        .quick-action-btn,
        .view-all,
        .pagination a,
        .pagination span,
        .menu-section a,
        .user-actions a,
        .footer-content a,
        .top-bar .quick-action-btn,
        .toast-notification .toast-close {
            text-decoration: none !important;
        }
        .btn-chamar:hover,
        .btn-icon:hover,
        .btn-filter:hover,
        .btn-primary:hover,
        .btn-secondary:hover,
        .quick-action-btn:hover,
        .view-all:hover,
        .pagination a:hover,
        .menu-section a:hover,
        .user-actions a:hover,
        .footer-content a:hover,
        .top-bar .quick-action-btn:hover,
        .toast-notification .toast-close:hover {
            text-decoration: none !important;
        }

        .btn-chamar { background:var(--secondary); color:white; border:none; padding:6px 14px; border-radius:6px; font-size:12px; font-weight:600; cursor:pointer; transition:0.3s; display:inline-flex; align-items:center; gap:5px; }
        .btn-chamar:hover { background:#1baa80; transform:translateY(-2px); box-shadow:0 4px 12px rgba(32,201,151,0.4); }
        .btn-icon { display:inline-flex; align-items:center; justify-content:center; width:32px; height:32px; border-radius:6px; color:var(--gray); transition:0.3s; background:none; border:none; cursor:pointer; }
        .btn-icon:hover { background:var(--primary); color:white; }
        .btn-filter:hover { background:var(--primary-dark); transform:translateY(-2px); }
        .actions { display:flex; gap:5px; align-items:center; flex-wrap:wrap; }

        /* ===== PAGINAÇÃO ===== */
        .pagination { display:flex; justify-content:center; gap:8px; padding:20px; flex-wrap:wrap; }
        .pagination a, .pagination span { display:inline-block; padding:8px 14px; border-radius:6px; background:var(--light); color:var(--primary); transition:0.3s; border:1px solid var(--light-gray); }
        .dark-theme .pagination a, .dark-theme .pagination span { background:#2d3239; border-color:#3d4249; color:#f8f9fa; }
        .pagination a:hover { background:var(--primary); color:white; border-color:var(--primary); }
        .pagination .active { background:var(--primary); color:white; border-color:var(--primary); }

        /* ===== FOOTER ===== */
        .main-footer { background:white; padding:15px; border-top:1px solid var(--light-gray); text-align:center; font-size:13px; color:var(--gray); }
        .dark-theme .main-footer { background:#1a1d23; border-top-color:#2d3239; }
        .footer-content a { color:var(--primary); }

        /* ===== RESPONSIVIDADE GERAL ===== */
        @media (max-width: 1199px) {
            .sidebar { transform:translateX(-100%); width:300px; }
            .sidebar.active { transform:translateX(0); }
            .sidebar-toggle { display:flex; }
            .sidebar-overlay.active { display:block; }
            .main-content { margin-left:0; }
        }
        @media (max-width: 992px) { .dashboard-content { padding:15px; } }
        @media (max-width: 768px) { .filters-form { grid-template-columns:1fr; } .page-header { flex-direction:column; align-items:flex-start; gap:10px; } }

        /* Preloader */
        .preloader { position:fixed; top:0; left:0; width:100%; height:100%; background:white; display:flex; align-items:center; justify-content:center; z-index:9999; transition:opacity 0.5s; }
        .dark-theme .preloader { background:#1a1d23; }
        .loader { text-align:center; }
        .loader i { font-size:50px; color:var(--primary); margin-bottom:20px; animation:bounce 1.5s infinite; }
        @keyframes bounce { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-15px);} }
    </style>
</head>
<body>
    <div class="preloader" id="preloader"><div class="loader"><i class="fas fa-stethoscope"></i><div>Carregando...</div></div></div>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="dashboard-container">
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon"><i class="fas fa-stethoscope"></i></div>
                    <div class="logo-text"><h2>Alfa Saúde</h2><p>Gestão Clínica</p></div>
                </div>
            </div>
            <div class="sidebar-menu">
                <div class="menu-section">
                    <h3>Menu Principal</h3>
                    <ul>
                        <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                        <li><a href="agendamentos.php"><i class="fas fa-calendar-alt"></i> Agenda</a></li>
                        <li><a href="pacientes.php" class="active"><i class="fas fa-user-injured"></i> Pacientes</a></li>
                        <li><a href="usuarios.php"><i class="fas fa-user-md"></i> Usuários</a></li>
                    </ul>
                </div>
                <div class="menu-section">
                    <h3>Atendimento</h3>
                    <ul>
                        <li><a href="prontuarios.php"><i class="fas fa-notes-medical"></i> Prontuários</a></li>
                        <li><a href="receituarios.php"><i class="fas fa-prescription"></i> Receituários</a></li>
                        <li><a href="declaracoes.php"><i class="fas fa-file-medical"></i> Declarações</a></li>
                    </ul>
                </div>
                <?php if ($usuario_tipo === 'admin'): ?>
                <div class="menu-section">
                    <h3>Administração</h3>
                    <ul>
                        <li><a href="clinica.php"><i class="fas fa-hospital"></i> Clínica</a></li>
                        <li><a href="relatorios.php"><i class="fas fa-chart-line"></i> Relatórios</a></li>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
            <div class="user-profile">
                <div class="user-avatar"><div class="avatar-placeholder"><?php echo $usuario_iniciais; ?></div><div class="online-status"></div></div>
                <div class="user-info"><h4><?php echo htmlspecialchars($usuario_nome); ?></h4><p><?php echo ucfirst($usuario_tipo); ?></p></div>
                <div class="user-actions"><a href="logout.php" title="Sair"><i class="fas fa-sign-out-alt"></i></a></div>
            </div>
        </aside>

        <main class="main-content">
            <header class="top-bar">
                <div class="top-bar-left">
                    <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <div class="search-bar">
                        <i class="fas fa-search"></i>
                        <input type="text" id="searchInput" placeholder="Pesquisar pacientes..." onkeyup="filtrarTabela()">
                    </div>
                </div>
                <div class="top-bar-right">
                    <button class="notification-btn"><i class="fas fa-bell"></i><span class="notification-badge"><?php echo $fila_contagem; ?></span></button>
                    <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
                    <div class="quick-actions">
                        <a href="pacientes/novo.php" class="quick-action-btn" title="Novo Paciente"><i class="fas fa-user-plus"></i></a>
                        <a href="agendamentos/novo.php" class="quick-action-btn" title="Novo Agendamento"><i class="fas fa-calendar-plus"></i></a>
                    </div>
                </div>
            </header>

            <div class="dashboard-content">
                <div class="page-header">
                    <h1><i class="fas fa-user-injured"></i> Pacientes</h1>
                    <a href="pacientes/novo.php" class="btn-filter"><i class="fas fa-plus"></i> Novo Paciente</a>
                </div>

                <div class="filters-card">
                    <form method="GET" class="filters-form">
                        <div class="form-group">
                            <label>Buscar</label>
                            <input type="text" name="busca" placeholder="Nome, CPF, telefone..." value="<?php echo htmlspecialchars($busca); ?>">
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <select name="filtro_ativo">
                                <option value="1" <?php echo $filtro_ativo == '1' ? 'selected' : ''; ?>>Ativos</option>
                                <option value="0" <?php echo $filtro_ativo == '0' ? 'selected' : ''; ?>>Inativos</option>
                            </select>
                        </div>
                        <button type="submit" class="btn-filter"><i class="fas fa-filter"></i> Filtrar</button>
                    </form>
                </div>

                <div class="table-card">
                    <div class="table-header">
                        <h3><i class="fas fa-list"></i> Lista de Pacientes</h3>
                        <span class="view-all">Total: <?php echo $total_registros; ?> | Página <?php echo $pagina_atual; ?> de <?php echo $total_paginas; ?></span>
                    </div>
                    <div class="table-container">
                        <table class="data-table" id="tabelaPacientes">
                            <thead>
                                <tr>
                                    <th>Paciente</th>
                                    <th>CPF</th>
                                    <th>Telefone</th>
                                    <th>Convênio</th>
                                    <th>Gravidade / Fila</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($pacientes) > 0): ?>
                                    <?php foreach ($pacientes as $p): ?>
                                    <?php 
                                        $is_chamando = ($p['fila_status'] === 'chamando');
                                        $row_class = $is_chamando ? 'chamando-pulsing' : '';
                                        $gravidade = $p['fila_gravidade'] ?? 'nenhuma';
                                        $senha = $p['fila_senha'] ?? '';
                                        $esp_atual = $p['fila_especialidade'] ?? 'Clínico Geral';
                                        
                                        $gravidade_labels = [
                                            'verde' => '<i class="fas fa-circle" style="font-size:8px;color:#20c997;"></i> Verde',
                                            'azul' => '<i class="fas fa-circle" style="font-size:8px;color:#2e86de;"></i> Azul',
                                            'amarelo' => '<i class="fas fa-circle" style="font-size:8px;color:#ff9f43;"></i> Amarelo',
                                            'vermelho' => '<i class="fas fa-circle" style="font-size:8px;color:#ff4757;"></i> Vermelho',
                                            'nenhuma' => 'Não na fila'
                                        ];
                                    ?>
                                    <tr class="<?php echo $row_class; ?>">
                                        <td data-label="Paciente">
                                            <div class="patient-cell">
                                                <div class="patient-avatar"><?php echo strtoupper(substr($p['nome'], 0, 2)); ?></div>
                                                <div class="patient-info">
                                                    <strong><?php echo htmlspecialchars($p['nome']); ?></strong>
                                                    <?php if (!empty($p['data_nascimento'])): ?>
                                                        <br><small><?php echo date('d/m/Y', strtotime($p['data_nascimento'])); ?></small>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td data-label="CPF"><?php echo htmlspecialchars($p['cpf'] ?? '-'); ?></td>
                                        <td data-label="Telefone"><?php echo htmlspecialchars($p['telefone'] ?? '-'); ?></td>
                                        <td data-label="Convênio"><?php echo htmlspecialchars($p['convenio'] ?? 'Particular'); ?></td>
                                        <td data-label="Gravidade">
                                            <?php if ($gravidade !== 'nenhuma'): ?>
                                                <span class="gravidade-badge <?php echo $gravidade; ?>">
                                                    <?php echo $gravidade_labels[$gravidade]; ?>
                                                </span>
                                                <?php if ($esp_atual): ?>
                                                    <span class="badge-especialidade"><?php echo htmlspecialchars($esp_atual); ?></span>
                                                <?php endif; ?>
                                                <?php if ($is_chamando): ?>
                                                    <br><small style="color:var(--secondary);font-weight:600;"><i class="fas fa-bullhorn"></i> Chamando (<?php echo $senha; ?>)</small>
                                                <?php elseif ($p['fila_status'] === 'aguardando'): ?>
                                                    <br><small style="color:var(--warning);font-weight:600;"><i class="fas fa-clock"></i> Aguardando (<?php echo $senha; ?>)</small>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="gravidade-badge nenhuma">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td data-label="Status">
                                            <span class="status-badge status-<?php echo $p['ativo'] ? 'ativo' : 'inativo'; ?>">
                                                <?php echo $p['ativo'] ? 'Ativo' : 'Inativo'; ?>
                                            </span>
                                        </td>
                                        <td data-label="Ações" class="actions">
                                            <form method="POST" style="display:inline;" onsubmit="return confirm('Chamar paciente para <?php echo htmlspecialchars($esp_atual); ?>?');">
                                                <input type="hidden" name="acao_chamar" value="1">
                                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                                <input type="hidden" name="nome_paciente" value="<?php echo htmlspecialchars($p['nome']); ?>">
                                                <input type="hidden" name="especialidade_chamada" value="<?php echo htmlspecialchars($esp_atual); ?>">
                                                <button type="submit" class="btn-chamar" title="Chamar Paciente"><i class="fas fa-bullhorn"></i> Chamar</button>
                                            </form>
                                            <a href="pacientes/visualizar.php?id=<?php echo $p['id']; ?>" class="btn-icon" title="Visualizar"><i class="fas fa-eye"></i></a>
                                            <?php if (hasPermissao('medico') || $usuario_tipo === 'admin'): ?>
                                                <a href="pacientes/editar.php?id=<?php echo $p['id']; ?>" class="btn-icon" title="Editar"><i class="fas fa-edit"></i></a>
                                                <?php if ($p['ativo']): ?>
                                                    <a href="pacientes/excluir.php?id=<?php echo $p['id']; ?>" class="btn-icon" onclick="return confirm('Tem certeza que deseja inativar este paciente?')" title="Inativar"><i class="fas fa-trash"></i></a>
                                                <?php else: ?>
                                                    <a href="pacientes/reativar.php?id=<?php echo $p['id']; ?>" class="btn-icon" onclick="return confirm('Reativar este paciente?')" title="Reativar"><i class="fas fa-undo"></i></a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="7" class="empty-table" style="text-align:center;padding:40px;color:var(--gray);"><i class="fas fa-user-injured" style="font-size:40px;display:block;margin-bottom:10px;"></i>Nenhum paciente encontrado</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- Paginação -->
                    <?php if ($total_paginas > 1): ?>
                    <div class="pagination">
                        <?php if ($pagina_atual > 1): ?>
                            <a href="?pagina=<?php echo $pagina_atual-1; ?>&busca=<?php echo urlencode($busca); ?>&filtro_ativo=<?php echo $filtro_ativo; ?>"><i class="fas fa-chevron-left"></i> Anterior</a>
                        <?php endif; ?>
                        <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                            <?php if ($i == $pagina_atual): ?>
                                <span class="active"><?php echo $i; ?></span>
                            <?php else: ?>
                                <a href="?pagina=<?php echo $i; ?>&busca=<?php echo urlencode($busca); ?>&filtro_ativo=<?php echo $filtro_ativo; ?>"><?php echo $i; ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        <?php if ($pagina_atual < $total_paginas): ?>
                            <a href="?pagina=<?php echo $pagina_atual+1; ?>&busca=<?php echo urlencode($busca); ?>&filtro_ativo=<?php echo $filtro_ativo; ?>">Próximo <i class="fas fa-chevron-right"></i></a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <footer class="main-footer">
                <div class="footer-content">
                    <p>desenvolvido por <a href="https://alfasistemas.dev.br" target="_blank">alfa sistemas s.a</a> (85) 2028-4584</p>
                </div>
            </footer>
        </main>
    </div>

    <!-- Toast Notification -->
    <?php if ($msg_chamada): ?>
    <div class="toast-notification <?php echo $tipo_chamada; ?> show" id="toastMsg">
        <i class="fas <?php echo $tipo_chamada === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
        <span><?php echo $msg_chamada; ?></span>
        <button class="toast-close" onclick="this.parentElement.classList.remove('show')">&times;</button>
    </div>
    <script>
        setTimeout(() => {
            const toast = document.getElementById('toastMsg');
            if (toast) toast.classList.remove('show');
        }, 6000);
    </script>
    <?php endif; ?>

    <script>
        // Preloader
        window.addEventListener('load', function() {
            setTimeout(() => {
                document.getElementById('preloader').style.opacity = '0';
                setTimeout(() => document.getElementById('preloader').style.display = 'none', 500);
            }, 800);
        });

        // Sidebar toggle
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => { sidebar.classList.toggle('active'); overlay.classList.toggle('active'); });
            overlay.addEventListener('click', () => { sidebar.classList.remove('active'); overlay.classList.remove('active'); });
        }

        // Theme toggle
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark-theme');
                const icon = themeToggle.querySelector('i');
                if (document.body.classList.contains('dark-theme')) {
                    icon.className = 'fas fa-sun';
                    localStorage.setItem('theme', 'dark');
                } else {
                    icon.className = 'fas fa-moon';
                    localStorage.setItem('theme', 'light');
                }
            });
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-theme');
                themeToggle.querySelector('i').className = 'fas fa-sun';
            }
        }

        // Filtro de busca na tabela (cliente-side)
        function filtrarTabela() {
            const input = document.getElementById('searchInput');
            const filter = input.value.toUpperCase();
            const table = document.getElementById('tabelaPacientes');
            const tr = table.getElementsByTagName('tr');
            for (let i = 1; i < tr.length; i++) {
                const tdNome = tr[i].getElementsByTagName('td')[0];
                if (tdNome) {
                    const txtValue = tdNome.textContent || tdNome.innerText;
                    tr[i].style.display = txtValue.toUpperCase().indexOf(filter) > -1 ? '' : 'none';
                }
            }
        }
    </script>
</body>
</html>