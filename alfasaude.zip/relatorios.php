<?php
// ============================================
// ARQUIVO: relatorios.php
// DESCRIÇÃO: Relatórios gerenciais com tema original + melhorias
// ============================================

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config/database.php';
require_once 'config/auth.php';
verificarLogin();

if (!hasPermissao('medico')) {
    header('Location: dashboard.php?erro=permissao');
    exit;
}

// ============================================
// CONFIGURAÇÕES DE PAGINAÇÃO
// ============================================
$itens_por_pagina = 10;
$pagina_atual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$offset = ($pagina_atual - 1) * $itens_por_pagina;

// ============================================
// FILTROS
// ============================================
$tipo_relatorio = $_GET['tipo'] ?? 'atendimentos';
$data_inicio    = $_GET['data_inicio'] ?? date('Y-m-01');
$data_fim       = $_GET['data_fim'] ?? date('Y-m-d');
$medico_id      = isset($_GET['medico_id']) ? intval($_GET['medico_id']) : 0;

$dados = [];
$colunas = [];
$total_registros = 0;

// ============================================
// CONSULTAS (com contagem para paginação)
// ============================================
switch ($tipo_relatorio) {
    case 'atendimentos':
        $sql_count = "SELECT COUNT(*) as total FROM agendamentos a
                      JOIN pacientes p ON a.paciente_id = p.id
                      JOIN usuarios u ON a.usuario_id = u.id
                      WHERE DATE(a.data_hora) BETWEEN :data_inicio AND :data_fim";
        $params = [':data_inicio' => $data_inicio, ':data_fim' => $data_fim];
        if ($medico_id > 0) {
            $sql_count .= " AND a.usuario_id = :medico_id";
            $params[':medico_id'] = $medico_id;
        }
        $stmt_count = $pdo->prepare($sql_count);
        $stmt_count->execute($params);
        $total_registros = $stmt_count->fetch()['total'];

        $sql = "SELECT a.data_hora, p.nome as paciente, u.nome as medico, a.tipo_consulta, a.status
                FROM agendamentos a
                JOIN pacientes p ON a.paciente_id = p.id
                JOIN usuarios u ON a.usuario_id = u.id
                WHERE DATE(a.data_hora) BETWEEN :data_inicio AND :data_fim";
        if ($medico_id > 0) {
            $sql .= " AND a.usuario_id = :medico_id";
        }
        $sql .= " ORDER BY a.data_hora DESC LIMIT :limit OFFSET :offset";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':limit', $itens_por_pagina, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindValue(':data_inicio', $data_inicio);
        $stmt->bindValue(':data_fim', $data_fim);
        if ($medico_id > 0) $stmt->bindValue(':medico_id', $medico_id);
        $stmt->execute();
        $dados = $stmt->fetchAll();
        $colunas = ['Data/Hora', 'Paciente', 'Médico', 'Tipo', 'Status'];
        break;

    case 'pacientes':
        $sql_count = "SELECT COUNT(*) as total FROM pacientes
                      WHERE DATE(data_cadastro) BETWEEN :data_inicio AND :data_fim";
        $stmt_count = $pdo->prepare($sql_count);
        $stmt_count->execute([':data_inicio' => $data_inicio, ':data_fim' => $data_fim]);
        $total_registros = $stmt_count->fetch()['total'];

        $sql = "SELECT id, nome, data_nascimento, telefone, email, convenio, data_cadastro
                FROM pacientes
                WHERE DATE(data_cadastro) BETWEEN :data_inicio AND :data_fim
                ORDER BY data_cadastro DESC LIMIT :limit OFFSET :offset";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':limit', $itens_por_pagina, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindValue(':data_inicio', $data_inicio);
        $stmt->bindValue(':data_fim', $data_fim);
        $stmt->execute();
        $dados = $stmt->fetchAll();
        $colunas = ['ID', 'Nome', 'Nascimento', 'Telefone', 'E-mail', 'Convênio', 'Cadastro'];
        break;

    case 'receituarios':
        $sql_count = "SELECT COUNT(*) as total FROM receituarios r
                      JOIN pacientes p ON r.paciente_id = p.id
                      JOIN usuarios u ON r.usuario_id = u.id
                      WHERE DATE(r.data_emissao) BETWEEN :data_inicio AND :data_fim";
        $params = [':data_inicio' => $data_inicio, ':data_fim' => $data_fim];
        if ($medico_id > 0) {
            $sql_count .= " AND r.usuario_id = :medico_id";
            $params[':medico_id'] = $medico_id;
        }
        $stmt_count = $pdo->prepare($sql_count);
        $stmt_count->execute($params);
        $total_registros = $stmt_count->fetch()['total'];

        $sql = "SELECT r.data_emissao, p.nome as paciente, u.nome as medico, r.codigo_verificacao
                FROM receituarios r
                JOIN pacientes p ON r.paciente_id = p.id
                JOIN usuarios u ON r.usuario_id = u.id
                WHERE DATE(r.data_emissao) BETWEEN :data_inicio AND :data_fim";
        if ($medico_id > 0) $sql .= " AND r.usuario_id = :medico_id";
        $sql .= " ORDER BY r.data_emissao DESC LIMIT :limit OFFSET :offset";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':limit', $itens_por_pagina, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindValue(':data_inicio', $data_inicio);
        $stmt->bindValue(':data_fim', $data_fim);
        if ($medico_id > 0) $stmt->bindValue(':medico_id', $medico_id);
        $stmt->execute();
        $dados = $stmt->fetchAll();
        $colunas = ['Data', 'Paciente', 'Médico', 'Código'];
        break;

    case 'declaracoes':
        $sql_count = "SELECT COUNT(*) as total FROM declaracoes d
                      JOIN pacientes p ON d.paciente_id = p.id
                      JOIN usuarios u ON d.usuario_id = u.id
                      WHERE DATE(d.data_emissao) BETWEEN :data_inicio AND :data_fim";
        $params = [':data_inicio' => $data_inicio, ':data_fim' => $data_fim];
        if ($medico_id > 0) {
            $sql_count .= " AND d.usuario_id = :medico_id";
            $params[':medico_id'] = $medico_id;
        }
        $stmt_count = $pdo->prepare($sql_count);
        $stmt_count->execute($params);
        $total_registros = $stmt_count->fetch()['total'];

        $sql = "SELECT d.data_emissao, p.nome as paciente, u.nome as medico, d.tipo, d.codigo_verificacao
                FROM declaracoes d
                JOIN pacientes p ON d.paciente_id = p.id
                JOIN usuarios u ON d.usuario_id = u.id
                WHERE DATE(d.data_emissao) BETWEEN :data_inicio AND :data_fim";
        if ($medico_id > 0) $sql .= " AND d.usuario_id = :medico_id";
        $sql .= " ORDER BY d.data_emissao DESC LIMIT :limit OFFSET :offset";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':limit', $itens_por_pagina, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindValue(':data_inicio', $data_inicio);
        $stmt->bindValue(':data_fim', $data_fim);
        if ($medico_id > 0) $stmt->bindValue(':medico_id', $medico_id);
        $stmt->execute();
        $dados = $stmt->fetchAll();
        $colunas = ['Data', 'Paciente', 'Médico', 'Tipo', 'Código'];
        break;

    default:
        $tipo_relatorio = 'atendimentos';
}

$total_paginas = ceil($total_registros / $itens_por_pagina);

// ============================================
// LISTA DE MÉDICOS PARA FILTRO
// ============================================
$medicos = $pdo->query("SELECT id, nome FROM usuarios WHERE tipo IN ('admin','medico') AND ativo = 1 ORDER BY nome")->fetchAll();

// ============================================
// DADOS DO USUÁRIO
// ============================================
$usuario_nome  = $_SESSION['usuario_nome']  ?? 'Usuário';
$usuario_tipo  = $_SESSION['usuario_tipo']  ?? 'usuario';
$usuario_iniciais = strtoupper(substr($usuario_nome, 0, 2));
$cores = function_exists('getCoresTema') ? getCoresTema() : ['primaria' => '#6f42c1', 'secundaria' => '#20c997'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios | Alfa Saúde</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ===== VARIÁVEIS ===== */
        :root {
            --primary: <?php echo $cores['primaria']; ?>;
            --primary-light: <?php echo $cores['primaria']; ?>dd;
            --primary-dark: <?php echo $cores['primaria']; ?>aa;
            --secondary: <?php echo $cores['secundaria']; ?>;
            --secondary-light: <?php echo $cores['secundaria']; ?>dd;
            --danger: #ff4757; --warning: #ff9f43; --info: #2e86de;
            --light: #f8f9fa; --dark: #343a40; --gray: #6c757d; --light-gray: #e9ecef;
            --border-radius: 12px; --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --sidebar-width: 280px; --topbar-height: 80px;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family:'Poppins',sans-serif;
            background:linear-gradient(135deg,#f5f7fb 0%,#eef2f7 100%);
            color:var(--dark); line-height:1.6; min-height:100vh; overflow-x:hidden;
        }
        body.dark-theme {
            --light:#1a1d23; --dark:#f8f9fa; --gray:#adb5bd; --light-gray:#2d3239;
            background:linear-gradient(135deg,#121416 0%,#1a1d23 100%);
        }

        /* ===== SIDEBAR ===== */
        .dashboard-container { display:flex; min-height:100vh; }
        .sidebar {
            width:var(--sidebar-width);
            background:linear-gradient(180deg,var(--primary),var(--primary-dark));
            color:white; position:fixed; height:100vh; z-index:1000;
            transition:transform 0.3s ease; overflow-y:auto;
            box-shadow:3px 0 20px rgba(0,0,0,0.1);
        }
        .dark-theme .sidebar { box-shadow:3px 0 20px rgba(0,0,0,0.3); }
        .sidebar-header { padding:25px; border-bottom:1px solid rgba(255,255,255,0.15); background:rgba(255,255,255,0.05); position:sticky; top:0; }
        .logo { display:flex; align-items:center; gap:15px; }
        .logo-icon { width:45px; height:45px; background:rgba(255,255,255,0.2); border-radius:10px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
        .logo-text h2 { font-size:18px; font-weight:700; margin:0; }
        .logo-text p { font-size:12px; opacity:0.9; margin:0; }
        .sidebar-menu { padding:20px 0; }
        .menu-section { margin-bottom:25px; padding:0 20px; }
        .menu-section h3 { font-size:11px; text-transform:uppercase; letter-spacing:1.5px; opacity:0.7; margin-bottom:15px; font-weight:600; }
        .menu-section ul { list-style:none; }
        .menu-section a {
            display:flex; align-items:center; gap:15px; padding:12px 15px;
            color:rgba(255,255,255,0.85); text-decoration:none; border-radius:8px;
            transition:0.3s; font-size:14px; font-weight:500;
        }
        .menu-section a:hover, .menu-section a.active { background:rgba(255,255,255,0.12); color:white; }
        .menu-section a.active { background:rgba(255,255,255,0.18); font-weight:600; }
        .menu-section a.active::before { content:''; position:absolute; left:0; top:50%; transform:translateY(-50%); width:4px; height:60%; background:var(--secondary); border-radius:0 4px 4px 0; }
        .menu-section a i { width:20px; text-align:center; }
        .user-profile {
            padding:20px; border-top:1px solid rgba(255,255,255,0.15);
            display:flex; align-items:center; gap:15px; background:rgba(255,255,255,0.05);
            position:sticky; bottom:0;
        }
        .user-avatar { width:45px; height:45px; border-radius:50%; background:linear-gradient(135deg,var(--primary-light),var(--secondary)); display:flex; align-items:center; justify-content:center; position:relative; flex-shrink:0; }
        .avatar-placeholder { font-size:16px; font-weight:700; color:white; }
        .online-status { position:absolute; bottom:3px; right:3px; width:12px; height:12px; background:var(--secondary); border-radius:50%; border:2px solid var(--primary-dark); }
        .user-info { flex:1; min-width:0; }
        .user-info h4 { font-size:14px; font-weight:600; margin:0 0 2px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .user-info p { font-size:12px; opacity:0.8; margin:0; }
        .user-actions a { color:rgba(255,255,255,0.8); font-size:16px; padding:8px; border-radius:6px; transition:0.3s; }
        .user-actions a:hover { background:rgba(255,255,255,0.15); color:white; }

        /* ===== MAIN ===== */
        .main-content { flex:1; margin-left:var(--sidebar-width); transition:margin 0.3s; display:flex; flex-direction:column; min-height:100vh; }
        .sidebar-overlay { display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:999; }

        /* ===== TOPBAR ===== */
        .top-bar {
            background:white; padding:15px 25px; box-shadow:var(--shadow);
            display:flex; justify-content:space-between; align-items:center;
            position:sticky; top:0; z-index:900; gap:15px; flex-wrap:wrap;
            min-height:var(--topbar-height);
        }
        .dark-theme .top-bar { background:rgba(26,29,35,0.95); box-shadow:0 4px 20px rgba(0,0,0,0.3); }
        .top-bar-left { display:flex; align-items:center; gap:15px; flex:1; min-width:0; }
        .sidebar-toggle {
            display:none; background:var(--primary); border:none; color:white;
            font-size:18px; cursor:pointer; padding:10px; border-radius:8px;
            width:40px; height:40px; align-items:center; justify-content:center;
            transition:0.3s; flex-shrink:0;
        }
        .sidebar-toggle:hover { background:var(--primary-dark); transform:translateY(-2px); }
        .search-bar { flex:1; min-width:200px; max-width:500px; position:relative; }
        .search-bar i { position:absolute; left:15px; top:50%; transform:translateY(-50%); color:var(--gray); }
        .search-bar input {
            width:100%; padding:12px 15px 12px 40px; border:2px solid var(--light-gray);
            border-radius:var(--border-radius); font-size:14px; font-family:'Poppins',sans-serif;
            background:white; color:var(--dark); transition:0.3s;
        }
        .dark-theme .search-bar input { background:var(--light); border-color:#3d4249; color:var(--dark); }
        .search-bar input:focus { outline:none; border-color:var(--primary); }
        .top-bar-right { display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
        .notification-btn { position:relative; background:var(--light); border:none; width:40px; height:40px; border-radius:50%; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:0.3s; color:var(--gray); }
        .dark-theme .notification-btn { background:#2d3239; }
        .notification-btn:hover { background:var(--primary); color:white; }
        .notification-badge { position:absolute; top:-5px; right:-5px; background:var(--danger); color:white; font-size:10px; font-weight:700; width:18px; height:18px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:2px solid white; }
        .theme-toggle { background:var(--light); border:none; width:40px; height:40px; border-radius:50%; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:0.3s; color:var(--gray); }
        .dark-theme .theme-toggle { background:#2d3239; }
        .theme-toggle:hover { background:var(--primary); color:white; transform:rotate(30deg); }
        .quick-actions { display:flex; gap:8px; }
        .quick-action-btn { width:40px; height:40px; border-radius:50%; border:none; background:linear-gradient(135deg,var(--primary),var(--primary-light)); color:white; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:0.3s; text-decoration:none; font-size:16px; }
        .quick-action-btn:hover { transform:translateY(-3px) scale(1.1); box-shadow:0 6px 20px rgba(111,66,193,0.4); }

        /* ===== CONTENT ===== */
        .dashboard-content { padding:25px; flex:1; }
        .page-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:30px; flex-wrap:wrap; gap:15px; }
        .page-header h1 { font-size:24px; font-weight:700; display:flex; align-items:center; gap:10px; }
        .page-header h1 i { color:var(--primary); }

        /* ===== FILTROS ===== */
        .filters-card { background:white; border-radius:var(--border-radius); padding:20px; margin-bottom:20px; box-shadow:var(--shadow); }
        .dark-theme .filters-card { background:#1a1d23; }
        .filters-form { display:grid; grid-template-columns:repeat(auto-fit, minmax(150px,1fr)); gap:15px; align-items:flex-end; }
        .form-group label { display:block; margin-bottom:5px; font-weight:500; color:var(--gray); font-size:13px; }
        .form-group input, .form-group select { width:100%; padding:10px; border:2px solid var(--light-gray); border-radius:8px; font-family:'Poppins',sans-serif; background:white; color:var(--dark); transition:0.3s; }
        .dark-theme .form-group input, .dark-theme .form-group select { background:#2d3239; border-color:#3d4249; color:#f8f9fa; }
        .form-group input:focus, .form-group select:focus { outline:none; border-color:var(--primary); }
        .btn-filter { background:var(--primary); color:white; border:none; padding:10px 20px; border-radius:8px; cursor:pointer; font-weight:600; height:42px; transition:0.3s; }
        .btn-filter:hover { background:var(--primary-dark); transform:translateY(-2px); }

        /* ===== TABELA ===== */
        .table-card { background:white; border-radius:var(--border-radius); box-shadow:var(--shadow); overflow:hidden; border:1px solid rgba(0,0,0,0.05); }
        .dark-theme .table-card { background:#1a1d23; border-color:#2d3239; }
        .table-header { padding:20px; border-bottom:1px solid var(--light-gray); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:15px; }
        .dark-theme .table-header { border-bottom-color:#2d3239; }
        .table-header h3 { font-size:18px; font-weight:700; display:flex; align-items:center; gap:10px; }
        .table-header h3 i { color:var(--primary); }
        .view-all { color:var(--primary); text-decoration:none !important; font-size:13px; font-weight:600; padding:6px 12px; border-radius:6px; transition:0.3s; }
        .view-all:hover { background:var(--light); transform:translateX(3px); }
        .dark-theme .view-all:hover { background:#2d3239; }

        .table-container { overflow-x:auto; -webkit-overflow-scrolling:touch; }
        .data-table { width:100%; min-width:700px; border-collapse:collapse; }
        .data-table th { padding:12px 15px; text-align:left; font-weight:600; color:var(--gray); font-size:11px; text-transform:uppercase; letter-spacing:1px; border-bottom:2px solid var(--light-gray); background:#f8f9fa; }
        .dark-theme .data-table th { background:#2d3239; border-bottom-color:#3d4249; }
        .data-table td { padding:12px 15px; border-bottom:1px solid var(--light-gray); color:var(--dark); font-size:13px; vertical-align:middle; }
        .dark-theme .data-table td { color:#f8f9fa; border-bottom-color:#2d3239; }
        .data-table tbody tr:hover { background:rgba(111,66,193,0.02); }
        .dark-theme .data-table tbody tr:hover { background:rgba(111,66,193,0.05); }

        /* Responsivo: em telas pequenas vira cards */
        @media (max-width:768px) {
            .data-table, .data-table thead, .data-table tbody, .data-table tr, .data-table td, .data-table th { display:block; }
            .data-table thead { display:none; }
            .data-table tr { margin-bottom:15px; border-radius:var(--border-radius); box-shadow:0 2px 8px rgba(0,0,0,0.05); border:1px solid var(--light-gray); padding:15px; }
            .dark-theme .data-table tr { border-color:#2d3239; }
            .data-table td { border:none; padding:8px 0; position:relative; }
            .data-table td:before { content:attr(data-label); font-weight:600; color:var(--gray); display:inline-block; width:100px; }
        }

        /* ===== BADGES ===== */
        .status-badge { display:inline-block; padding:4px 12px; border-radius:15px; font-size:11px; font-weight:700; text-transform:uppercase; }
        .status-agendado { background:rgba(255,159,67,0.15); color:var(--warning); }
        .status-confirmado { background:rgba(46,134,222,0.15); color:var(--info); }
        .status-em_andamento { background:rgba(32,201,151,0.15); color:var(--secondary); }
        .status-concluido { background:rgba(32,201,151,0.15); color:var(--secondary); }
        .status-cancelado { background:rgba(255,71,87,0.15); color:var(--danger); }

        /* ===== PAGINAÇÃO ===== */
        .pagination { display:flex; justify-content:center; gap:8px; padding:20px; flex-wrap:wrap; }
        .pagination a, .pagination span { display:inline-block; padding:8px 14px; border-radius:6px; background:var(--light); color:var(--primary); text-decoration:none !important; font-weight:500; transition:0.3s; border:1px solid var(--light-gray); }
        .dark-theme .pagination a, .dark-theme .pagination span { background:#2d3239; border-color:#3d4249; color:#f8f9fa; }
        .pagination a:hover { background:var(--primary); color:white; border-color:var(--primary); }
        .pagination .active { background:var(--primary); color:white; border-color:var(--primary); }

        /* ===== BOTÕES (SEM SUBLINHADO) ===== */
        .btn-primary, .btn-secondary, .btn-filter, .quick-action-btn, .view-all,
        .pagination a, .pagination span, .menu-section a, .user-actions a,
        .footer-content a {
            text-decoration: none !important;
        }
        .btn-primary:hover, .btn-secondary:hover, .btn-filter:hover,
        .quick-action-btn:hover, .view-all:hover,
        .pagination a:hover, .menu-section a:hover, .user-actions a:hover,
        .footer-content a:hover {
            text-decoration: none !important;
        }

        .btn-primary { background:var(--primary); color:white; border:none; padding:12px 20px; border-radius:var(--border-radius); font-size:14px; font-weight:600; cursor:pointer; display:inline-flex; align-items:center; gap:8px; transition:0.3s; }
        .btn-primary:hover { background:var(--primary-dark); transform:translateY(-2px); box-shadow:0 4px 15px rgba(111,66,193,0.4); }
        .btn-secondary { background:var(--light-gray); color:var(--dark); border:none; padding:12px 20px; border-radius:var(--border-radius); font-size:14px; font-weight:600; cursor:pointer; display:inline-flex; align-items:center; gap:8px; transition:0.3s; }
        .dark-theme .btn-secondary { background:#2d3239; color:#f8f9fa; }
        .btn-secondary:hover { background:var(--gray); color:white; }

        /* ===== EMPTY STATE ===== */
        .empty-state { text-align:center; padding:40px; color:var(--gray); }
        .empty-state i { font-size:40px; margin-bottom:15px; opacity:0.5; }

        /* ===== FOOTER ===== */
        .main-footer { background:white; padding:15px; border-top:1px solid var(--light-gray); text-align:center; font-size:13px; color:var(--gray); margin-top:20px; }
        .dark-theme .main-footer { background:#1a1d23; border-top-color:#2d3239; }
        .footer-content a { color:var(--primary); }

        /* ===== RESPONSIVIDADE ===== */
        @media (max-width:1199px) {
            .sidebar { transform:translateX(-100%); width:300px; }
            .sidebar.active { transform:translateX(0); }
            .sidebar-toggle { display:flex; }
            .sidebar-overlay.active { display:block; }
            .main-content { margin-left:0; }
        }
        @media (max-width:992px) { .dashboard-content { padding:15px; } }
        @media (max-width:768px) { .filters-form { grid-template-columns:1fr; } .page-header { flex-direction:column; align-items:flex-start; gap:10px; } }

        /* Preloader */
        .preloader { position:fixed; top:0; left:0; width:100%; height:100%; background:white; display:flex; align-items:center; justify-content:center; z-index:9999; transition:opacity 0.5s; }
        .dark-theme .preloader { background:#1a1d23; }
        .loader { text-align:center; }
        .loader i { font-size:50px; color:var(--primary); margin-bottom:20px; animation:bounce 1.5s infinite; }
        @keyframes bounce { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-15px);} }
    </style>
</head>
<body>
    <div class="preloader" id="preloader"><div class="loader"><i class="fas fa-stethoscope"></i><div>Carregando...</div></div></div>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo"><div class="logo-icon"><i class="fas fa-stethoscope"></i></div><div class="logo-text"><h2>Alfa Saúde</h2><p>Gestão Clínica</p></div></div>
            </div>
            <div class="sidebar-menu">
                <div class="menu-section"><h3>Menu Principal</h3>
                    <ul>
                        <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                        <li><a href="agendamentos.php"><i class="fas fa-calendar-alt"></i> Agenda</a></li>
                        <li><a href="pacientes.php"><i class="fas fa-user-injured"></i> Pacientes</a></li>
                        <li><a href="usuarios.php"><i class="fas fa-user-md"></i> Usuários</a></li>
                    </ul>
                </div>
                <div class="menu-section"><h3>Atendimento</h3>
                    <ul>
                        <li><a href="prontuarios.php"><i class="fas fa-notes-medical"></i> Prontuários</a></li>
                        <li><a href="receituarios.php"><i class="fas fa-prescription"></i> Receituários</a></li>
                        <li><a href="declaracoes.php"><i class="fas fa-file-medical"></i> Declarações</a></li>
                    </ul>
                </div>
                <div class="menu-section"><h3>Administração</h3>
                    <ul>
                        <li><a href="clinica.php"><i class="fas fa-hospital"></i> Clínica</a></li>
                        <li><a href="relatorios.php" class="active"><i class="fas fa-chart-line"></i> Relatórios</a></li>
                    </ul>
                </div>
            </div>
            <div class="user-profile">
                <div class="user-avatar"><div class="avatar-placeholder"><?php echo $usuario_iniciais; ?></div><div class="online-status"></div></div>
                <div class="user-info"><h4><?php echo htmlspecialchars($usuario_nome); ?></h4><p><?php echo ucfirst($usuario_tipo); ?></p></div>
                <div class="user-actions"><a href="logout.php" title="Sair"><i class="fas fa-sign-out-alt"></i></a></div>
            </div>
        </aside>

        <!-- Main -->
        <main class="main-content">
            <header class="top-bar">
                <div class="top-bar-left">
                    <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <div class="search-bar"><i class="fas fa-search"></i><input type="text" placeholder="Pesquisar..."></div>
                </div>
                <div class="top-bar-right">
                    <button class="notification-btn"><i class="fas fa-bell"></i><span class="notification-badge">0</span></button>
                    <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
                    <div class="quick-actions">
                        <a href="relatorios.php" class="quick-action-btn" title="Relatórios"><i class="fas fa-chart-line"></i></a>
                    </div>
                </div>
            </header>

            <div class="dashboard-content">
                <div class="page-header">
                    <h1><i class="fas fa-chart-line"></i> Relatórios</h1>
                </div>

                <!-- Filtros -->
                <div class="filters-card">
                    <form method="GET" class="filters-form">
                        <div class="form-group">
                            <label>Tipo</label>
                            <select name="tipo">
                                <option value="atendimentos" <?php echo $tipo_relatorio == 'atendimentos' ? 'selected' : ''; ?>>Atendimentos</option>
                                <option value="pacientes" <?php echo $tipo_relatorio == 'pacientes' ? 'selected' : ''; ?>>Pacientes</option>
                                <option value="receituarios" <?php echo $tipo_relatorio == 'receituarios' ? 'selected' : ''; ?>>Receituários</option>
                                <option value="declaracoes" <?php echo $tipo_relatorio == 'declaracoes' ? 'selected' : ''; ?>>Declarações</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Data Início</label>
                            <input type="date" name="data_inicio" value="<?php echo $data_inicio; ?>">
                        </div>
                        <div class="form-group">
                            <label>Data Fim</label>
                            <input type="date" name="data_fim" value="<?php echo $data_fim; ?>">
                        </div>
                        <?php if (in_array($tipo_relatorio, ['atendimentos', 'receituarios', 'declaracoes'])): ?>
                        <div class="form-group">
                            <label>Médico</label>
                            <select name="medico_id">
                                <option value="0">Todos</option>
                                <?php foreach ($medicos as $m): ?>
                                    <option value="<?php echo $m['id']; ?>" <?php echo $medico_id == $m['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($m['nome']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php endif; ?>
                        <button type="submit" class="btn-filter"><i class="fas fa-filter"></i> Filtrar</button>
                    </form>
                </div>

                <!-- Tabela -->
                <div class="table-card">
                    <div class="table-header">
                        <h3><i class="fas fa-list"></i> Resultados</h3>
                        <span class="view-all">Total: <?php echo $total_registros; ?> | Página <?php echo $pagina_atual; ?> de <?php echo $total_paginas; ?></span>
                    </div>
                    <div class="table-container">
                        <?php if (count($dados) > 0): ?>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <?php foreach ($colunas as $col): ?>
                                        <th><?php echo $col; ?></th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($dados as $row): ?>
                                <tr>
                                    <?php foreach ($row as $key => $value): ?>
                                        <td data-label="<?php echo ucfirst(str_replace('_', ' ', $key)); ?>">
                                            <?php
                                            // Formatação de datas
                                            if (strpos($key, 'data') !== false && !empty($value) && $key != 'data_nascimento') {
                                                echo date('d/m/Y H:i', strtotime($value));
                                            } elseif ($key == 'data_nascimento' && !empty($value)) {
                                                echo date('d/m/Y', strtotime($value));
                                            }
                                            // Status com badge
                                            elseif ($key == 'status') {
                                                echo '<span class="status-badge status-'.strtolower(str_replace(' ', '_', $value)).'">'.ucfirst($value).'</span>';
                                            }
                                            // Código de verificação com fonte monoespaçada
                                            elseif ($key == 'codigo_verificacao') {
                                                echo '<code style="background:var(--light-gray);padding:2px 8px;border-radius:4px;font-size:12px;">'.htmlspecialchars($value).'</code>';
                                            }
                                            else {
                                                echo htmlspecialchars($value ?? '-');
                                            }
                                            ?>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-chart-bar"></i>
                                <p>Nenhum dado encontrado para os filtros selecionados.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <!-- Paginação -->
                    <?php if ($total_paginas > 1): ?>
                    <div class="pagination">
                        <?php if ($pagina_atual > 1): ?>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['pagina' => $pagina_atual-1])); ?>"><i class="fas fa-chevron-left"></i> Anterior</a>
                        <?php endif; ?>
                        <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                            <?php if ($i == $pagina_atual): ?>
                                <span class="active"><?php echo $i; ?></span>
                            <?php else: ?>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['pagina' => $i])); ?>"><?php echo $i; ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        <?php if ($pagina_atual < $total_paginas): ?>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['pagina' => $pagina_atual+1])); ?>">Próximo <i class="fas fa-chevron-right"></i></a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>

                <?php if (count($dados) > 0): ?>
                <div style="text-align: right; margin-top: 20px;">
                    <a href="relatorios_print.php?<?php echo http_build_query($_GET); ?>" target="_blank" class="btn-primary"><i class="fas fa-print"></i> Versão para Impressão</a>
                </div>
                <?php endif; ?>
            </div>

            <footer class="main-footer">
                <div class="footer-content"><p>desenvolvido por <a href="https://alfasistemas.dev.br" target="_blank">alfa sistemas s.a</a> (85) 2028-4584</p></div>
            </footer>
        </main>
    </div>

    <script>
        // Preloader
        window.addEventListener('load', function() {
            setTimeout(() => {
                document.getElementById('preloader').style.opacity = '0';
                setTimeout(() => document.getElementById('preloader').style.display = 'none', 500);
            }, 800);
        });

        // Sidebar
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => { sidebar.classList.toggle('active'); overlay.classList.toggle('active'); });
            overlay.addEventListener('click', () => { sidebar.classList.remove('active'); overlay.classList.remove('active'); });
        }

        // Theme
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark-theme');
                const icon = themeToggle.querySelector('i');
                if (document.body.classList.contains('dark-theme')) {
                    icon.className = 'fas fa-sun';
                    localStorage.setItem('theme', 'dark');
                } else {
                    icon.className = 'fas fa-moon';
                    localStorage.setItem('theme', 'light');
                }
            });
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-theme');
                themeToggle.querySelector('i').className = 'fas fa-sun';
            }
        }
    </script>
</body>
</html>