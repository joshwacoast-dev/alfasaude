<header class="top-bar">
    <div class="top-bar-left">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <div class="search-bar">
            <i class="fas fa-search"></i>
            <input type="text" id="searchInput" placeholder="Pesquisar pacientes, médicos...">
        </div>
    </div>
    <div class="top-bar-right">
        <button class="notification-btn"><i class="fas fa-bell"></i><span class="notification-badge">3</span></button>
        <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
        <div class="quick-actions">
            <a href="<?php echo $base_url; ?>modules/pacientes/novo.php" class="quick-action-btn" title="Novo Paciente"><i class="fas fa-user-plus"></i></a>
            <a href="<?php echo $base_url; ?>modules/agendamentos/novo.php" class="quick-action-btn" title="Novo Agendamento"><i class="fas fa-calendar-plus"></i></a>
        </div>
    </div>
</header>