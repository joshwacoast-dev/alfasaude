<footer class="main-footer">
    <div class="footer-content">
        <p>desenvolvido por <a href="https://alfasistemas.dev.br" target="_blank">alfa sistemas s.a</a> (85) 2028-4584</p>
        <?php
        $clinica = getClinica();
        if ($clinica['logo']): ?>
            <img src="assets/img/<?php echo $clinica['logo']; ?>" alt="Logo" height="30">
        <?php endif; ?>
    </div>
</footer>
<style>
    .main-footer {
        background: white;
        padding: 15px 25px;
        border-top: 1px solid var(--light-gray);
        text-align: center;
        font-size: 13px;
        color: var(--gray);
    }
    .dark-theme .main-footer {
        background: #1a1d23;
        border-top-color: #2d3239;
    }
    .footer-content {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
    }
    .footer-content a {
        color: var(--primary);
        text-decoration: none;
    }
</style>