<?php
$clinica = getClinica();
$pagina_atual = basename($_SERVER['PHP_SELF']);
?>
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <div class="logo-icon">
                <i class="fas fa-stethoscope"></i>
            </div>
            <div class="logo-text">
                <h2><?php echo $clinica['nome']; ?></h2>
                <p>Gestão Clínica</p>
            </div>
        </div>
    </div>
    
    <div class="sidebar-menu">
        <div class="menu-section">
            <h3>Menu Principal</h3>
            <ul>
                <li><a href="<?php echo $base_url; ?>dashboard.php" class="<?php echo $pagina_atual=='dashboard.php'?'active':''; ?>"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="<?php echo $base_url; ?>modules/agendamentos/index.php" class="<?php echo strpos($pagina_atual,'agendamentos')!==false?'active':''; ?>"><i class="fas fa-calendar-alt"></i> Agenda</a></li>
                <li><a href="<?php echo $base_url; ?>modules/pacientes/index.php" class="<?php echo strpos($pagina_atual,'pacientes')!==false?'active':''; ?>"><i class="fas fa-user-injured"></i> Pacientes</a></li>
                <li><a href="<?php echo $base_url; ?>modules/medicos/index.php" class="<?php echo strpos($pagina_atual,'medicos')!==false?'active':''; ?>"><i class="fas fa-user-md"></i> Médicos</a></li>
            </ul>
        </div>
        <div class="menu-section">
            <h3>Atendimento</h3>
            <ul>
                <li><a href="<?php echo $base_url; ?>modules/prontuarios/index.php"><i class="fas fa-notes-medical"></i> Prontuários</a></li>
                <li><a href="<?php echo $base_url; ?>modules/receituarios/index.php"><i class="fas fa-prescription"></i> Receituários</a></li>
                <li><a href="<?php echo $base_url; ?>modules/declaracoes/index.php"><i class="fas fa-file-medical"></i> Declarações</a></li>
            </ul>
        </div>
        <div class="menu-section">
            <h3>Relatórios</h3>
            <ul>
                <li><a href="<?php echo $base_url; ?>modules/relatorios/atendimentos.php"><i class="fas fa-chart-line"></i> Atendimentos</a></li>
                <li><a href="<?php echo $base_url; ?>modules/relatorios/paciente.php"><i class="fas fa-user-chart"></i> Por Paciente</a></li>
            </ul>
        </div>
        <?php if (hasPermissao('admin')): ?>
        <div class="menu-section">
            <h3>Configurações</h3>
            <ul>
                <li><a href="<?php echo $base_url; ?>modules/clinica/index.php"><i class="fas fa-hospital"></i> Clínica</a></li>
                <li><a href="<?php echo $base_url; ?>modules/medicos/permissao.php"><i class="fas fa-lock"></i> Permissões</a></li>
            </ul>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="user-profile">
        <div class="user-avatar">
            <div class="avatar-placeholder"><?php echo strtoupper(substr($_SESSION['medico_nome'],0,2)); ?></div>
            <div class="online-status"></div>
        </div>
        <div class="user-info">
            <h4><?php echo $_SESSION['medico_nome']; ?></h4>
            <p><?php echo ucfirst($_SESSION['medico_nivel']); ?></p>
        </div>
        <div class="user-actions">
            <a href="<?php echo $base_url; ?>logout.php" title="Sair"><i class="fas fa-sign-out-alt"></i></a>
        </div>
    </div>
</aside>