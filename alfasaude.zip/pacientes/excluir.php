<?php
// ============================================
// ARQUIVO: pacientes/excluir.php
// DESCRIÇÃO: Inativa um paciente (exclusão lógica)
// ============================================

// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/database.php';
require_once '../config/auth.php';
verificarLogin();

// Apenas médicos e admin podem excluir pacientes
if (!hasPermissao('medico')) {
    header('Location: ../pacientes.php?erro=permissao');
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    header('Location: ../pacientes.php?erro=id_invalido');
    exit;
}

// Buscar paciente
$stmt = $pdo->prepare("SELECT * FROM pacientes WHERE id = ?");
$stmt->execute([$id]);
$paciente = $stmt->fetch();

if (!$paciente) {
    session_start();
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Paciente não encontrado.'];
    header('Location: ../pacientes.php');
    exit;
}

// Verificar se já está inativo
if ($paciente['ativo'] == 0) {
    session_start();
    $_SESSION['flash'] = ['tipo' => 'warning', 'msg' => 'Paciente já estava inativo.'];
    header('Location: ../pacientes.php');
    exit;
}

// Verificar se existem agendamentos futuros (não cancelados/concluídos)
$stmt = $pdo->prepare("
    SELECT COUNT(*) FROM agendamentos 
    WHERE paciente_id = ? 
    AND status IN ('agendado', 'confirmado')
    AND data_hora > NOW()
");
$stmt->execute([$id]);
$agendamentos_futuros = $stmt->fetchColumn();

if ($agendamentos_futuros > 0) {
    session_start();
    $_SESSION['flash'] = [
        'tipo' => 'error',
        'msg' => 'Este paciente possui agendamentos futuros. Cancele os agendamentos antes de inativar o paciente.'
    ];
    header('Location: ../pacientes.php');
    exit;
}

// Inativar paciente
try {
    $stmt = $pdo->prepare("UPDATE pacientes SET ativo = 0 WHERE id = ?");
    if ($stmt->execute([$id])) {
        session_start();
        $_SESSION['flash'] = ['tipo' => 'success', 'msg' => 'Paciente inativado com sucesso!'];
    } else {
        session_start();
        $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Erro ao inativar paciente.'];
    }
} catch (PDOException $e) {
    session_start();
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Erro no banco de dados: ' . $e->getMessage()];
}

header('Location: ../pacientes.php');
exit;