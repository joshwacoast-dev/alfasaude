<?php
// ============================================
// ARQUIVO: pacientes/reativar.php
// DESCRIÇÃO: Reativa um paciente inativo
// ============================================

// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Iniciar sessão no início (se necessário)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';
require_once '../config/auth.php';
verificarLogin();

// Apenas médicos e admin podem reativar pacientes
if (!hasPermissao('medico')) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Você não tem permissão para reativar pacientes.'];
    header('Location: ../pacientes.php');
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'ID inválido.'];
    header('Location: ../pacientes.php');
    exit;
}

// Buscar paciente
$stmt = $pdo->prepare("SELECT * FROM pacientes WHERE id = ?");
$stmt->execute([$id]);
$paciente = $stmt->fetch();

if (!$paciente) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Paciente não encontrado.'];
    header('Location: ../pacientes.php');
    exit;
}

// Verificar se já está ativo
if ($paciente['ativo'] == 1) {
    $_SESSION['flash'] = ['tipo' => 'warning', 'msg' => 'Paciente já está ativo.'];
    header('Location: ../pacientes.php');
    exit;
}

// Reativar paciente
try {
    $stmt = $pdo->prepare("UPDATE pacientes SET ativo = 1 WHERE id = ?");
    if ($stmt->execute([$id])) {
        $_SESSION['flash'] = ['tipo' => 'success', 'msg' => 'Paciente reativado com sucesso!'];
    } else {
        $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Erro ao reativar paciente.'];
    }
} catch (PDOException $e) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Erro no banco de dados: ' . $e->getMessage()];
}

header('Location: ../pacientes.php');
exit;