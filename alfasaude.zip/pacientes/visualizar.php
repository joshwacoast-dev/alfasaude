<?php
// ============================================
// ARQUIVO: pacientes/visualizar.php
// DESCRIÇÃO: Exibe detalhes de um paciente
// ============================================

// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/database.php';
require_once '../config/auth.php';
verificarLogin();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Buscar dados do paciente
$stmt = $pdo->prepare("SELECT * FROM pacientes WHERE id = ?");
$stmt->execute([$id]);
$paciente = $stmt->fetch();

if (!$paciente) {
    header('Location: ../pacientes.php?erro=nao_encontrado');
    exit;
}

// Buscar agendamentos do paciente
$agendamentos = $pdo->prepare("
    SELECT a.*, u.nome as medico_nome
    FROM agendamentos a
    JOIN usuarios u ON a.usuario_id = u.id
    WHERE a.paciente_id = ?
    ORDER BY a.data_hora DESC
    LIMIT 5
");
$agendamentos->execute([$id]);
$agendamentos = $agendamentos->fetchAll();

// Buscar prontuários do paciente
$prontuarios = $pdo->prepare("
    SELECT p.*, u.nome as medico_nome
    FROM prontuarios p
    JOIN usuarios u ON p.usuario_id = u.id
    WHERE p.paciente_id = ?
    ORDER BY p.data_atendimento DESC
    LIMIT 5
");
$prontuarios->execute([$id]);
$prontuarios = $prontuarios->fetchAll();

// ============================================
// DADOS DO USUÁRIO LOGADO
// ============================================
$usuario_nome  = $_SESSION['usuario_nome']  ?? 'Usuário';
$usuario_tipo  = $_SESSION['usuario_tipo']  ?? 'usuario';
$usuario_iniciais = strtoupper(substr($usuario_nome, 0, 2));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes do Paciente | Alfa Saúde</title>
    <!-- Font Awesome, Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ===== VARIÁVEIS GLOBAIS ===== */
        :root {
            --primary: #6f42c1;
            --primary-light: #6f42c1dd;
            --primary-dark: #6f42c1aa;
            --secondary: #20c997;
            --secondary-light: #20c997dd;
            --danger: #ff4757;
            --warning: #ff9f43;
            --info: #2e86de;
            --light: #f8f9fa;
            --dark: #343a40;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --border-radius: 12px;
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 8px 30px rgba(0, 0, 0, 0.12);
            --transition: all 0.3s ease;
            --sidebar-width: 280px;
            --topbar-height: 80px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fb 0%, #eef2f7 100%);
            color: var(--dark);
            line-height: 1.6;
            min-height: 100vh;
            overflow-x: hidden;
        }

        body.dark-theme {
            --light: #1a1d23;
            --dark: #f8f9fa;
            --gray: #adb5bd;
            --light-gray: #2d3239;
            background: linear-gradient(135deg, #121416 0%, #1a1d23 100%);
            color: #f8f9fa;
        }

        /* ===== LAYOUT PRINCIPAL ===== */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
            position: relative;
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            z-index: 1000;
            transition: var(--transition);
            box-shadow: 3px 0 20px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
        }

        .dark-theme .sidebar {
            box-shadow: 3px 0 20px rgba(0, 0, 0, 0.3);
        }

        .sidebar-header {
            padding: 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.15);
            background: rgba(255, 255, 255, 0.05);
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-icon {
            width: 45px;
            height: 45px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            flex-shrink: 0;
        }

        .logo-icon i {
            font-size: 22px;
        }

        .logo-text h2 {
            font-size: 18px;
            font-weight: 700;
            margin: 0;
            letter-spacing: 0.5px;
            line-height: 1.2;
        }

        .logo-text p {
            font-size: 12px;
            opacity: 0.9;
            margin: 3px 0 0 0;
            font-weight: 300;
        }

        .sidebar-menu {
            flex: 1;
            padding: 25px 0;
            overflow-y: auto;
        }

        .menu-section {
            margin-bottom: 25px;
            padding: 0 25px;
        }

        .menu-section h3 {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            opacity: 0.7;
            margin-bottom: 15px;
            font-weight: 600;
        }

        .menu-section ul {
            list-style: none;
        }

        .menu-section li {
            margin-bottom: 5px;
        }

        .menu-section a {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 15px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            border-radius: 8px;
            transition: var(--transition);
            position: relative;
            font-weight: 500;
            font-size: 14px;
        }

        .menu-section a:hover,
        .menu-section a.active {
            background: rgba(255, 255, 255, 0.12);
            color: white;
        }

        .menu-section a.active {
            background: rgba(255, 255, 255, 0.18);
            font-weight: 600;
        }

        .menu-section a.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 4px;
            height: 60%;
            background: var(--secondary);
            border-radius: 0 4px 4px 0;
        }

        .menu-section a i {
            font-size: 16px;
            width: 20px;
            text-align: center;
        }

        .menu-badge {
            margin-left: auto;
            background: var(--secondary);
            color: white;
            font-size: 11px;
            padding: 3px 8px;
            border-radius: 10px;
            font-weight: 600;
            min-width: 20px;
            text-align: center;
        }

        .menu-badge.new {
            background: var(--danger);
        }

        .menu-badge.alert {
            background: var(--warning);
        }

        .user-profile {
            padding: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.15);
            display: flex;
            align-items: center;
            gap: 15px;
            background: rgba(255, 255, 255, 0.05);
            position: sticky;
            bottom: 0;
        }

        .user-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            overflow: hidden;
            background: linear-gradient(135deg, var(--primary-light), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            flex-shrink: 0;
        }

        .avatar-placeholder {
            font-size: 16px;
            font-weight: 700;
            color: white;
        }

        .online-status {
            position: absolute;
            bottom: 3px;
            right: 3px;
            width: 12px;
            height: 12px;
            background: var(--secondary);
            border-radius: 50%;
            border: 2px solid var(--primary-dark);
        }

        .user-info {
            flex: 1;
            min-width: 0;
        }

        .user-info h4 {
            font-size: 14px;
            font-weight: 600;
            margin: 0 0 4px 0;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .user-info p {
            font-size: 12px;
            opacity: 0.9;
            margin: 0;
            font-weight: 400;
        }

        .user-actions a {
            color: rgba(255, 255, 255, 0.8);
            font-size: 16px;
            transition: var(--transition);
            padding: 8px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .user-actions a:hover {
            background: rgba(255, 255, 255, 0.15);
            color: white;
        }

        /* ===== CONTEÚDO PRINCIPAL ===== */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            transition: var(--transition);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        @media (max-width: 1199px) {
            .main-content {
                margin-left: 0;
            }
        }

        /* ===== TOP BAR ===== */
        .top-bar {
            background: white;
            padding: 15px 25px;
            box-shadow: var(--shadow);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 900;
            gap: 15px;
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95);
            flex-wrap: wrap;
            min-height: var(--topbar-height);
        }

        .dark-theme .top-bar {
            background: rgba(26, 29, 35, 0.95);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        }

        .top-bar-left {
            display: flex;
            align-items: center;
            gap: 15px;
            flex: 1;
            min-width: 0;
        }

        .sidebar-toggle {
            display: none;
            background: var(--primary);
            border: none;
            color: white;
            font-size: 18px;
            cursor: pointer;
            padding: 10px;
            border-radius: 8px;
            transition: var(--transition);
            flex-shrink: 0;
            width: 40px;
            height: 40px;
            align-items: center;
            justify-content: center;
        }

        .sidebar-toggle:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }

        .search-bar {
            flex: 1;
            min-width: 200px;
            max-width: 500px;
            position: relative;
        }

        .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            font-size: 14px;
            z-index: 1;
        }

        .search-bar input {
            width: 100%;
            padding: 12px 15px 12px 40px;
            border: 2px solid var(--light-gray);
            border-radius: var(--border-radius);
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            transition: var(--transition);
            background: white;
            color: var(--dark);
        }

        .dark-theme .search-bar input {
            background: var(--light);
            border-color: #3d4249;
            color: var(--dark);
        }

        .search-bar input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(111, 66, 193, 0.15);
        }

        .top-bar-right {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .notification-btn,
        .message-btn {
            position: relative;
            background: var(--light);
            border: none;
            font-size: 16px;
            color: var(--gray);
            cursor: pointer;
            padding: 10px;
            border-radius: 8px;
            transition: var(--transition);
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .dark-theme .notification-btn,
        .dark-theme .message-btn {
            background: #2d3239;
        }

        .notification-btn:hover,
        .message-btn:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-2px);
        }

        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            font-size: 10px;
            font-weight: 700;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid white;
        }

        .dark-theme .notification-badge {
            border-color: #1a1d23;
        }

        .theme-toggle {
            background: var(--light);
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
            font-size: 16px;
            color: var(--gray);
        }

        .dark-theme .theme-toggle {
            background: #2d3239;
        }

        .theme-toggle:hover {
            background: var(--primary);
            color: white;
            transform: rotate(30deg);
        }

        .quick-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .quick-action-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: none;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
            font-size: 16px;
            text-decoration: none;
        }

        .quick-action-btn:hover {
            transform: translateY(-3px) scale(1.1);
            box-shadow: 0 6px 20px rgba(111, 66, 193, 0.4);
        }

        /* ===== CONTEÚDO DO DASHBOARD ===== */
        .dashboard-content {
            padding: 25px;
            flex: 1;
            overflow-y: auto;
        }

        /* ===== PÁGINA DE VISUALIZAÇÃO ===== */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .page-header h1 {
            font-size: 24px;
            font-weight: 700;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .dark-theme .page-header h1 {
            color: #f8f9fa;
        }

        .btn-primary, .btn-secondary, .btn-success, .btn-danger {
            padding: 12px 20px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
            text-decoration: none;
            white-space: nowrap;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(111, 66, 193, 0.4);
        }

        .btn-secondary {
            background: var(--light-gray);
            color: var(--dark);
        }

        .btn-secondary:hover {
            background: var(--gray);
            color: white;
        }

        .btn-success {
            background: var(--secondary);
            color: white;
        }

        .btn-success:hover {
            background: var(--secondary-light);
            transform: translateY(-2px);
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            background: #ff1a2e;
            transform: translateY(-2px);
        }

        .dark-theme .btn-secondary {
            background: #2d3239;
            color: #f8f9fa;
        }

        .dark-theme .btn-secondary:hover {
            background: #3d4249;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .info-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 25px;
            box-shadow: var(--shadow);
            border: 1px solid rgba(0, 0, 0, 0.05);
        }

        .dark-theme .info-card {
            background: #1a1d23;
            border-color: #2d3239;
        }

        .info-card h3 {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 20px;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .dark-theme .info-card h3 {
            color: #f8f9fa;
        }

        .info-card h3 i {
            color: var(--primary);
        }

        .info-row {
            display: flex;
            margin-bottom: 12px;
            border-bottom: 1px dashed var(--light-gray);
            padding-bottom: 8px;
        }

        .info-label {
            width: 120px;
            font-weight: 600;
            color: var(--gray);
        }

        .info-value {
            flex: 1;
            color: var(--dark);
        }

        .dark-theme .info-value {
            color: #f8f9fa;
        }

        .info-value.status-ativo {
            color: var(--secondary);
            font-weight: 600;
        }

        .info-value.status-inativo {
            color: var(--danger);
            font-weight: 600;
        }

        .table-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            margin-bottom: 20px;
        }

        .dark-theme .table-card {
            background: #1a1d23;
        }

        .table-header {
            padding: 20px;
            border-bottom: 1px solid var(--light-gray);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .dark-theme .table-header {
            border-bottom-color: #2d3239;
        }

        .table-header h3 {
            font-size: 18px;
            font-weight: 700;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .dark-theme .table-header h3 {
            color: #f8f9fa;
        }

        .table-header h3 i {
            color: var(--primary);
        }

        .table-container {
            overflow-x: auto;
        }

        .data-table {
            width: 100%;
            min-width: 600px;
            border-collapse: collapse;
        }

        .data-table th {
            padding: 15px 20px;
            text-align: left;
            font-weight: 600;
            color: var(--gray);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-bottom: 2px solid var(--light-gray);
            background: #f8f9fa;
        }

        .dark-theme .data-table th {
            background: #2d3239;
            border-bottom-color: #3d4249;
        }

        .data-table td {
            padding: 15px 20px;
            border-bottom: 1px solid var(--light-gray);
            color: var(--dark);
            font-size: 13px;
        }

        .dark-theme .data-table td {
            color: #f8f9fa;
            border-bottom-color: #2d3239;
        }

        .data-table tbody tr:hover {
            background: rgba(111, 66, 193, 0.02);
        }

        .dark-theme .data-table tbody tr:hover {
            background: rgba(111, 66, 193, 0.05);
        }

        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-agendado {
            background: rgba(255, 159, 67, 0.15);
            color: var(--warning);
        }

        .status-concluido {
            background: rgba(32, 201, 151, 0.15);
            color: var(--secondary);
        }

        .status-cancelado {
            background: rgba(255, 71, 87, 0.15);
            color: var(--danger);
        }

        .btn-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 6px;
            color: var(--gray);
            transition: var(--transition);
            margin: 0 2px;
        }

        .btn-icon:hover {
            background: var(--primary);
            color: white;
        }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 40px;
            margin-bottom: 15px;
            opacity: 0.5;
        }

        /* ===== RODAPÉ ===== */
        .main-footer {
            background: white;
            padding: 15px 25px;
            border-top: 1px solid var(--light-gray);
            text-align: center;
            font-size: 13px;
            color: var(--gray);
        }

        .dark-theme .main-footer {
            background: #1a1d23;
            border-top-color: #2d3239;
        }

        .footer-content {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .footer-content a {
            color: var(--primary);
            text-decoration: none;
        }

        @media (max-width: 1199px) {
            .sidebar {
                transform: translateX(-100%);
                width: 300px;
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .sidebar-toggle {
                display: flex;
            }
            .sidebar-overlay.active {
                display: block;
            }
        }

        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 999;
        }

        .preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            transition: opacity 0.5s;
        }
        .dark-theme .preloader {
            background: #1a1d23;
        }
        .loader {
            text-align: center;
        }
        .loader i {
            font-size: 50px;
            color: var(--primary);
            margin-bottom: 20px;
            animation: bounce 1.5s infinite;
        }
        @keyframes bounce {
            0%,100%{transform:translateY(0);}
            50%{transform:translateY(-15px);}
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader" id="preloader">
        <div class="loader">
            <i class="fas fa-stethoscope"></i>
            <div>Carregando...</div>
        </div>
    </div>

    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="fas fa-stethoscope"></i>
                    </div>
                    <div class="logo-text">
                        <h2>Alfa Saúde</h2>
                        <p>Gestão Clínica</p>
                    </div>
                </div>
            </div>

            <div class="sidebar-menu">
                <div class="menu-section">
                    <h3>Menu Principal</h3>
                    <ul>
                        <li><a href="../dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                        <li><a href="../agendamentos.php"><i class="fas fa-calendar-alt"></i> Agenda</a></li>
                        <li><a href="../pacientes.php" class="active"><i class="fas fa-user-injured"></i> Pacientes</a></li>
                        <li><a href="../usuarios.php"><i class="fas fa-user-md"></i> Usuários</a></li>
                    </ul>
                </div>
                <div class="menu-section">
                    <h3>Atendimento</h3>
                    <ul>
                        <li><a href="../prontuarios.php"><i class="fas fa-notes-medical"></i> Prontuários</a></li>
                        <li><a href="../receituarios.php"><i class="fas fa-prescription"></i> Receituários</a></li>
                        <li><a href="../declaracoes.php"><i class="fas fa-file-medical"></i> Declarações</a></li>
                    </ul>
                </div>
                <?php if ($usuario_tipo === 'admin'): ?>
                <div class="menu-section">
                    <h3>Administração</h3>
                    <ul>
                        <li><a href="../clinica.php"><i class="fas fa-hospital"></i> Clínica</a></li>
                        <li><a href="../relatorios.php"><i class="fas fa-chart-line"></i> Relatórios</a></li>
                    </ul>
                </div>
                <?php endif; ?>
            </div>

            <div class="user-profile">
                <div class="user-avatar">
                    <div class="avatar-placeholder"><?php echo $usuario_iniciais; ?></div>
                    <div class="online-status"></div>
                </div>
                <div class="user-info">
                    <h4><?php echo htmlspecialchars($usuario_nome); ?></h4>
                    <p><?php echo ucfirst($usuario_tipo); ?></p>
                </div>
                <div class="user-actions">
                    <a href="../logout.php" title="Sair"><i class="fas fa-sign-out-alt"></i></a>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <header class="top-bar">
                <div class="top-bar-left">
                    <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <div class="search-bar">
                        <i class="fas fa-search"></i>
                        <input type="text" id="searchInput" placeholder="Pesquisar...">
                    </div>
                </div>
                <div class="top-bar-right">
                    <button class="notification-btn"><i class="fas fa-bell"></i><span class="notification-badge">0</span></button>
                    <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
                    <div class="quick-actions">
                        <a href="novo.php" class="quick-action-btn" title="Novo Paciente"><i class="fas fa-user-plus"></i></a>
                        <a href="../agendamentos/novo.php" class="quick-action-btn" title="Novo Agendamento"><i class="fas fa-calendar-plus"></i></a>
                    </div>
                </div>
            </header>

            <!-- Dashboard Content -->
            <div class="dashboard-content">
                <div class="page-header">
                    <h1><i class="fas fa-user-injured" style="color: var(--primary);"></i> Detalhes do Paciente</h1>
                    <div>
                        <a href="../pacientes.php" class="btn-secondary"><i class="fas fa-arrow-left"></i> Voltar</a>
                        <?php if (hasPermissao('medico')): ?>
                            <a href="editar.php?id=<?php echo $paciente['id']; ?>" class="btn-primary"><i class="fas fa-edit"></i> Editar</a>
                            <?php if ($paciente['ativo'] == 1): ?>
                                <a href="excluir.php?id=<?php echo $paciente['id']; ?>" class="btn-danger" onclick="return confirm('Tem certeza que deseja inativar este paciente?')"><i class="fas fa-trash"></i> Inativar</a>
                            <?php else: ?>
                                <a href="reativar.php?id=<?php echo $paciente['id']; ?>" class="btn-success" onclick="return confirm('Reativar este paciente?')"><i class="fas fa-undo"></i> Reativar</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Informações do paciente -->
                <div class="info-grid">
                    <div class="info-card">
                        <h3><i class="fas fa-id-card"></i> Dados Pessoais</h3>
                        <div class="info-row">
                            <span class="info-label">Nome:</span>
                            <span class="info-value"><?php echo htmlspecialchars($paciente['nome']); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Data Nasc.:</span>
                            <span class="info-value"><?php echo $paciente['data_nascimento'] ? date('d/m/Y', strtotime($paciente['data_nascimento'])) : '-'; ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">CPF:</span>
                            <span class="info-value"><?php echo htmlspecialchars($paciente['cpf'] ?? '-'); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">RG:</span>
                            <span class="info-value"><?php echo htmlspecialchars($paciente['rg'] ?? '-'); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Status:</span>
                            <span class="info-value <?php echo $paciente['ativo'] ? 'status-ativo' : 'status-inativo'; ?>">
                                <?php echo $paciente['ativo'] ? 'Ativo' : 'Inativo'; ?>
                            </span>
                        </div>
                    </div>

                    <div class="info-card">
                        <h3><i class="fas fa-phone-alt"></i> Contato</h3>
                        <div class="info-row">
                            <span class="info-label">Telefone:</span>
                            <span class="info-value"><?php echo htmlspecialchars($paciente['telefone'] ?? '-'); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">E-mail:</span>
                            <span class="info-value"><?php echo htmlspecialchars($paciente['email'] ?? '-'); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Endereço:</span>
                            <span class="info-value"><?php echo nl2br(htmlspecialchars($paciente['endereco'] ?? '-')); ?></span>
                        </div>
                    </div>

                    <div class="info-card">
                        <h3><i class="fas fa-hospital"></i> Convênio</h3>
                        <div class="info-row">
                            <span class="info-label">Convênio:</span>
                            <span class="info-value"><?php echo htmlspecialchars($paciente['convenio'] ?? 'Particular'); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Nº Carteirinha:</span>
                            <span class="info-value"><?php echo htmlspecialchars($paciente['numero_carteirinha'] ?? '-'); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Cadastro:</span>
                            <span class="info-value"><?php echo date('d/m/Y H:i', strtotime($paciente['data_cadastro'])); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Últimos agendamentos -->
                <div class="table-card">
                    <div class="table-header">
                        <h3><i class="fas fa-calendar-alt"></i> Últimos Agendamentos</h3>
                        <a href="../agendamentos.php?paciente_id=<?php echo $paciente['id']; ?>" class="view-all">Ver todos</a>
                    </div>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Data/Hora</th>
                                    <th>Médico</th>
                                    <th>Tipo</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($agendamentos) > 0): ?>
                                    <?php foreach ($agendamentos as $a): ?>
                                    <tr>
                                        <td><?php echo date('d/m/Y H:i', strtotime($a['data_hora'])); ?></td>
                                        <td><?php echo htmlspecialchars($a['medico_nome']); ?></td>
                                        <td><?php echo ucfirst($a['tipo_consulta']); ?></td>
                                        <td><span class="status-badge status-<?php echo $a['status']; ?>"><?php echo ucfirst($a['status']); ?></span></td>
                                        <td>
                                            <a href="../agendamentos/visualizar.php?id=<?php echo $a['id']; ?>" class="btn-icon" title="Visualizar"><i class="fas fa-eye"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="empty-state">
                                            <i class="fas fa-calendar-times"></i>
                                            <p>Nenhum agendamento encontrado.</p>
                                            <a href="../agendamentos/novo.php?paciente_id=<?php echo $paciente['id']; ?>" class="btn-primary" style="display: inline-block; margin-top: 10px;"><i class="fas fa-plus"></i> Novo Agendamento</a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Últimos prontuários -->
                <div class="table-card">
                    <div class="table-header">
                        <h3><i class="fas fa-notes-medical"></i> Últimos Prontuários</h3>
                        <a href="../prontuarios.php?paciente_id=<?php echo $paciente['id']; ?>" class="view-all">Ver todos</a>
                    </div>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Médico</th>
                                    <th>Diagnóstico</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($prontuarios) > 0): ?>
                                    <?php foreach ($prontuarios as $p): ?>
                                    <tr>
                                        <td><?php echo date('d/m/Y', strtotime($p['data_atendimento'])); ?></td>
                                        <td><?php echo htmlspecialchars($p['medico_nome']); ?></td>
                                        <td><?php echo htmlspecialchars(substr($p['diagnostico_final'] ?? '', 0, 50)) . (strlen($p['diagnostico_final'] ?? '') > 50 ? '...' : ''); ?></td>
                                        <td>
                                            <a href="../prontuarios/visualizar.php?id=<?php echo $p['id']; ?>" class="btn-icon" title="Visualizar"><i class="fas fa-eye"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="empty-state">
                                            <i class="fas fa-notes-medical"></i>
                                            <p>Nenhum prontuário encontrado.</p>
                                            <a href="../prontuarios/novo.php?paciente_id=<?php echo $paciente['id']; ?>" class="btn-primary" style="display: inline-block; margin-top: 10px;"><i class="fas fa-plus"></i> Novo Prontuário</a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <footer class="main-footer">
                <div class="footer-content">
                    <p>desenvolvido por <a href="https://alfasistemas.dev.br" target="_blank">alfa sistemas s.a</a> (85) 2028-4584</p>
                </div>
            </footer>
        </main>
    </div>

    <script>
        window.addEventListener('load', function() {
            setTimeout(() => {
                document.getElementById('preloader').style.opacity = '0';
                setTimeout(() => document.getElementById('preloader').style.display = 'none', 500);
            }, 800);
        });

        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('active');
                overlay.classList.toggle('active');
            });
            overlay.addEventListener('click', () => {
                sidebar.classList.remove('active');
                overlay.classList.remove('active');
            });
        }

        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark-theme');
                const icon = themeToggle.querySelector('i');
                if (document.body.classList.contains('dark-theme')) {
                    icon.className = 'fas fa-sun';
                    localStorage.setItem('theme', 'dark');
                } else {
                    icon.className = 'fas fa-moon';
                    localStorage.setItem('theme', 'light');
                }
            });
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-theme');
                themeToggle.querySelector('i').className = 'fas fa-sun';
            }
        }
    </script>
</body>
</html>