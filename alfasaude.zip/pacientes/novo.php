<?php
// ============================================
// ARQUIVO: pacientes/novo.php
// DESCRIÇÃO: Cadastro de novos pacientes
// ============================================

// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/database.php';
require_once '../config/auth.php';
verificarLogin();

// Apenas médicos e admin podem cadastrar pacientes
if (!hasPermissao('medico')) {
    header('Location: ../pacientes.php');
    exit;
}

// ============================================
// PROCESSAR FORMULÁRIO
// ============================================
$erros = [];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome              = trim($_POST['nome'] ?? '');
    $data_nascimento   = $_POST['data_nascimento'] ?: null;
    $cpf               = preg_replace('/[^0-9]/', '', $_POST['cpf'] ?? '');
    $rg                = trim($_POST['rg'] ?? '');
    $telefone          = trim($_POST['telefone'] ?? '');
    $email             = trim($_POST['email'] ?? '');
    $endereco          = trim($_POST['endereco'] ?? '');
    $convenio          = trim($_POST['convenio'] ?? '');
    $numero_carteirinha = trim($_POST['numero_carteirinha'] ?? '');

    // Validações
    if (empty($nome)) $erros[] = "O nome do paciente é obrigatório.";
    if (!empty($cpf)) {
        // Verificar se CPF já existe
        $check = $pdo->prepare("SELECT id FROM pacientes WHERE cpf = ?");
        $check->execute([$cpf]);
        if ($check->fetch()) $erros[] = "CPF já cadastrado para outro paciente.";
    }
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erros[] = "E-mail inválido.";
    }

    if (empty($erros)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO pacientes (nome, data_nascimento, cpf, rg, telefone, email, endereco, convenio, numero_carteirinha) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$nome, $data_nascimento, $cpf, $rg, $telefone, $email, $endereco, $convenio, $numero_carteirinha])) {
                session_start();
                $_SESSION['flash'] = ['tipo' => 'success', 'msg' => 'Paciente cadastrado com sucesso!'];
                header('Location: ../pacientes.php');
                exit;
            } else {
                $erros[] = "Erro ao salvar paciente. Tente novamente.";
            }
        } catch (PDOException $e) {
            $erros[] = "Erro no banco de dados: " . $e->getMessage();
        }
    }
}

// ============================================
// DADOS DO USUÁRIO LOGADO (para exibir na sidebar)
// ============================================
$usuario_nome  = $_SESSION['usuario_nome']  ?? 'Usuário';
$usuario_tipo  = $_SESSION['usuario_tipo']  ?? 'usuario';
$usuario_iniciais = strtoupper(substr($usuario_nome, 0, 2));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Novo Paciente | Alfa Saúde</title>
    <!-- Font Awesome, Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ===== VARIÁVEIS GLOBAIS (copiadas do dashboard) ===== */
        :root {
            --primary: #6f42c1;
            --primary-light: #6f42c1dd;
            --primary-dark: #6f42c1aa;
            --secondary: #20c997;
            --secondary-light: #20c997dd;
            --danger: #ff4757;
            --warning: #ff9f43;
            --info: #2e86de;
            --light: #f8f9fa;
            --dark: #343a40;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --border-radius: 12px;
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 8px 30px rgba(0, 0, 0, 0.12);
            --transition: all 0.3s ease;
            --sidebar-width: 280px;
            --topbar-height: 80px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fb 0%, #eef2f7 100%);
            color: var(--dark);
            line-height: 1.6;
            min-height: 100vh;
            overflow-x: hidden;
        }

        body.dark-theme {
            --light: #1a1d23;
            --dark: #f8f9fa;
            --gray: #adb5bd;
            --light-gray: #2d3239;
            background: linear-gradient(135deg, #121416 0%, #1a1d23 100%);
            color: #f8f9fa;
        }

        /* ===== LAYOUT PRINCIPAL ===== */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
            position: relative;
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            z-index: 1000;
            transition: var(--transition);
            box-shadow: 3px 0 20px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
        }

        .dark-theme .sidebar {
            box-shadow: 3px 0 20px rgba(0, 0, 0, 0.3);
        }

        .sidebar-header {
            padding: 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.15);
            background: rgba(255, 255, 255, 0.05);
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-icon {
            width: 45px;
            height: 45px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            flex-shrink: 0;
        }

        .logo-icon i {
            font-size: 22px;
        }

        .logo-text h2 {
            font-size: 18px;
            font-weight: 700;
            margin: 0;
            letter-spacing: 0.5px;
            line-height: 1.2;
        }

        .logo-text p {
            font-size: 12px;
            opacity: 0.9;
            margin: 3px 0 0 0;
            font-weight: 300;
        }

        .sidebar-menu {
            flex: 1;
            padding: 25px 0;
            overflow-y: auto;
        }

        .menu-section {
            margin-bottom: 25px;
            padding: 0 25px;
        }

        .menu-section h3 {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            opacity: 0.7;
            margin-bottom: 15px;
            font-weight: 600;
        }

        .menu-section ul {
            list-style: none;
        }

        .menu-section li {
            margin-bottom: 5px;
        }

        .menu-section a {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 15px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            border-radius: 8px;
            transition: var(--transition);
            position: relative;
            font-weight: 500;
            font-size: 14px;
        }

        .menu-section a:hover,
        .menu-section a.active {
            background: rgba(255, 255, 255, 0.12);
            color: white;
        }

        .menu-section a.active {
            background: rgba(255, 255, 255, 0.18);
            font-weight: 600;
        }

        .menu-section a.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 4px;
            height: 60%;
            background: var(--secondary);
            border-radius: 0 4px 4px 0;
        }

        .menu-section a i {
            font-size: 16px;
            width: 20px;
            text-align: center;
        }

        .menu-badge {
            margin-left: auto;
            background: var(--secondary);
            color: white;
            font-size: 11px;
            padding: 3px 8px;
            border-radius: 10px;
            font-weight: 600;
            min-width: 20px;
            text-align: center;
        }

        .menu-badge.new {
            background: var(--danger);
        }

        .menu-badge.alert {
            background: var(--warning);
        }

        .user-profile {
            padding: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.15);
            display: flex;
            align-items: center;
            gap: 15px;
            background: rgba(255, 255, 255, 0.05);
            position: sticky;
            bottom: 0;
        }

        .user-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            overflow: hidden;
            background: linear-gradient(135deg, var(--primary-light), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            flex-shrink: 0;
        }

        .avatar-placeholder {
            font-size: 16px;
            font-weight: 700;
            color: white;
        }

        .online-status {
            position: absolute;
            bottom: 3px;
            right: 3px;
            width: 12px;
            height: 12px;
            background: var(--secondary);
            border-radius: 50%;
            border: 2px solid var(--primary-dark);
        }

        .user-info {
            flex: 1;
            min-width: 0;
        }

        .user-info h4 {
            font-size: 14px;
            font-weight: 600;
            margin: 0 0 4px 0;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .user-info p {
            font-size: 12px;
            opacity: 0.9;
            margin: 0;
            font-weight: 400;
        }

        .user-actions a {
            color: rgba(255, 255, 255, 0.8);
            font-size: 16px;
            transition: var(--transition);
            padding: 8px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .user-actions a:hover {
            background: rgba(255, 255, 255, 0.15);
            color: white;
        }

        /* ===== CONTEÚDO PRINCIPAL ===== */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            transition: var(--transition);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        @media (max-width: 1199px) {
            .main-content {
                margin-left: 0;
            }
        }

        /* ===== TOP BAR ===== */
        .top-bar {
            background: white;
            padding: 15px 25px;
            box-shadow: var(--shadow);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 900;
            gap: 15px;
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95);
            flex-wrap: wrap;
            min-height: var(--topbar-height);
        }

        .dark-theme .top-bar {
            background: rgba(26, 29, 35, 0.95);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        }

        .top-bar-left {
            display: flex;
            align-items: center;
            gap: 15px;
            flex: 1;
            min-width: 0;
        }

        .sidebar-toggle {
            display: none;
            background: var(--primary);
            border: none;
            color: white;
            font-size: 18px;
            cursor: pointer;
            padding: 10px;
            border-radius: 8px;
            transition: var(--transition);
            flex-shrink: 0;
            width: 40px;
            height: 40px;
            align-items: center;
            justify-content: center;
        }

        .sidebar-toggle:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }

        .search-bar {
            flex: 1;
            min-width: 200px;
            max-width: 500px;
            position: relative;
        }

        .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            font-size: 14px;
            z-index: 1;
        }

        .search-bar input {
            width: 100%;
            padding: 12px 15px 12px 40px;
            border: 2px solid var(--light-gray);
            border-radius: var(--border-radius);
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            transition: var(--transition);
            background: white;
            color: var(--dark);
        }

        .dark-theme .search-bar input {
            background: var(--light);
            border-color: #3d4249;
            color: var(--dark);
        }

        .search-bar input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(111, 66, 193, 0.15);
        }

        .top-bar-right {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .notification-btn,
        .message-btn {
            position: relative;
            background: var(--light);
            border: none;
            font-size: 16px;
            color: var(--gray);
            cursor: pointer;
            padding: 10px;
            border-radius: 8px;
            transition: var(--transition);
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .dark-theme .notification-btn,
        .dark-theme .message-btn {
            background: #2d3239;
        }

        .notification-btn:hover,
        .message-btn:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-2px);
        }

        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            font-size: 10px;
            font-weight: 700;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid white;
        }

        .dark-theme .notification-badge {
            border-color: #1a1d23;
        }

        .theme-toggle {
            background: var(--light);
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
            font-size: 16px;
            color: var(--gray);
        }

        .dark-theme .theme-toggle {
            background: #2d3239;
        }

        .theme-toggle:hover {
            background: var(--primary);
            color: white;
            transform: rotate(30deg);
        }

        .quick-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .quick-action-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: none;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
            font-size: 16px;
            text-decoration: none;
        }

        .quick-action-btn:hover {
            transform: translateY(-3px) scale(1.1);
            box-shadow: 0 6px 20px rgba(111, 66, 193, 0.4);
        }

        /* ===== CONTEÚDO DO DASHBOARD ===== */
        .dashboard-content {
            padding: 25px;
            flex: 1;
            overflow-y: auto;
        }

        /* ===== SEÇÃO DE BOAS-VINDAS (adaptada para título) ===== */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-header h1 {
            font-size: 24px;
            font-weight: 700;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .dark-theme .page-header h1 {
            color: #f8f9fa;
        }

        .btn-primary, .btn-secondary {
            padding: 12px 20px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
            text-decoration: none;
            white-space: nowrap;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(111, 66, 193, 0.4);
        }

        .btn-secondary {
            background: var(--light-gray);
            color: var(--dark);
        }

        .btn-secondary:hover {
            background: var(--gray);
            color: white;
        }

        .dark-theme .btn-secondary {
            background: #2d3239;
            color: #f8f9fa;
        }

        .dark-theme .btn-secondary:hover {
            background: #3d4249;
        }

        /* ===== FORMULÁRIO ===== */
        .form-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 30px;
            box-shadow: var(--shadow);
            max-width: 800px;
            margin: 0 auto;
        }

        .dark-theme .form-card {
            background: #1a1d23;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: var(--dark);
        }

        .dark-theme .form-group label {
            color: #f8f9fa;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid var(--light-gray);
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            transition: var(--transition);
            background: white;
            color: var(--dark);
        }

        .dark-theme .form-group input,
        .dark-theme .form-group select,
        .dark-theme .form-group textarea {
            background: #2d3239;
            border-color: #3d4249;
            color: #f8f9fa;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-actions {
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            margin-top: 30px;
        }

        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            background: var(--danger);
            color: white;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert i {
            font-size: 20px;
        }

        .alert ul {
            margin-left: 20px;
        }

        /* ===== RODAPÉ ===== */
        .main-footer {
            background: white;
            padding: 15px 25px;
            border-top: 1px solid var(--light-gray);
            text-align: center;
            font-size: 13px;
            color: var(--gray);
        }

        .dark-theme .main-footer {
            background: #1a1d23;
            border-top-color: #2d3239;
        }

        .footer-content {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .footer-content a {
            color: var(--primary);
            text-decoration: none;
        }

        /* ===== RESPONSIVIDADE ===== */
        @media (max-width: 1199px) {
            .sidebar {
                transform: translateX(-100%);
                width: 300px;
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .sidebar-toggle {
                display: flex;
            }
            .sidebar-overlay.active {
                display: block;
            }
        }

        @media (max-width: 992px) {
            .dashboard-content { padding: 20px; }
            .form-row { grid-template-columns: 1fr; }
        }

        @media (max-width: 768px) {
            .form-actions { flex-direction: column; }
            .btn-primary, .btn-secondary { width: 100%; justify-content: center; }
        }

        /* Overlay do sidebar */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 999;
        }

        /* Preloader */
        .preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            transition: opacity 0.5s;
        }
        .dark-theme .preloader {
            background: #1a1d23;
        }
        .loader {
            text-align: center;
        }
        .loader i {
            font-size: 50px;
            color: var(--primary);
            margin-bottom: 20px;
            animation: bounce 1.5s infinite;
        }
        @keyframes bounce {
            0%,100%{transform:translateY(0);}
            50%{transform:translateY(-15px);}
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader" id="preloader">
        <div class="loader">
            <i class="fas fa-stethoscope"></i>
            <div>Carregando...</div>
        </div>
    </div>

    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="fas fa-stethoscope"></i>
                    </div>
                    <div class="logo-text">
                        <h2>Alfa Saúde</h2>
                        <p>Gestão Clínica</p>
                    </div>
                </div>
            </div>

            <div class="sidebar-menu">
                <div class="menu-section">
                    <h3>Menu Principal</h3>
                    <ul>
                        <li><a href="../dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                        <li><a href="../agendamentos.php"><i class="fas fa-calendar-alt"></i> Agenda</a></li>
                        <li><a href="../pacientes.php" class="active"><i class="fas fa-user-injured"></i> Pacientes</a></li>
                        <li><a href="../usuarios.php"><i class="fas fa-user-md"></i> Usuários</a></li>
                    </ul>
                </div>
                <div class="menu-section">
                    <h3>Atendimento</h3>
                    <ul>
                        <li><a href="../prontuarios.php"><i class="fas fa-notes-medical"></i> Prontuários</a></li>
                        <li><a href="../receituarios.php"><i class="fas fa-prescription"></i> Receituários</a></li>
                        <li><a href="../declaracoes.php"><i class="fas fa-file-medical"></i> Declarações</a></li>
                    </ul>
                </div>
                <?php if ($usuario_tipo === 'admin'): ?>
                <div class="menu-section">
                    <h3>Administração</h3>
                    <ul>
                        <li><a href="../clinica.php"><i class="fas fa-hospital"></i> Clínica</a></li>
                        <li><a href="../relatorios.php"><i class="fas fa-chart-line"></i> Relatórios</a></li>
                    </ul>
                </div>
                <?php endif; ?>
            </div>

            <div class="user-profile">
                <div class="user-avatar">
                    <div class="avatar-placeholder"><?php echo $usuario_iniciais; ?></div>
                    <div class="online-status"></div>
                </div>
                <div class="user-info">
                    <h4><?php echo htmlspecialchars($usuario_nome); ?></h4>
                    <p><?php echo ucfirst($usuario_tipo); ?></p>
                </div>
                <div class="user-actions">
                    <a href="../logout.php" title="Sair"><i class="fas fa-sign-out-alt"></i></a>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <header class="top-bar">
                <div class="top-bar-left">
                    <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <div class="search-bar">
                        <i class="fas fa-search"></i>
                        <input type="text" id="searchInput" placeholder="Pesquisar...">
                    </div>
                </div>
                <div class="top-bar-right">
                    <button class="notification-btn"><i class="fas fa-bell"></i><span class="notification-badge">0</span></button>
                    <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
                    <div class="quick-actions">
                        <a href="novo.php" class="quick-action-btn" title="Novo Paciente"><i class="fas fa-user-plus"></i></a>
                        <a href="../agendamentos/novo.php" class="quick-action-btn" title="Novo Agendamento"><i class="fas fa-calendar-plus"></i></a>
                    </div>
                </div>
            </header>

            <!-- Dashboard Content -->
            <div class="dashboard-content">
                <div class="page-header">
                    <h1><i class="fas fa-user-plus" style="color: var(--primary);"></i> Novo Paciente</h1>
                    <a href="../pacientes.php" class="btn-secondary"><i class="fas fa-arrow-left"></i> Voltar</a>
                </div>

                <?php if (!empty($erros)): ?>
                    <div class="alert">
                        <i class="fas fa-exclamation-circle"></i>
                        <ul>
                            <?php foreach ($erros as $erro): ?>
                                <li><?php echo htmlspecialchars($erro); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" class="form-card">
                    <div class="form-group">
                        <label>Nome Completo *</label>
                        <input type="text" name="nome" required value="<?php echo htmlspecialchars($_POST['nome'] ?? ''); ?>">
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Data de Nascimento</label>
                            <input type="date" name="data_nascimento" value="<?php echo htmlspecialchars($_POST['data_nascimento'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label>CPF</label>
                            <input type="text" name="cpf" value="<?php echo htmlspecialchars($_POST['cpf'] ?? ''); ?>" placeholder="000.000.000-00">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>RG</label>
                            <input type="text" name="rg" value="<?php echo htmlspecialchars($_POST['rg'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label>Telefone</label>
                            <input type="text" name="telefone" value="<?php echo htmlspecialchars($_POST['telefone'] ?? ''); ?>" placeholder="(00) 00000-0000">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>E-mail</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label>Endereço</label>
                        <textarea name="endereco" rows="2"><?php echo htmlspecialchars($_POST['endereco'] ?? ''); ?></textarea>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Convênio</label>
                            <input type="text" name="convenio" value="<?php echo htmlspecialchars($_POST['convenio'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label>Nº Carteirinha</label>
                            <input type="text" name="numero_carteirinha" value="<?php echo htmlspecialchars($_POST['numero_carteirinha'] ?? ''); ?>">
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn-primary"><i class="fas fa-save"></i> Salvar</button>
                        <a href="../pacientes.php" class="btn-secondary"><i class="fas fa-times"></i> Cancelar</a>
                    </div>
                </form>
            </div>

            <!-- Footer -->
            <footer class="main-footer">
                <div class="footer-content">
                    <p>desenvolvido por <a href="https://alfasistemas.dev.br" target="_blank">alfa sistemas s.a</a> (85) 2028-4584</p>
                </div>
            </footer>
        </main>
    </div>

    <script>
        // Preloader
        window.addEventListener('load', function() {
            setTimeout(() => {
                document.getElementById('preloader').style.opacity = '0';
                setTimeout(() => document.getElementById('preloader').style.display = 'none', 500);
            }, 800);
        });

        // Sidebar toggle
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('active');
                overlay.classList.toggle('active');
            });
            overlay.addEventListener('click', () => {
                sidebar.classList.remove('active');
                overlay.classList.remove('active');
            });
        }

        // Theme toggle
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark-theme');
                const icon = themeToggle.querySelector('i');
                if (document.body.classList.contains('dark-theme')) {
                    icon.className = 'fas fa-sun';
                    localStorage.setItem('theme', 'dark');
                } else {
                    icon.className = 'fas fa-moon';
                    localStorage.setItem('theme', 'light');
                }
            });
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-theme');
                themeToggle.querySelector('i').className = 'fas fa-sun';
            }
        }
    </script>
</body>
</html>