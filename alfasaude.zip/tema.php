<?php
require_once 'config/database.php';
$clinica = getClinica();
$page = $_GET['page'] ?? 'default';

// Definir variações de cor baseadas na página
$cores = [
    'dashboard' => ['primaria' => $clinica['cor_primaria'], 'secundaria' => $clinica['cor_secundaria']],
    'pacientes' => ['primaria' => '#28a745', 'secundaria' => '#20c997'], // verde
    'agendamentos' => ['primaria' => '#007bff', 'secundaria' => '#17a2b8'], // azul
    'medicos' => ['primaria' => '#6610f2', 'secundaria' => '#6f42c1'], // roxo
    // etc.
];

$cor_primaria = $cores[$page]['primaria'] ?? $clinica['cor_primaria'];
$cor_secundaria = $cores[$page]['secundaria'] ?? $clinica['cor_secundaria'];

header('Content-type: text/css');
echo "
:root {
    --primary: $cor_primaria;
    --primary-light: {$cor_primaria}dd;
    --primary-dark: {$cor_primaria}aa;
    --secondary: $cor_secundaria;
    --secondary-light: {$cor_secundaria}dd;
}
";