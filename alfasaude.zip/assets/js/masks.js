// Máscara para CPF
function mascaraCPF(i) {
    var v = i.value.replace(/\D/g, '');
    v = v.replace(/(\d{3})(\d)/, '$1.$2');
    v = v.replace(/(\d{3})(\d)/, '$1.$2');
    v = v.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    i.value = v;
}

// Máscara para telefone
function mascaraTelefone(i) {
    var v = i.value.replace(/\D/g, '');
    v = v.replace(/^(\d\d)(\d)/g, '($1) $2');
    v = v.replace(/(\d{4,5})(\d{4})/, '$1-$2');
    i.value = v;
}

// Aplicar máscaras aos campos com as classes
document.addEventListener('DOMContentLoaded', function() {
    var cpfs = document.querySelectorAll('.cpf-mask');
    cpfs.forEach(function(el) {
        el.addEventListener('input', function() { mascaraCPF(this); });
    });
    var phones = document.querySelectorAll('.phone-mask');
    phones.forEach(function(el) {
        el.addEventListener('input', function() { mascaraTelefone(this); });
    });
});