<?php
// ============================================
// ARQUIVO: receituarios/excluir.php
// DESCRIÇÃO: Exclui (fisicamente) um receituário
// ============================================

// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Iniciar sessão se necessário
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';
require_once '../config/auth.php';
verificarLogin();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'ID inválido.'];
    header('Location: ../receituarios.php');
    exit;
}

// Buscar dados do receituário para verificar permissão e existência
$stmt = $pdo->prepare("SELECT usuario_id FROM receituarios WHERE id = ?");
$stmt->execute([$id]);
$receituario = $stmt->fetch();

if (!$receituario) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Receituário não encontrado.'];
    header('Location: ../receituarios.php');
    exit;
}

// Verificar permissão: apenas o médico que criou ou administrador podem excluir
if (!hasPermissao('admin') && $_SESSION['usuario_id'] != $receituario['usuario_id']) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Você não tem permissão para excluir este receituário.'];
    header('Location: ../receituarios.php');
    exit;
}

try {
    $stmt = $pdo->prepare("DELETE FROM receituarios WHERE id = ?");
    if ($stmt->execute([$id])) {
        $_SESSION['flash'] = ['tipo' => 'success', 'msg' => 'Receituário excluído com sucesso!'];
    } else {
        $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Erro ao excluir receituário.'];
    }
} catch (PDOException $e) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Erro no banco de dados: ' . $e->getMessage()];
}

header('Location: ../receituarios.php');
exit;