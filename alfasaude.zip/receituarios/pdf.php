<?php
// ============================================
// ARQUIVO: receituarios/pdf.php
// DESCRIÇÃO: Versão para impressão do receituário (salvar como PDF pelo navegador)
// ============================================

// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/database.php';
require_once '../config/auth.php';
verificarLogin();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    die('ID inválido.');
}

// Buscar dados do receituário com informações do paciente e médico
$stmt = $pdo->prepare("
    SELECT r.*,
           p.nome as paciente_nome, p.data_nascimento as paciente_data_nascimento,
           p.cpf as paciente_cpf, p.telefone as paciente_telefone,
           p.email as paciente_email, p.convenio as paciente_convenio,
           u.nome as medico_nome, u.crm as medico_crm, u.especialidade as medico_especialidade
    FROM receituarios r
    JOIN pacientes p ON r.paciente_id = p.id
    JOIN usuarios u ON r.usuario_id = u.id
    WHERE r.id = ?
");
$stmt->execute([$id]);
$receituario = $stmt->fetch();

if (!$receituario) {
    die('Receituário não encontrado.');
}

// Buscar dados da clínica
$clinica = $pdo->query("SELECT * FROM clinica LIMIT 1")->fetch();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receituário #<?php echo $id; ?> - <?php echo htmlspecialchars($clinica['nome'] ?? 'Alfa Saúde'); ?></title>
    <!-- Font Awesome para ícones (opcional) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Reset e estilos básicos */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Arial', sans-serif;
            background: #f5f5f5;
            padding: 20px;
            display: flex;
            justify-content: center;
        }
        .receita-container {
            max-width: 800px;
            width: 100%;
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            padding: 30px;
        }
        /* Cabeçalho */
        .header {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
            border-bottom: 2px solid #6f42c1;
            padding-bottom: 20px;
        }
        .logo {
            width: 80px;
            height: 80px;
            background: #6f42c1;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 40px;
        }
        .logo img {
            max-width: 100%;
            max-height: 100%;
            border-radius: 50%;
        }
        .titulo {
            flex: 1;
        }
        .titulo h1 {
            color: #6f42c1;
            font-size: 28px;
            margin-bottom: 5px;
        }
        .titulo p {
            color: #666;
            font-size: 14px;
        }
        /* Código de verificação */
        .codigo {
            text-align: right;
            font-family: monospace;
            background: #f0f0f0;
            padding: 8px 12px;
            border-radius: 8px;
            font-size: 14px;
            color: #6f42c1;
            border: 1px dashed #6f42c1;
            margin-bottom: 20px;
        }
        /* Informações do paciente/médico */
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }
        .info-box {
            background: #f9f9f9;
            border-radius: 12px;
            padding: 15px;
        }
        .info-box h3 {
            color: #6f42c1;
            font-size: 16px;
            margin-bottom: 15px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 5px;
        }
        .info-row {
            display: flex;
            margin-bottom: 8px;
            font-size: 14px;
        }
        .info-label {
            width: 90px;
            font-weight: bold;
            color: #555;
        }
        .info-value {
            flex: 1;
            color: #333;
        }
        /* Seção de medicamentos */
        .medicamentos {
            margin-bottom: 30px;
        }
        .medicamentos h2 {
            color: #6f42c1;
            font-size: 18px;
            margin-bottom: 15px;
        }
        .medicamentos pre {
            background: #f9f9f9;
            border-radius: 8px;
            padding: 15px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            line-height: 1.6;
            white-space: pre-wrap;
            border-left: 4px solid #20c997;
        }
        /* Instruções */
        .instrucoes {
            margin-bottom: 30px;
        }
        .instrucoes h2 {
            color: #6f42c1;
            font-size: 18px;
            margin-bottom: 15px;
        }
        .instrucoes p {
            background: #f9f9f9;
            border-radius: 8px;
            padding: 15px;
            line-height: 1.6;
        }
        /* Assinatura */
        .assinatura {
            text-align: right;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
        }
        .assinatura p {
            margin-bottom: 5px;
        }
        .assinatura .nome {
            font-weight: bold;
            color: #6f42c1;
        }
        .assinatura .crm {
            color: #666;
        }
        /* Rodapé */
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 11px;
            color: #999;
        }
        .footer a {
            color: #6f42c1;
            text-decoration: none;
        }
        /* Botão de impressão (escondido na impressão) */
        .print-btn {
            display: block;
            width: 200px;
            margin: 20px auto 0;
            padding: 10px;
            background: #6f42c1;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
        }
        .print-btn:hover {
            background: #4a1e8a;
        }
        @media print {
            .print-btn { display: none; }
            body { background: white; padding: 0; }
            .receita-container { box-shadow: none; padding: 20px; }
        }
    </style>
</head>
<body>
    <div class="receita-container">
        <!-- Cabeçalho -->
        <div class="header">
            <div class="logo">
                <?php if (!empty($clinica['logo']) && file_exists('../assets/img/'.$clinica['logo'])): ?>
                    <img src="../assets/img/<?php echo $clinica['logo']; ?>" alt="Logo" style="width:100%; height:100%; border-radius:50%; object-fit:cover;">
                <?php else: ?>
                    <i class="fas fa-stethoscope"></i>
                <?php endif; ?>
            </div>
            <div class="titulo">
                <h1><?php echo htmlspecialchars($clinica['nome'] ?? 'Alfa Saúde'); ?></h1>
                <p><?php echo htmlspecialchars($clinica['endereco'] ?? ''); ?> | Tel: <?php echo htmlspecialchars($clinica['telefone'] ?? ''); ?></p>
                <p><?php echo htmlspecialchars($clinica['email'] ?? ''); ?></p>
            </div>
        </div>

        <!-- Código de verificação -->
        <div class="codigo">
            <i class="fas fa-qrcode"></i> Código de verificação: <strong><?php echo htmlspecialchars($receituario['codigo_verificacao']); ?></strong>
        </div>

        <!-- Informações do paciente e médico -->
        <div class="info-grid">
            <div class="info-box">
                <h3><i class="fas fa-user-injured"></i> Paciente</h3>
                <div class="info-row">
                    <span class="info-label">Nome:</span>
                    <span class="info-value"><strong><?php echo htmlspecialchars($receituario['paciente_nome']); ?></strong></span>
                </div>
                <?php if ($receituario['paciente_data_nascimento']): ?>
                <div class="info-row">
                    <span class="info-label">Nascimento:</span>
                    <span class="info-value"><?php echo date('d/m/Y', strtotime($receituario['paciente_data_nascimento'])); ?></span>
                </div>
                <?php endif; ?>
                <?php if ($receituario['paciente_cpf']): ?>
                <div class="info-row">
                    <span class="info-label">CPF:</span>
                    <span class="info-value"><?php echo htmlspecialchars($receituario['paciente_cpf']); ?></span>
                </div>
                <?php endif; ?>
                <?php if ($receituario['paciente_telefone']): ?>
                <div class="info-row">
                    <span class="info-label">Telefone:</span>
                    <span class="info-value"><?php echo htmlspecialchars($receituario['paciente_telefone']); ?></span>
                </div>
                <?php endif; ?>
                <div class="info-row">
                    <span class="info-label">Convênio:</span>
                    <span class="info-value"><?php echo htmlspecialchars($receituario['paciente_convenio'] ?? 'Particular'); ?></span>
                </div>
            </div>
            <div class="info-box">
                <h3><i class="fas fa-user-md"></i> Médico</h3>
                <div class="info-row">
                    <span class="info-label">Nome:</span>
                    <span class="info-value"><strong><?php echo htmlspecialchars($receituario['medico_nome']); ?></strong></span>
                </div>
                <?php if ($receituario['medico_crm']): ?>
                <div class="info-row">
                    <span class="info-label">CRM:</span>
                    <span class="info-value"><?php echo htmlspecialchars($receituario['medico_crm']); ?></span>
                </div>
                <?php endif; ?>
                <?php if ($receituario['medico_especialidade']): ?>
                <div class="info-row">
                    <span class="info-label">Especialidade:</span>
                    <span class="info-value"><?php echo htmlspecialchars($receituario['medico_especialidade']); ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Medicamentos -->
        <div class="medicamentos">
            <h2><i class="fas fa-pills"></i> Medicamentos Prescritos</h2>
            <pre><?php echo htmlspecialchars($receituario['medicamentos']); ?></pre>
        </div>

        <!-- Instruções (se houver) -->
        <?php if (!empty($receituario['instrucoes'])): ?>
        <div class="instrucoes">
            <h2><i class="fas fa-info-circle"></i> Instruções Adicionais</h2>
            <p><?php echo nl2br(htmlspecialchars($receituario['instrucoes'])); ?></p>
        </div>
        <?php endif; ?>

        <!-- Assinatura -->
        <div class="assinatura">
            <p><?php echo $clinica['cidade'] ?? ''; ?>, <?php echo date('d/m/Y'); ?></p>
            <p class="nome">Dr(a). <?php echo htmlspecialchars($receituario['medico_nome']); ?></p>
            <p class="crm">CRM <?php echo htmlspecialchars($receituario['medico_crm'] ?? ''); ?></p>
        </div>

        <!-- Rodapé -->
        <div class="footer">
            <p>Este documento pode ser verificado pelo código: <?php echo htmlspecialchars($receituario['codigo_verificacao']); ?></p>
            <p>desenvolvido por <a href="https://alfasistemas.dev.br" target="_blank">alfa sistemas s.a</a> (85) 2028-4584</p>
        </div>

        <!-- Botão para imprimir (salvar como PDF) -->
        <button class="print-btn" onclick="window.print()"><i class="fas fa-print"></i> Imprimir / Salvar PDF</button>
    </div>
</body>
</html>