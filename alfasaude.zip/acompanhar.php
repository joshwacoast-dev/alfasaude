<?php
require_once 'config/database.php';
$hash = $_GET['hash'] ?? '';
if (!$hash) die('Hash inválido');

$stmt = $pdo->prepare("SELECT p.*, a.data_hora, a.status, pac.nome as paciente, m.nome as medico 
                       FROM progresso_paciente p
                       JOIN agendamentos a ON p.agendamento_id = a.id
                       JOIN pacientes pac ON p.paciente_id = pac.id
                       JOIN medicos m ON a.medico_id = m.id
                       WHERE p.qrcode_hash = ?");
$stmt->execute([$hash]);
$progresso = $stmt->fetch();

if (!$progresso) die('Registro não encontrado');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Acompanhamento de Consulta</title>
    <style>
        body { font-family: Arial; background: #f5f5f5; padding: 20px; }
        .card { background: white; max-width: 600px; margin: auto; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .status { padding: 10px; border-radius: 5px; }
        .concluido { background: #d4edda; color: #155724; }
        .pendente { background: #fff3cd; color: #856404; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Olá, <?php echo $progresso['paciente']; ?>!</h2>
        <p>Médico: <?php echo $progresso['medico']; ?></p>
        <p>Data da consulta: <?php echo date('d/m/Y H:i', strtotime($progresso['data_hora'])); ?></p>
        <p>Status atual: <span class="status <?php echo $progresso['status']; ?>"><?php echo ucfirst($progresso['status']); ?></span></p>
        <p>Etapa: <?php echo $progresso['etapa'] ?: 'Aguardando início'; ?></p>
        <hr>
        <p>Última atualização: <?php echo date('d/m/Y H:i', strtotime($progresso['data_atualizacao'])); ?></p>
    </div>
</body>
</html>