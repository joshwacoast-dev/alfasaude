<?php
// ============================================
// ARQUIVO: relatorios_print.php
// DESCRIÇÃO: Versão para impressão dos relatórios (tema institucional)
// ============================================

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config/database.php';
require_once 'config/auth.php';
verificarLogin();

if (!hasPermissao('medico')) {
    die('Acesso negado.');
}

$tipo_relatorio = $_GET['tipo'] ?? 'atendimentos';
$data_inicio    = $_GET['data_inicio'] ?? date('Y-m-01');
$data_fim       = $_GET['data_fim'] ?? date('Y-m-d');
$medico_id      = isset($_GET['medico_id']) ? intval($_GET['medico_id']) : 0;

$dados = [];
$colunas = [];

switch ($tipo_relatorio) {
    case 'atendimentos':
        $sql = "SELECT a.data_hora, p.nome as paciente, u.nome as medico, a.tipo_consulta, a.status
                FROM agendamentos a
                JOIN pacientes p ON a.paciente_id = p.id
                JOIN usuarios u ON a.usuario_id = u.id
                WHERE DATE(a.data_hora) BETWEEN :data_inicio AND :data_fim";
        $params = [':data_inicio' => $data_inicio, ':data_fim' => $data_fim];
        if ($medico_id > 0) {
            $sql .= " AND a.usuario_id = :medico_id";
            $params[':medico_id'] = $medico_id;
        }
        $sql .= " ORDER BY a.data_hora DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $dados = $stmt->fetchAll();
        $colunas = ['Data/Hora', 'Paciente', 'Médico', 'Tipo', 'Status'];
        break;
    case 'pacientes':
        $sql = "SELECT id, nome, data_nascimento, telefone, email, convenio, data_cadastro
                FROM pacientes
                WHERE DATE(data_cadastro) BETWEEN :data_inicio AND :data_fim
                ORDER BY data_cadastro DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':data_inicio' => $data_inicio, ':data_fim' => $data_fim]);
        $dados = $stmt->fetchAll();
        $colunas = ['ID', 'Nome', 'Nascimento', 'Telefone', 'E-mail', 'Convênio', 'Cadastro'];
        break;
    case 'receituarios':
        $sql = "SELECT r.data_emissao, p.nome as paciente, u.nome as medico, r.codigo_verificacao
                FROM receituarios r
                JOIN pacientes p ON r.paciente_id = p.id
                JOIN usuarios u ON r.usuario_id = u.id
                WHERE DATE(r.data_emissao) BETWEEN :data_inicio AND :data_fim";
        $params = [':data_inicio' => $data_inicio, ':data_fim' => $data_fim];
        if ($medico_id > 0) {
            $sql .= " AND r.usuario_id = :medico_id";
            $params[':medico_id'] = $medico_id;
        }
        $sql .= " ORDER BY r.data_emissao DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $dados = $stmt->fetchAll();
        $colunas = ['Data', 'Paciente', 'Médico', 'Código'];
        break;
    case 'declaracoes':
        $sql = "SELECT d.data_emissao, p.nome as paciente, u.nome as medico, d.tipo, d.codigo_verificacao
                FROM declaracoes d
                JOIN pacientes p ON d.paciente_id = p.id
                JOIN usuarios u ON d.usuario_id = u.id
                WHERE DATE(d.data_emissao) BETWEEN :data_inicio AND :data_fim";
        $params = [':data_inicio' => $data_inicio, ':data_fim' => $data_fim];
        if ($medico_id > 0) {
            $sql .= " AND d.usuario_id = :medico_id";
            $params[':medico_id'] = $medico_id;
        }
        $sql .= " ORDER BY d.data_emissao DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $dados = $stmt->fetchAll();
        $colunas = ['Data', 'Paciente', 'Médico', 'Tipo', 'Código'];
        break;
    default:
        $tipo_relatorio = 'atendimentos';
}

$clinica = $pdo->query("SELECT * FROM clinica LIMIT 1")->fetch();
$cores = function_exists('getCoresTema') ? getCoresTema() : ['primaria' => '#6f42c1', 'secundaria' => '#20c997'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório - <?php echo ucfirst($tipo_relatorio); ?> | Alfa Saúde</title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: Arial, sans-serif;
            background: white;
            color: #333;
            padding: 20px;
            line-height: 1.5;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid <?php echo $cores['primaria']; ?>;
        }
        .logo {
            max-height: 70px;
            margin-bottom: 10px;
        }
        h1 {
            font-size: 22px;
            color: <?php echo $cores['primaria']; ?>;
            margin: 5px 0;
        }
        .clinica-info {
            font-size: 13px;
            color: #666;
        }
        .relatorio-titulo {
            font-size: 18px;
            font-weight: bold;
            color: <?php echo $cores['secundaria']; ?>;
            margin: 15px 0 5px;
        }
        .periodo {
            font-size: 13px;
            color: #555;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 12px;
        }
        th {
            background: <?php echo $cores['primaria']; ?>;
            color: white;
            padding: 10px;
            text-align: left;
            font-weight: 600;
        }
        td {
            padding: 8px 10px;
            border-bottom: 1px solid #ddd;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        .status-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: bold;
            text-transform: uppercase;
        }
        .status-agendado { background: #fff3cd; color: #856404; }
        .status-confirmado { background: #cce5ff; color: #004085; }
        .status-em_andamento { background: #d4edda; color: #155724; }
        .status-concluido { background: #d4edda; color: #155724; }
        .status-cancelado { background: #f8d7da; color: #721c24; }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 10px;
            color: #888;
            border-top: 1px solid #ccc;
            padding-top: 10px;
        }
        .no-data {
            text-align: center;
            padding: 40px;
            color: #888;
            font-size: 14px;
        }
        .no-print {
            text-align: center;
            margin-top: 20px;
        }
        .btn-print {
            background: <?php echo $cores['primaria']; ?>;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
        }
        .btn-print:hover {
            background: <?php echo $cores['primary-dark']; ?>;
        }
        @media print {
            .no-print { display: none; }
            th { background: #6f42c1; color: white; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            body { padding: 0; }
        }
    </style>
</head>
<body>
    <div class="header">
        <?php if (!empty($clinica['logo']) && file_exists('assets/img/' . $clinica['logo'])): ?>
            <img src="assets/img/<?php echo $clinica['logo']; ?>" class="logo" alt="Logo">
        <?php endif; ?>
        <h1><?php echo htmlspecialchars($clinica['nome'] ?? 'Alfa Saúde'); ?></h1>
        <div class="clinica-info">
            <?php echo htmlspecialchars($clinica['endereco'] ?? ''); ?><br>
            Tel: <?php echo htmlspecialchars($clinica['telefone'] ?? ''); ?> | E-mail: <?php echo htmlspecialchars($clinica['email'] ?? ''); ?>
        </div>
    </div>

    <div class="relatorio-titulo">
        <?php
        switch($tipo_relatorio) {
            case 'atendimentos': echo 'Relatório de Atendimentos'; break;
            case 'pacientes': echo 'Relatório de Pacientes Cadastrados'; break;
            case 'receituarios': echo 'Relatório de Receituários Emitidos'; break;
            case 'declaracoes': echo 'Relatório de Declarações Emitidas'; break;
        }
        ?>
    </div>
    <div class="periodo">
        Período: <?php echo date('d/m/Y', strtotime($data_inicio)); ?> a <?php echo date('d/m/Y', strtotime($data_fim)); ?>
    </div>

    <?php if (count($dados) > 0): ?>
    <table>
        <thead>
            <tr>
                <?php foreach ($colunas as $col): ?>
                    <th><?php echo $col; ?></th>
                <?php endforeach; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($dados as $row): ?>
            <tr>
                <?php foreach ($row as $key => $value): ?>
                    <td>
                        <?php
                        if (strpos($key, 'data') !== false && !empty($value) && $key != 'data_nascimento') {
                            echo date('d/m/Y H:i', strtotime($value));
                        } elseif ($key == 'data_nascimento' && !empty($value)) {
                            echo date('d/m/Y', strtotime($value));
                        } elseif ($key == 'status') {
                            echo '<span class="status-badge status-'.strtolower($value).'">'.ucfirst($value).'</span>';
                        } elseif ($key == 'codigo_verificacao') {
                            echo '<code>'.htmlspecialchars($value).'</code>';
                        } else {
                            echo htmlspecialchars($value ?? '-');
                        }
                        ?>
                    </td>
                <?php endforeach; ?>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
        <div class="no-data">Nenhum registro encontrado para o período.</div>
    <?php endif; ?>

    <div class="footer">
        Relatório gerado em <?php echo date('d/m/Y H:i:s'); ?> por <?php echo htmlspecialchars($_SESSION['usuario_nome'] ?? 'Sistema'); ?><br>
        desenvolvido por <a href="https://alfasistemas.dev.br" target="_blank">alfa sistemas s.a</a> (85) 2028-4584
    </div>

    <div class="no-print">
        <button class="btn-print" onclick="window.print();"><i class="fas fa-print"></i> Imprimir / Salvar PDF</button>
    </div>

    <!-- Font Awesome para ícone (opcional) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</body>
</html>