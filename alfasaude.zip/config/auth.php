<?php
// 1. Inicia a sessão APENAS se ela ainda não estiver ativa
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'database.php';

// ============================================
// 🔐 CHAVE SECRETA E FUNÇÃO DE VALIDAÇÃO
// ============================================
if (!defined('CHAVE_SECRETA_LICENCA')) {
    define('CHAVE_SECRETA_LICENCA', 'ALFA@S4Ud3#2026!Ch@v3Sup3rS3cr3t@');
}

// Função para validar o código criptográfico (usada na tela de bloqueio)
function validarCodigoLicencaAuth($codigo) {
    $codigo = strtoupper(trim($codigo));
    if (!preg_match('/^ALFA-([A-F0-9]{4})-([A-F0-9]{4})-([A-F0-9]{4})-([A-F0-9]{4})$/', $codigo, $matches)) {
        return ['valido' => false, 'dias' => 0, 'erro' => 'Formato de código inválido.'];
    }
    
    $dados = $matches[1] . $matches[2] . $matches[3];
    $assinatura_calculada = strtoupper(substr(hash_hmac('sha256', $dados, CHAVE_SECRETA_LICENCA), 0, 4));
    
    if (!hash_equals($assinatura_calculada, $matches[4])) {
        return ['valido' => false, 'dias' => 0, 'erro' => 'Código inválido ou não gerado por este sistema.'];
    }
    
    return ['valido' => true, 'dias' => hexdec($matches[1]), 'erro' => ''];
}

// ============================================
// PROCESSAR ATIVAÇÃO DIRETA DA TELA DE BLOQUEIO
// ============================================
$erro_ativacao = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'ativar_da_bloqueio') {
    $resultado = validarCodigoLicencaAuth($_POST['codigo_serial'] ?? '');
    
    if ($resultado['valido']) {
        // Busca dados atuais para calcular a nova data
        $stmt = $pdo->query("SELECT data_expiracao_licenca, status_licenca FROM clinica WHERE id = 1 LIMIT 1");
        $licenca_atual = $stmt->fetch(PDO::FETCH_ASSOC);
        $hoje = new DateTime();
        
        $base_data = ($licenca_atual['status_licenca'] === 'bloqueado' || new DateTime() > new DateTime($licenca_atual['data_expiracao_licenca'])) 
            ? clone $hoje 
            : new DateTime($licenca_atual['data_expiracao_licenca']);
            
        $base_data->modify("+{$resultado['dias']} days");
        
        $update = $pdo->prepare("UPDATE clinica SET data_expiracao_licenca = ?, status_licenca = 'ativo' WHERE id = 1");
        if ($update->execute([$base_data->format('Y-m-d H:i:s')])) {
            // Sucesso! Recarrega a página para entrar no sistema
            header('Location: ' . $_SERVER['REQUEST_URI']);
            exit;
        }
    } else {
        $erro_ativacao = $resultado['erro'];
    }
}

// ============================================
// FUNÇÕES DE AUTENTICAÇÃO
// ============================================
function login($email, $senha) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ? AND ativo = 1");
    $stmt->execute([$email]);
    $usuario = $stmt->fetch();

    if ($usuario && password_verify($senha, $usuario['senha'])) {
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['usuario_nome'] = $usuario['nome'];
        $_SESSION['usuario_tipo'] = $usuario['tipo'];
        $_SESSION['usuario_crm'] = $usuario['crm'];
        return true;
    }
    return false;
}

function verificarLogin() {
    if (!isset($_SESSION['usuario_id'])) {
        header('Location: login.php');
        exit;
    }

    // ==========================================
    // VERIFICAÇÃO DE LICENÇA CRIPTOGRÁFICA
    // ==========================================
    global $pdo;
    global $erro_ativacao;
    
    $stmt_licenca = $pdo->query("SELECT data_expiracao_licenca, status_licenca FROM clinica WHERE id = 1 LIMIT 1");
    $dados_licenca = $stmt_licenca->fetch(PDO::FETCH_ASSOC);

    if ($dados_licenca) {
        $hoje = new DateTime();
        $expiracao = new DateTime($dados_licenca['data_expiracao_licenca']);
        $expirou = ($hoje > $expiracao || $dados_licenca['status_licenca'] === 'bloqueado');

        // REGRA DE OURO: Permite o ADMIN acessar a página 'licenca.php' mesmo bloqueado
        $pagina_atual = basename($_SERVER['PHP_SELF']);
        $eh_admin = (isset($_SESSION['usuario_tipo']) && $_SESSION['usuario_tipo'] === 'admin');

        if ($expirou && !($eh_admin && $pagina_atual === 'licenca.php')) {
            
            // Garante que o banco de dados marque como bloqueado
            if ($dados_licenca['status_licenca'] !== 'bloqueado') {
                $pdo->prepare("UPDATE clinica SET status_licenca = 'bloqueado' WHERE id = 1")->execute();
            }
            
            $msg_erro = !empty($erro_ativacao) 
                ? '<p style="color:#ff4757; font-size:13px; margin-top:10px; background:rgba(255,71,87,0.1); padding:10px; border-radius:6px;"><i class="fas fa-exclamation-circle"></i> ' . htmlspecialchars($erro_ativacao) . '</p>' 
                : '';
            
            http_response_code(403);
            die("
                <!DOCTYPE html>
                <html lang='pt-BR'>
                <head>
                    <meta charset='UTF-8'>
                    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                    <title>Sistema Bloqueado | Alfa Saúde</title>
                    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap' rel='stylesheet'>
                    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>
                    <style>
                        * { margin: 0; padding: 0; box-sizing: border-box; }
                        body { 
                            font-family: 'Poppins', sans-serif; 
                            background: linear-gradient(135deg, #f5f7fb 0%, #eef2f7 100%); 
                            display: flex; 
                            align-items: center; 
                            justify-content: center; 
                            height: 100vh; 
                            margin: 0; 
                        }
                        .box { 
                            background: #ffffff; 
                            padding: 40px; 
                            border-radius: 16px; 
                            border-top: 5px solid #6f42c1; 
                            max-width: 450px; 
                            width: 90%;
                            box-shadow: 0 10px 40px rgba(111, 66, 193, 0.15); 
                            text-align: center;
                        }
                        .icon-lock {
                            width: 70px;
                            height: 70px;
                            background: rgba(111, 66, 193, 0.1);
                            color: #6f42c1;
                            border-radius: 50%;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            font-size: 32px;
                            margin: 0 auto 20px;
                        }
                        h1 { color: #343a40; font-size: 22px; margin-bottom: 10px; font-weight: 700; }
                        p { color: #6c757d; margin-bottom: 20px; font-size: 14px; line-height: 1.5; }
                        .data { 
                            background: #f8f9fa; 
                            padding: 12px 20px; 
                            border-radius: 8px; 
                            font-weight: 600; 
                            color: #ff4757; 
                            display: inline-block; 
                            margin-bottom: 25px; 
                            border: 1px solid rgba(255, 71, 87, 0.2);
                            font-size: 15px;
                        }
                        .form-group { margin-bottom: 20px; text-align: left; }
                        .form-group label { display: block; font-size: 13px; font-weight: 600; color: #343a40; margin-bottom: 6px; }
                        .form-input { 
                            width: 100%; 
                            padding: 14px 15px; 
                            border: 2px solid #e9ecef; 
                            border-radius: 8px; 
                            font-size: 16px; 
                            font-family: 'Courier New', monospace; 
                            font-weight: 700; 
                            text-align: center; 
                            letter-spacing: 1.5px;
                            text-transform: uppercase;
                            transition: 0.3s;
                        }
                        .form-input:focus { 
                            outline: none; 
                            border-color: #6f42c1; 
                            box-shadow: 0 0 0 3px rgba(111, 66, 193, 0.15); 
                        }
                        .btn-ativar { 
                            width: 100%; 
                            padding: 14px; 
                            background: #6f42c1; 
                            color: white; 
                            border: none; 
                            border-radius: 8px; 
                            font-size: 15px; 
                            font-weight: 600; 
                            cursor: pointer; 
                            transition: 0.3s;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            gap: 8px;
                        }
                        .btn-ativar:hover { 
                            background: #5a32a3; 
                            transform: translateY(-2px); 
                            box-shadow: 0 4px 15px rgba(111, 66, 193, 0.3);
                        }
                        .footer-text { margin-top: 25px; font-size: 12px; color: #adb5bd; }
                        .footer-text a { color: #6f42c1; text-decoration: none; font-weight: 600; }
                    </style>
                </head>
                <body>
                    <div class='box'>
                        <div class='icon-lock'><i class='fas fa-lock'></i></div>
                        <h1>Sistema Bloqueado</h1>
                        <p>A licença do sistema expirou ou foi suspensa. Insira o código de ativação para liberar o acesso imediatamente.</p>
                        <div class='data'><i class='fas fa-calendar-times'></i> Expiração: " . $expiracao->format('d/m/Y') . "</div>
                        
                        <form method='POST' action=''>
                            <input type='hidden' name='acao' value='ativar_da_bloqueio'>
                            <div class='form-group'>
                                <label>Código de Ativação:</label>
                                <input type='text' name='codigo_serial' class='form-input' placeholder='ALFA-XXXX-XXXX-XXXX-XXXX' required oninput='this.value = this.value.toUpperCase()'>
                            </div>
                            " . $msg_erro . "
                            <button type='submit' class='btn-ativar'>
                                <i class='fas fa-unlock'></i> Ativar Licença Agora
                            </button>
                        </form>
                        
                        <div class='footer-text'>
                            Dúvidas? Contate <a href='mailto:contato@alfasistemas.dev.br'>Alfa Sistemas S.A.</a>
                        </div>
                    </div>
                </body>
                </html>
            ");
        }
        
        // Salva os dias restantes na sessão para exibir no dashboard
        $_SESSION['dias_restantes_licenca'] = max(0, $hoje->diff($expiracao)->days);
    }
}

function hasPermissao($nivel_necessario) {
    if ($_SESSION['usuario_tipo'] === 'admin') return true;
    $niveis = ['admin' => 3, 'medico' => 2, 'atendente' => 1];
    $nivel_usuario = $niveis[$_SESSION['usuario_tipo']] ?? 0;
    return $nivel_usuario >= $niveis[$nivel_necessario];
}
?>