<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
require_once '../../vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("
    SELECT r.*, p.nome as paciente_nome, p.cpf, m.nome as medico_nome, m.crm
    FROM receituarios r
    JOIN pacientes p ON r.paciente_id = p.id
    JOIN medicos m ON r.medico_id = m.id
    WHERE r.id = ?
");
$stmt->execute([$id]);
$receita = $stmt->fetch();

if (!$receita) die('Receituário não encontrado');

$clinica = getClinica();
$medicamentos = explode("\n", trim($receita['medicamentos']));

$html = "
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial; }
        .header { text-align: center; margin-bottom: 20px; }
        .logo { max-height: 80px; }
        .title { font-size: 20px; color: {$clinica['cor_primaria']}; }
        .receita-item { border-bottom: 1px dashed #ccc; padding: 10px 0; }
        .codigo { text-align: center; font-size: 11px; color: #666; margin-top: 30px; }
    </style>
</head>
<body>
    <div class='header'>
        <img src='../../assets/img/{$clinica['logo']}' class='logo'><br>
        <h2 class='title'>{$clinica['nome']}</h2>
        <p>{$clinica['endereco']} - Tel: {$clinica['telefone']}</p>
    </div>
    <p><strong>Paciente:</strong> {$receita['paciente_nome']} (CPF: {$receita['cpf']})</p>
    <p><strong>Médico:</strong> Dr(a). {$receita['medico_nome']} (CRM {$receita['crm']})</p>
    <p><strong>Data de emissão:</strong> " . date('d/m/Y H:i', strtotime($receita['data_emissao'])) . "</p>
    <h3>Medicamentos prescritos:</h3>";

foreach ($medicamentos as $linha) {
    if (trim($linha) == '') continue;
    $parts = explode('|', $linha);
    $html .= "<div class='receita-item'>
        <strong>{$parts[0]}</strong><br>
        Dosagem: {$parts[1]}<br>
        Posologia: {$parts[2]}<br>
        Quantidade: {$parts[3]}
    </div>";
}

if ($receita['instrucoes']) {
    $html .= "<p><strong>Instruções:</strong><br>" . nl2br($receita['instrucoes']) . "</p>";
}

$html .= "<div class='codigo'>Código de verificação: {$receita['codigo_verificacao']}</div>
</body>
</html>";

$options = new Options();
$options->set('defaultFont', 'Arial');
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("receituario_{$id}.pdf", array("Attachment" => 0));