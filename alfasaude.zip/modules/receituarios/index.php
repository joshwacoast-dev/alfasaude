<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();

$paciente_id = $_GET['paciente_id'] ?? '';

$sql = "SELECT r.*, p.nome as paciente_nome, m.nome as medico_nome 
        FROM receituarios r
        JOIN pacientes p ON r.paciente_id = p.id
        JOIN medicos m ON r.medico_id = m.id";
$params = [];
if ($paciente_id) {
    $sql .= " WHERE r.paciente_id = :paciente";
    $params[':paciente'] = $paciente_id;
}
$sql .= " ORDER BY r.data_emissao DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$receitas = $stmt->fetchAll();

$pacientes = $pdo->query("SELECT id, nome FROM pacientes WHERE ativo=1 ORDER BY nome")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Receituários | <?php echo getNomeSistema(); ?></title>
    <link rel="stylesheet" href="../../assets/css/estilo.css">
</head>
<body>
    <?php include '../../includes/sidebar.php'; ?>
    <?php include '../../includes/topbar.php'; ?>
    <div class="dashboard-content">
        <div class="page-header">
            <h1><i class="fas fa-prescription"></i> Receituários</h1>
            <a href="novo.php" class="btn-primary">Novo Receituário</a>
        </div>
        <div class="filters-card">
            <form method="GET">
                <select name="paciente_id">
                    <option value="">Todos</option>
                    <?php foreach ($pacientes as $p): ?>
                        <option value="<?php echo $p['id']; ?>" <?php echo $p['id']==$paciente_id?'selected':''; ?>><?php echo $p['nome']; ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit">Filtrar</button>
            </form>
        </div>
        <table class="data-table">
            <thead><tr><th>Paciente</th><th>Médico</th><th>Data</th><th>Código</th><th>Ações</th></tr></thead>
            <tbody>
                <?php foreach ($receitas as $r): ?>
                <tr>
                    <td><?php echo $r['paciente_nome']; ?></td>
                    <td><?php echo $r['medico_nome']; ?></td>
                    <td><?php echo date('d/m/Y', strtotime($r['data_emissao'])); ?></td>
                    <td><?php echo $r['codigo_verificacao']; ?></td>
                    <td>
                        <a href="visualizar.php?id=<?php echo $r['id']; ?>">Ver</a>
                        <a href="pdf.php?id=<?php echo $r['id']; ?>" target="_blank">PDF</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php include '../../includes/footer.php'; ?>
</body>
</html>