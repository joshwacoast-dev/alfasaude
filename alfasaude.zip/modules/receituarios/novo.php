<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();
if (!hasPermissao('medico')) {
    header('Location: index.php');
    exit;
}

$paciente_id = $_GET['paciente_id'] ?? 0;
$pacientes = $pdo->query("SELECT id, nome FROM pacientes WHERE ativo=1 ORDER BY nome")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $paciente_id = $_POST['paciente_id'];
    $medico_id = $_SESSION['medico_id'];
    $medicamentos = $_POST['medicamentos']; // texto com linhas
    $instrucoes = $_POST['instrucoes'];

    // Gerar código de verificação único
    $codigo = bin2hex(random_bytes(8));

    $stmt = $pdo->prepare("INSERT INTO receituarios (paciente_id, medico_id, medicamentos, instrucoes, codigo_verificacao) VALUES (?,?,?,?,?)");
    if ($stmt->execute([$paciente_id, $medico_id, $medicamentos, $instrucoes, $codigo])) {
        header('Location: index.php?msg=sucesso');
        exit;
    }
}
?>
<form method="POST">
    <select name="paciente_id" required>...</select>
    <textarea name="medicamentos" placeholder="Medicamento|Dosagem|Posologia|Quantidade (um por linha)" required></textarea>
    <textarea name="instrucoes"></textarea>
    <button type="submit">Emitir Receita</button>
</form>