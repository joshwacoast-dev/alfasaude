<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();

$stmt = $pdo->query("SELECT * FROM medicos WHERE ativo=1 ORDER BY nome");
$medicos = $stmt->fetchAll();
?>
<!-- HTML com tabela e botões -->