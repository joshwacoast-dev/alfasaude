<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();
if (!hasPermissao('admin')) {
    header('Location: ../../dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
    $crm = $_POST['crm'];
    $especialidade = $_POST['especialidade'];
    $telefone = $_POST['telefone'];
    $nivel = $_POST['nivel'];

    $stmt = $pdo->prepare("INSERT INTO medicos (nome, email, senha, crm, especialidade, telefone, nivel) VALUES (?,?,?,?,?,?,?)");
    if ($stmt->execute([$nome, $email, $senha, $crm, $especialidade, $telefone, $nivel])) {
        header('Location: index.php?msg=sucesso');
        exit;
    }
}
?>
<!-- formulário -->