<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();
if (!hasPermissao('admin')) {
    header('Location: ../../dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nivel = $_POST['nivel'];
    $stmt = $pdo->prepare("UPDATE medicos SET nivel = ? WHERE id = ?");
    $stmt->execute([$nivel, $id]);
    header('Location: permissao.php?msg=sucesso');
    exit;
}

$stmt = $pdo->query("SELECT id, nome, email, nivel FROM medicos WHERE ativo=1 ORDER BY nome");
$medicos = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Permissões | <?php echo getNomeSistema(); ?></title>
    <link rel="stylesheet" href="../../assets/css/estilo.css">
</head>
<body>
    <?php include '../../includes/sidebar.php'; ?>
    <?php include '../../includes/topbar.php'; ?>
    <div class="dashboard-content">
        <h1><i class="fas fa-lock"></i> Gerenciar Permissões</h1>
        <table class="data-table">
            <thead>
                <tr><th>Médico</th><th>E-mail</th><th>Nível Atual</th><th>Alterar</th></tr>
            </thead>
            <tbody>
                <?php foreach ($medicos as $m): ?>
                <tr>
                    <td><?php echo $m['nome']; ?></td>
                    <td><?php echo $m['email']; ?></td>
                    <td><?php echo ucfirst($m['nivel']); ?></td>
                    <td>
                        <form method="POST" style="display:flex; gap:5px;">
                            <input type="hidden" name="id" value="<?php echo $m['id']; ?>">
                            <select name="nivel">
                                <option value="admin" <?php echo $m['nivel']=='admin'?'selected':''; ?>>Admin</option>
                                <option value="medico" <?php echo $m['nivel']=='medico'?'selected':''; ?>>Médico</option>
                                <option value="atendente" <?php echo $m['nivel']=='atendente'?'selected':''; ?>>Atendente</option>
                            </select>
                            <button type="submit" class="btn-small">Salvar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php include '../../includes/footer.php'; ?>
</body>
</html>