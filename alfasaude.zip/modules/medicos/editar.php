<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();
if (!hasPermissao('admin')) {
    header('Location: index.php');
    exit;
}

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM medicos WHERE id = ?");
$stmt->execute([$id]);
$medico = $stmt->fetch();

if (!$medico) {
    header('Location: index.php?erro=nao_encontrado');
    exit;
}

$erros = [];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $crm = $_POST['crm'];
    $especialidade = $_POST['especialidade'];
    $telefone = $_POST['telefone'];
    $nivel = $_POST['nivel'];
    $ativo = isset($_POST['ativo']) ? 1 : 0;

    if (!empty($_POST['senha'])) {
        $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE medicos SET nome=?, email=?, senha=?, crm=?, especialidade=?, telefone=?, nivel=?, ativo=? WHERE id=?");
        $params = [$nome, $email, $senha, $crm, $especialidade, $telefone, $nivel, $ativo, $id];
    } else {
        $stmt = $pdo->prepare("UPDATE medicos SET nome=?, email=?, crm=?, especialidade=?, telefone=?, nivel=?, ativo=? WHERE id=?");
        $params = [$nome, $email, $crm, $especialidade, $telefone, $nivel, $ativo, $id];
    }

    if ($stmt->execute($params)) {
        header('Location: index.php?msg=editado');
        exit;
    } else {
        $erros[] = "Erro ao atualizar.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Médico | <?php echo getNomeSistema(); ?></title>
    <link rel="stylesheet" href="../../assets/css/estilo.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include '../../includes/sidebar.php'; ?>
    <?php include '../../includes/topbar.php'; ?>
    <div class="dashboard-content">
        <h1><i class="fas fa-user-md"></i> Editar Médico</h1>
        <?php if ($erros): ?>
            <div class="alert alert-danger"><?php echo implode('<br>', $erros); ?></div>
        <?php endif; ?>
        <form method="POST" class="form-card">
            <div class="form-group">
                <label>Nome</label>
                <input type="text" name="nome" value="<?php echo htmlspecialchars($medico['nome']); ?>" required>
            </div>
            <div class="form-group">
                <label>E-mail</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($medico['email']); ?>" required>
            </div>
            <div class="form-group">
                <label>Senha (deixe em branco para não alterar)</label>
                <input type="password" name="senha">
            </div>
            <div class="form-group">
                <label>CRM</label>
                <input type="text" name="crm" value="<?php echo htmlspecialchars($medico['crm']); ?>" required>
            </div>
            <div class="form-group">
                <label>Especialidade</label>
                <input type="text" name="especialidade" value="<?php echo htmlspecialchars($medico['especialidade']); ?>">
            </div>
            <div class="form-group">
                <label>Telefone</label>
                <input type="text" name="telefone" value="<?php echo htmlspecialchars($medico['telefone']); ?>">
            </div>
            <div class="form-group">
                <label>Nível</label>
                <select name="nivel">
                    <option value="admin" <?php echo $medico['nivel']=='admin'?'selected':''; ?>>Administrador</option>
                    <option value="medico" <?php echo $medico['nivel']=='medico'?'selected':''; ?>>Médico</option>
                    <option value="atendente" <?php echo $medico['nivel']=='atendente'?'selected':''; ?>>Atendente</option>
                </select>
            </div>
            <div class="form-group">
                <label>
                    <input type="checkbox" name="ativo" value="1" <?php echo $medico['ativo']?'checked':''; ?>> Ativo
                </label>
            </div>
            <button type="submit" class="btn-primary">Salvar</button>
            <a href="index.php" class="btn-secondary">Cancelar</a>
        </form>
    </div>
    <?php include '../../includes/footer.php'; ?>
</body>
</html>