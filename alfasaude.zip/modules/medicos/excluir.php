<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();
if (!hasPermissao('admin')) {
    header('Location: index.php');
    exit;
}

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("UPDATE medicos SET ativo = 0 WHERE id = ?");
$stmt->execute([$id]);
header('Location: index.php?msg=excluido');
exit;