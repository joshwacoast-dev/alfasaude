<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();

$paciente_id = $_GET['paciente_id'] ?? '';

$sql = "SELECT d.*, p.nome as paciente_nome, m.nome as medico_nome 
        FROM declaracoes d
        JOIN pacientes p ON d.paciente_id = p.id
        JOIN medicos m ON d.medico_id = m.id";
$params = [];
if ($paciente_id) {
    $sql .= " WHERE d.paciente_id = :paciente";
    $params[':paciente'] = $paciente_id;
}
$sql .= " ORDER BY d.data_emissao DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$declaracoes = $stmt->fetchAll();

$pacientes = $pdo->query("SELECT id, nome FROM pacientes WHERE ativo=1 ORDER BY nome")->fetchAll();
?>
<!-- similar ao de receitas -->