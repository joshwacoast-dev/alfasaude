<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();
if (!hasPermissao('medico')) {
    header('Location: index.php');
    exit;
}

$paciente_id = $_GET['paciente_id'] ?? 0;
$pacientes = $pdo->query("SELECT id, nome FROM pacientes WHERE ativo=1 ORDER BY nome")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $paciente_id = $_POST['paciente_id'];
    $medico_id = $_SESSION['medico_id'];
    $tipo = $_POST['tipo'];
    $conteudo = $_POST['conteudo'];
    $codigo = bin2hex(random_bytes(8));

    $stmt = $pdo->prepare("INSERT INTO declaracoes (paciente_id, medico_id, tipo, conteudo, codigo_verificacao) VALUES (?,?,?,?,?)");
    if ($stmt->execute([$paciente_id, $medico_id, $tipo, $conteudo, $codigo])) {
        header('Location: index.php?msg=sucesso');
        exit;
    }
}
?>
<form>
    <select name="tipo">
        <option value="comparecimento">Comparecimento</option>
        <option value="saude_ocupacional">Saúde Ocupacional</option>
        <option value="atestado">Atestado</option>
        <option value="outros">Outros</option>
    </select>
    <textarea name="conteudo" placeholder="Texto da declaração" required></textarea>
    ...
</form>