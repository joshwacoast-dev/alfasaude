<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("
    SELECT d.*, p.nome as paciente_nome, p.cpf, m.nome as medico_nome, m.crm
    FROM declaracoes d
    JOIN pacientes p ON d.paciente_id = p.id
    JOIN medicos m ON d.medico_id = m.id
    WHERE d.id = ?
");
$stmt->execute([$id]);
$declaracao = $stmt->fetch();

if (!$declaracao) {
    header('Location: index.php?erro=nao_encontrado');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Declaração | <?php echo getNomeSistema(); ?></title>
    <link rel="stylesheet" href="../../assets/css/estilo.css">
    <style>
        .declaracao-box {
            border: 1px solid #ccc;
            padding: 30px;
            margin: 20px 0;
            background: white;
        }
    </style>
</head>
<body>
    <?php include '../../includes/sidebar.php'; ?>
    <?php include '../../includes/topbar.php'; ?>
    <div class="dashboard-content">
        <div class="page-header">
            <h1><i class="fas fa-file-medical"></i> Declaração</h1>
            <div class="page-actions">
                <a href="index.php?paciente_id=<?php echo $declaracao['paciente_id']; ?>" class="btn-secondary"><i class="fas fa-arrow-left"></i> Voltar</a>
                <a href="pdf.php?id=<?php echo $id; ?>" class="btn-success" target="_blank"><i class="fas fa-file-pdf"></i> Gerar PDF</a>
            </div>
        </div>

        <div class="declaracao-box">
            <?php
            $clinica = getClinica();
            ?>
            <div style="text-align: center;">
                <?php if ($clinica['logo']): ?>
                    <img src="../../assets/img/<?php echo $clinica['logo']; ?>" height="60">
                <?php endif; ?>
                <h2><?php echo $clinica['nome']; ?></h2>
                <p><?php echo $clinica['endereco']; ?> - Tel: <?php echo $clinica['telefone']; ?></p>
                <hr>
            </div>

            <h3 style="text-align: center;">DECLARAÇÃO <?php echo strtoupper($declaracao['tipo']); ?></h3>

            <p>Declaro para os devidos fins que o(a) paciente <strong><?php echo $declaracao['paciente_nome']; ?></strong>, CPF <?php echo $declaracao['cpf']; ?>, esteve em atendimento médico no dia <?php echo date('d/m/Y', strtotime($declaracao['data_emissao'])); ?>.</p>

            <div style="margin: 20px 0;">
                <?php echo nl2br($declaracao['conteudo']); ?>
            </div>

            <p style="text-align: right; margin-top: 40px;">
                <?php echo $clinica['cidade'] ?? ''; ?>, <?php echo date('d/m/Y'); ?><br><br>
                _________________________________<br>
                Dr(a). <?php echo $declaracao['medico_nome']; ?><br>
                CRM <?php echo $declaracao['crm']; ?>
            </p>

            <div style="text-align: center; font-size: 11px; color: #666; margin-top: 30px;">
                Código de verificação: <?php echo $declaracao['codigo_verificacao']; ?>
            </div>
        </div>
    </div>
    <?php include '../../includes/footer.php'; ?>
</body>
</html>