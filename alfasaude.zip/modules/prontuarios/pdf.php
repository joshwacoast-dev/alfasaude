<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
require_once '../../vendor/autoload.php'; // DOMPdf

use Dompdf\Dompdf;
use Dompdf\Options;

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT p.*, pac.nome as paciente, m.nome as medico, m.crm FROM prontuarios p JOIN pacientes pac ON p.paciente_id = pac.id JOIN medicos m ON p.medico_id = m.id WHERE p.id = ?");
$stmt->execute([$id]);
$prontuario = $stmt->fetch();

if (!$prontuario) die('Prontuário não encontrado');

$clinica = getClinica();

$html = "
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial; }
        .header { text-align: center; margin-bottom: 20px; }
        .logo { max-height: 80px; }
        .title { font-size: 20px; color: {$clinica['cor_primaria']}; }
        .content { margin-top: 20px; }
        .footer { margin-top: 30px; font-size: 12px; text-align: center; color: #666; }
    </style>
</head>
<body>
    <div class='header'>
        <img src='../../assets/img/{$clinica['logo']}' class='logo'><br>
        <h2 class='title'>{$clinica['nome']}</h2>
        <p>{$clinica['endereco']} - Tel: {$clinica['telefone']}</p>
    </div>
    <div class='content'>
        <h3>Prontuário Médico</h3>
        <p><strong>Paciente:</strong> {$prontuario['paciente']}</p>
        <p><strong>Médico:</strong> Dr. {$prontuario['medico']} (CRM {$prontuario['crm']})</p>
        <p><strong>Data do atendimento:</strong> " . date('d/m/Y H:i', strtotime($prontuario['data_atendimento'])) . "</p>
        <hr>
        <p><strong>Anamnese:</strong><br>" . nl2br($prontuario['anamnese']) . "</p>
        <p><strong>Exame Físico:</strong><br>" . nl2br($prontuario['exame_fisico']) . "</p>
        <p><strong>Hipótese Diagnóstica:</strong><br>" . nl2br($prontuario['hipotese_diagnostica']) . "</p>
        <p><strong>Diagnóstico Final:</strong><br>" . nl2br($prontuario['diagnostico_final']) . "</p>
        <p><strong>Conduta:</strong><br>" . nl2br($prontuario['conduta']) . "</p>
        <p><strong>Observações:</strong><br>" . nl2br($prontuario['observacoes']) . "</p>
    </div>
    <div class='footer'>
        <p>Documento gerado em " . date('d/m/Y H:i:s') . " - Válido apenas com assinatura digital.</p>
        <p>desenvolvido por alfa sistemas s.a (85) 2028-4584</p>
    </div>
</body>
</html>";

$options = new Options();
$options->set('defaultFont', 'Arial');
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("prontuario_{$id}.pdf", array("Attachment" => 0));