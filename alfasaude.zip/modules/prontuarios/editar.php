<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();
if (!hasPermissao('medico')) {
    header('Location: index.php');
    exit;
}

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM prontuarios WHERE id = ?");
$stmt->execute([$id]);
$prontuario = $stmt->fetch();

if (!$prontuario || $prontuario['medico_id'] != $_SESSION['medico_id']) {
    header('Location: index.php?erro=permissao');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $anamnese = $_POST['anamnese'];
    $exame_fisico = $_POST['exame_fisico'];
    $hipotese_diagnostica = $_POST['hipotese_diagnostica'];
    $diagnostico_final = $_POST['diagnostico_final'];
    $conduta = $_POST['conduta'];
    $observacoes = $_POST['observacoes'];

    $stmt = $pdo->prepare("UPDATE prontuarios SET anamnese=?, exame_fisico=?, hipotese_diagnostica=?, diagnostico_final=?, conduta=?, observacoes=? WHERE id=?");
    if ($stmt->execute([$anamnese, $exame_fisico, $hipotese_diagnostica, $diagnostico_final, $conduta, $observacoes, $id])) {
        header('Location: visualizar.php?id='.$id.'&msg=editado');
        exit;
    }
}
?>
<!-- formulário similar ao novo.php, com campos preenchidos -->