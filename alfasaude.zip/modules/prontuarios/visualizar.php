<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("
    SELECT p.*, pac.nome as paciente_nome, m.nome as medico_nome, m.crm
    FROM prontuarios p
    JOIN pacientes pac ON p.paciente_id = pac.id
    JOIN medicos m ON p.medico_id = m.id
    WHERE p.id = ?
");
$stmt->execute([$id]);
$prontuario = $stmt->fetch();

if (!$prontuario) {
    header('Location: index.php?erro=nao_encontrado');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Prontuário | <?php echo getNomeSistema(); ?></title>
    <link rel="stylesheet" href="../../assets/css/estilo.css">
</head>
<body>
    <?php include '../../includes/sidebar.php'; ?>
    <?php include '../../includes/topbar.php'; ?>
    <div class="dashboard-content">
        <div class="page-header">
            <h1><i class="fas fa-notes-medical"></i> Prontuário</h1>
            <div class="page-actions">
                <a href="index.php?paciente_id=<?php echo $prontuario['paciente_id']; ?>" class="btn-secondary"><i class="fas fa-arrow-left"></i> Voltar</a>
                <?php if (hasPermissao('medico') && $_SESSION['medico_id'] == $prontuario['medico_id']): ?>
                    <a href="editar.php?id=<?php echo $id; ?>" class="btn-primary"><i class="fas fa-edit"></i> Editar</a>
                <?php endif; ?>
                <a href="pdf.php?id=<?php echo $id; ?>" class="btn-success" target="_blank"><i class="fas fa-file-pdf"></i> Gerar PDF</a>
            </div>
        </div>

        <div class="info-card">
            <h3>Dados do Atendimento</h3>
            <p><strong>Paciente:</strong> <?php echo $prontuario['paciente_nome']; ?></p>
            <p><strong>Médico:</strong> Dr(a). <?php echo $prontuario['medico_nome']; ?> (CRM <?php echo $prontuario['crm']; ?>)</p>
            <p><strong>Data do atendimento:</strong> <?php echo date('d/m/Y H:i', strtotime($prontuario['data_atendimento'])); ?></p>
        </div>

        <div class="info-card">
            <h3>Anamnese</h3>
            <p><?php echo nl2br($prontuario['anamnese']); ?></p>
        </div>

        <div class="info-card">
            <h3>Exame Físico</h3>
            <p><?php echo nl2br($prontuario['exame_fisico']); ?></p>
        </div>

        <div class="info-card">
            <h3>Hipótese Diagnóstica</h3>
            <p><?php echo nl2br($prontuario['hipotese_diagnostica']); ?></p>
        </div>

        <?php if ($prontuario['diagnostico_final']): ?>
        <div class="info-card">
            <h3>Diagnóstico Final</h3>
            <p><?php echo nl2br($prontuario['diagnostico_final']); ?></p>
        </div>
        <?php endif; ?>

        <div class="info-card">
            <h3>Conduta</h3>
            <p><?php echo nl2br($prontuario['conduta']); ?></p>
        </div>

        <?php if ($prontuario['observacoes']): ?>
        <div class="info-card">
            <h3>Observações</h3>
            <p><?php echo nl2br($prontuario['observacoes']); ?></p>
        </div>
        <?php endif; ?>
    </div>
    <?php include '../../includes/footer.php'; ?>
</body>
</html>