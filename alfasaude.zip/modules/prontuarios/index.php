<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();

$paciente_id = $_GET['paciente_id'] ?? '';

$sql = "SELECT p.*, pac.nome as paciente_nome, m.nome as medico_nome 
        FROM prontuarios p
        JOIN pacientes pac ON p.paciente_id = pac.id
        JOIN medicos m ON p.medico_id = m.id";
$params = [];
if ($paciente_id) {
    $sql .= " WHERE p.paciente_id = :paciente";
    $params[':paciente'] = $paciente_id;
}
$sql .= " ORDER BY p.data_atendimento DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$prontuarios = $stmt->fetchAll();

$pacientes = $pdo->query("SELECT id, nome FROM pacientes WHERE ativo=1 ORDER BY nome")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Prontuários | <?php echo getNomeSistema(); ?></title>
    <link rel="stylesheet" href="../../assets/css/estilo.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include '../../includes/sidebar.php'; ?>
    <?php include '../../includes/topbar.php'; ?>
    <div class="dashboard-content">
        <div class="page-header">
            <h1><i class="fas fa-notes-medical"></i> Prontuários</h1>
            <div class="page-actions">
                <a href="novo.php" class="btn-primary"><i class="fas fa-plus"></i> Novo Prontuário</a>
            </div>
        </div>

        <div class="filters-card">
            <form method="GET" class="filters-form">
                <div class="form-group">
                    <label>Filtrar por paciente:</label>
                    <select name="paciente_id">
                        <option value="">Todos</option>
                        <?php foreach ($pacientes as $p): ?>
                            <option value="<?php echo $p['id']; ?>" <?php echo $p['id']==$paciente_id?'selected':''; ?>><?php echo $p['nome']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn-filter"><i class="fas fa-filter"></i> Filtrar</button>
            </form>
        </div>

        <div class="table-card">
            <table class="data-table">
                <thead>
                    <tr><th>Paciente</th><th>Médico</th><th>Data</th><th>Diagnóstico</th><th>Ações</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($prontuarios as $p): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($p['paciente_nome']); ?></td>
                        <td><?php echo htmlspecialchars($p['medico_nome']); ?></td>
                        <td><?php echo date('d/m/Y H:i', strtotime($p['data_atendimento'])); ?></td>
                        <td><?php echo substr($p['diagnostico_final'] ?? '', 0, 50); ?>...</td>
                        <td>
                            <a href="visualizar.php?id=<?php echo $p['id']; ?>" class="btn-icon"><i class="fas fa-eye"></i></a>
                            <?php if (hasPermissao('medico') && $_SESSION['medico_id'] == $p['medico_id']): ?>
                                <a href="editar.php?id=<?php echo $p['id']; ?>" class="btn-icon"><i class="fas fa-edit"></i></a>
                            <?php endif; ?>
                            <a href="pdf.php?id=<?php echo $p['id']; ?>" class="btn-icon" target="_blank"><i class="fas fa-file-pdf"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php include '../../includes/footer.php'; ?>
</body>
</html>