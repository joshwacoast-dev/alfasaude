<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();

$agendamento_id = $_GET['agendamento_id'] ?? 0;

// Buscar dados do agendamento
$stmt = $pdo->prepare("SELECT paciente_id FROM agendamentos WHERE id = ?");
$stmt->execute([$agendamento_id]);
$paciente_id = $stmt->fetchColumn();

if (!$paciente_id) {
    die('Agendamento não encontrado');
}

// Verificar se já existe progresso
$stmt = $pdo->prepare("SELECT id FROM progresso_paciente WHERE agendamento_id = ?");
$stmt->execute([$agendamento_id]);
$progresso_id = $stmt->fetchColumn();

if (!$progresso_id) {
    // Criar novo
    $hash = bin2hex(random_bytes(16));
    $stmt = $pdo->prepare("INSERT INTO progresso_paciente (paciente_id, agendamento_id, qrcode_hash) VALUES (?,?,?)");
    $stmt->execute([$paciente_id, $agendamento_id, $hash]);
    $progresso_id = $pdo->lastInsertId();
} else {
    // Recuperar hash existente
    $stmt = $pdo->prepare("SELECT qrcode_hash FROM progresso_paciente WHERE id = ?");
    $stmt->execute([$progresso_id]);
    $hash = $stmt->fetchColumn();
}

// Gerar QR Code (se biblioteca instalada)
if (file_exists('../../vendor/autoload.php')) {
    require_once '../../vendor/autoload.php';
    use chillerlan\QRCode\QRCode;
    $qrcode = new QRCode();
    $qrcode->render('https://'.$_SERVER['HTTP_HOST'].'/alfa_saude/acompanhar.php?hash='.$hash, '../../assets/qrcodes/'.$hash.'.png');
    echo "QR Code gerado com sucesso! <a href='../../assets/qrcodes/".$hash.".png' target='_blank'>Ver imagem</a>";
} else {
    echo "Biblioteca QR Code não instalada. Instale via composer.";
}