<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();

$data_inicio = $_GET['data_inicio'] ?? date('Y-m-01');
$data_fim = $_GET['data_fim'] ?? date('Y-m-d');

$stmt = $pdo->prepare("
    SELECT a.data_hora, p.nome as paciente, m.nome as medico, a.status, a.tipo_consulta
    FROM agendamentos a
    JOIN pacientes p ON a.paciente_id = p.id
    JOIN medicos m ON a.medico_id = m.id
    WHERE DATE(a.data_hora) BETWEEN ? AND ?
    ORDER BY a.data_hora
");
$stmt->execute([$data_inicio, $data_fim]);
$atendimentos = $stmt->fetchAll();

// Totais
$total = count($atendimentos);
$concluidos = array_filter($atendimentos, fn($a) => $a['status'] == 'concluido');
$cancelados = array_filter($atendimentos, fn($a) => $a['status'] == 'cancelado');
?>
<!-- HTML com filtros e tabela -->