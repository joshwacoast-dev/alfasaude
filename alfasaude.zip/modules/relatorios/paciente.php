<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();

$paciente_id = $_GET['paciente_id'] ?? 0;

// Buscar lista de pacientes para o filtro
$pacientes = $pdo->query("SELECT id, nome FROM pacientes WHERE ativo=1 ORDER BY nome")->fetchAll();

$dados_paciente = null;
$atendimentos = [];
$prontuarios = [];
$receitas = [];
$declaracoes = [];

if ($paciente_id) {
    // Dados do paciente
    $stmt = $pdo->prepare("SELECT * FROM pacientes WHERE id = ?");
    $stmt->execute([$paciente_id]);
    $dados_paciente = $stmt->fetch();

    if ($dados_paciente) {
        // Agendamentos
        $stmt = $pdo->prepare("SELECT a.*, m.nome as medico_nome FROM agendamentos a JOIN medicos m ON a.medico_id = m.id WHERE a.paciente_id = ? ORDER BY a.data_hora DESC");
        $stmt->execute([$paciente_id]);
        $atendimentos = $stmt->fetchAll();

        // Prontuários
        $stmt = $pdo->prepare("SELECT p.*, m.nome as medico_nome FROM prontuarios p JOIN medicos m ON p.medico_id = m.id WHERE p.paciente_id = ? ORDER BY p.data_atendimento DESC");
        $stmt->execute([$paciente_id]);
        $prontuarios = $stmt->fetchAll();

        // Receitas
        $stmt = $pdo->prepare("SELECT r.*, m.nome as medico_nome FROM receituarios r JOIN medicos m ON r.medico_id = m.id WHERE r.paciente_id = ? ORDER BY r.data_emissao DESC");
        $stmt->execute([$paciente_id]);
        $receitas = $stmt->fetchAll();

        // Declarações
        $stmt = $pdo->prepare("SELECT d.*, m.nome as medico_nome FROM declaracoes d JOIN medicos m ON d.medico_id = m.id WHERE d.paciente_id = ? ORDER BY d.data_emissao DESC");
        $stmt->execute([$paciente_id]);
        $declaracoes = $stmt->fetchAll();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Relatório por Paciente | <?php echo getNomeSistema(); ?></title>
    <link rel="stylesheet" href="../../assets/css/estilo.css">
</head>
<body>
    <?php include '../../includes/sidebar.php'; ?>
    <?php include '../../includes/topbar.php'; ?>
    <div class="dashboard-content">
        <h1><i class="fas fa-user-chart"></i> Relatório por Paciente</h1>

        <div class="filters-card">
            <form method="GET" class="filters-form">
                <div class="form-group">
                    <label>Selecione o paciente:</label>
                    <select name="paciente_id" required>
                        <option value="">-- Escolha --</option>
                        <?php foreach ($pacientes as $p): ?>
                            <option value="<?php echo $p['id']; ?>" <?php echo $p['id']==$paciente_id?'selected':''; ?>><?php echo $p['nome']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn-filter">Gerar Relatório</button>
            </form>
        </div>

        <?php if ($dados_paciente): ?>
            <div class="info-card">
                <h3>Dados do Paciente</h3>
                <p><strong>Nome:</strong> <?php echo $dados_paciente['nome']; ?></p>
                <p><strong>CPF:</strong> <?php echo $dados_paciente['cpf']; ?></p>
                <p><strong>Telefone:</strong> <?php echo $dados_paciente['telefone']; ?></p>
                <p><strong>Convênio:</strong> <?php echo $dados_paciente['convenio'] ?: 'Particular'; ?></p>
            </div>

            <h2>Histórico de Atendimentos</h2>
            <table class="data-table">
                <thead><tr><th>Data</th><th>Médico</th><th>Tipo</th><th>Status</th></tr></thead>
                <tbody>
                    <?php foreach ($atendimentos as $a): ?>
                    <tr>
                        <td><?php echo date('d/m/Y H:i', strtotime($a['data_hora'])); ?></td>
                        <td><?php echo $a['medico_nome']; ?></td>
                        <td><?php echo ucfirst($a['tipo_consulta']); ?></td>
                        <td><span class="status-badge status-<?php echo $a['status']; ?>"><?php echo ucfirst($a['status']); ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <h2>Prontuários</h2>
            <table class="data-table">
                <thead><tr><th>Data</th><th>Médico</th><th>Diagnóstico</th></tr></thead>
                <tbody>
                    <?php foreach ($prontuarios as $p): ?>
                    <tr>
                        <td><?php echo date('d/m/Y', strtotime($p['data_atendimento'])); ?></td>
                        <td><?php echo $p['medico_nome']; ?></td>
                        <td><?php echo substr($p['diagnostico_final'] ?? '', 0, 50); ?>...</td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <h2>Receitas</h2>
            <table class="data-table">
                <thead><tr><th>Data</th><th>Médico</th><th>Código</th></tr></thead>
                <tbody>
                    <?php foreach ($receitas as $r): ?>
                    <tr>
                        <td><?php echo date('d/m/Y', strtotime($r['data_emissao'])); ?></td>
                        <td><?php echo $r['medico_nome']; ?></td>
                        <td><?php echo $r['codigo_verificacao']; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <h2>Declarações</h2>
            <table class="data-table">
                <thead><tr><th>Data</th><th>Tipo</th><th>Código</th></tr></thead>
                <tbody>
                    <?php foreach ($declaracoes as $d): ?>
                    <tr>
                        <td><?php echo date('d/m/Y', strtotime($d['data_emissao'])); ?></td>
                        <td><?php echo ucfirst($d['tipo']); ?></td>
                        <td><?php echo $d['codigo_verificacao']; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div style="text-align: right; margin-top: 20px;">
                <a href="pdf.php?tipo=paciente&id=<?php echo $paciente_id; ?>" class="btn-success" target="_blank"><i class="fas fa-file-pdf"></i> Gerar PDF</a>
            </div>
        <?php endif; ?>
    </div>
    <?php include '../../includes/footer.php'; ?>
</body>
</html>