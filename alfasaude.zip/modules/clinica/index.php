<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();
if (!hasPermissao('admin')) {
    header('Location: ../../dashboard.php');
    exit;
}

$clinica = getClinica();
$mensagem = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $cnpj = $_POST['cnpj'];
    $endereco = $_POST['endereco'];
    $telefone = $_POST['telefone'];
    $email = $_POST['email'];
    $cor_primaria = $_POST['cor_primaria'];
    $cor_secundaria = $_POST['cor_secundaria'];

    // Upload do logo
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] == UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION);
        $nome_arquivo = 'logo_' . time() . '.' . $ext;
        move_uploaded_file($_FILES['logo']['tmp_name'], '../../assets/img/' . $nome_arquivo);
        // Se já existia logo antigo, pode apagar
        if ($clinica['logo'] && file_exists('../../assets/img/'.$clinica['logo'])) {
            unlink('../../assets/img/'.$clinica['logo']);
        }
    } else {
        $nome_arquivo = $clinica['logo'];
    }

    $stmt = $pdo->prepare("UPDATE clinica SET nome=?, cnpj=?, endereco=?, telefone=?, email=?, logo=?, cor_primaria=?, cor_secundaria=? WHERE id=?");
    if ($stmt->execute([$nome, $cnpj, $endereco, $telefone, $email, $nome_arquivo, $cor_primaria, $cor_secundaria, $clinica['id']])) {
        $mensagem = "Dados atualizados com sucesso!";
        $clinica = getClinica(); // recarregar
    } else {
        $mensagem = "Erro ao atualizar.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Configurações da Clínica | <?php echo $clinica['nome']; ?></title>
    <link rel="stylesheet" href="../../assets/css/estilo.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .color-picker { width: 50px; height: 50px; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <?php include '../../includes/sidebar.php'; ?>
    <?php include '../../includes/topbar.php'; ?>
    <div class="dashboard-content">
        <h1><i class="fas fa-hospital"></i> Configurações da Clínica</h1>
        <?php if ($mensagem): ?>
            <div class="alert alert-success"><?php echo $mensagem; ?></div>
        <?php endif; ?>
        <form method="POST" enctype="multipart/form-data" class="form-card">
            <div class="form-group">
                <label>Nome da Clínica</label>
                <input type="text" name="nome" value="<?php echo $clinica['nome']; ?>" required>
            </div>
            <div class="form-group">
                <label>CNPJ</label>
                <input type="text" name="cnpj" value="<?php echo $clinica['cnpj']; ?>">
            </div>
            <div class="form-group">
                <label>Endereço</label>
                <textarea name="endereco"><?php echo $clinica['endereco']; ?></textarea>
            </div>
            <div class="form-group">
                <label>Telefone</label>
                <input type="text" name="telefone" value="<?php echo $clinica['telefone']; ?>">
            </div>
            <div class="form-group">
                <label>E-mail</label>
                <input type="email" name="email" value="<?php echo $clinica['email']; ?>">
            </div>
            <div class="form-group">
                <label>Logo</label>
                <?php if ($clinica['logo']): ?>
                    <img src="../../assets/img/<?php echo $clinica['logo']; ?>" height="60" style="display:block; margin-bottom:10px;">
                <?php endif; ?>
                <input type="file" name="logo" accept="image/*">
            </div>
            <div class="form-group">
                <label>Cor Primária</label>
                <input type="color" name="cor_primaria" value="<?php echo $clinica['cor_primaria']; ?>" class="color-picker">
            </div>
            <div class="form-group">
                <label>Cor Secundária</label>
                <input type="color" name="cor_secundaria" value="<?php echo $clinica['cor_secundaria']; ?>" class="color-picker">
            </div>
            <button type="submit" class="btn-primary">Salvar Alterações</button>
        </form>
    </div>
    <?php include '../../includes/footer.php'; ?>
</body>
</html>