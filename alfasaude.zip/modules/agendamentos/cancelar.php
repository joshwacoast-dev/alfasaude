<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("UPDATE agendamentos SET status = 'cancelado' WHERE id = ?");
$stmt->execute([$id]);
header('Location: index.php?msg=cancelado');
exit;