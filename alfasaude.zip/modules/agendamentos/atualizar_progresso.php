<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $progresso_id = $_POST['progresso_id'];
    $etapa = $_POST['etapa'];
    $status = $_POST['status'];

    $stmt = $pdo->prepare("UPDATE progresso_paciente SET etapa = ?, status = ? WHERE id = ?");
    $stmt->execute([$etapa, $status, $progresso_id]);

    header('Location: visualizar.php?agendamento_id=' . $_GET['agendamento_id']); // precisa passar o id
}