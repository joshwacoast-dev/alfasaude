<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();
if (!hasPermissao('medico')) {
    header('Location: index.php');
    exit;
}

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM agendamentos WHERE id = ?");
$stmt->execute([$id]);
$agendamento = $stmt->fetch();

if (!$agendamento) {
    header('Location: index.php?erro=nao_encontrado');
    exit;
}

$medicos = $pdo->query("SELECT id, nome FROM medicos WHERE ativo=1 ORDER BY nome")->fetchAll();
$pacientes = $pdo->query("SELECT id, nome FROM pacientes WHERE ativo=1 ORDER BY nome")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $paciente_id = $_POST['paciente_id'];
    $medico_id = $_POST['medico_id'];
    $data = $_POST['data'];
    $hora = $_POST['hora'];
    $data_hora = $data . ' ' . $hora;
    $tipo_consulta = $_POST['tipo_consulta'];
    $status = $_POST['status'];
    $observacoes = $_POST['observacoes'];
    $data_retorno = $_POST['data_retorno'] ?: null;

    $stmt = $pdo->prepare("UPDATE agendamentos SET paciente_id=?, medico_id=?, data_hora=?, tipo_consulta=?, status=?, observacoes=?, data_retorno=? WHERE id=?");
    if ($stmt->execute([$paciente_id, $medico_id, $data_hora, $tipo_consulta, $status, $observacoes, $data_retorno, $id])) {
        header('Location: index.php?msg=editado');
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Editar Agendamento | <?php echo getNomeSistema(); ?></title>
    <link rel="stylesheet" href="../../assets/css/estilo.css">
</head>
<body>
    <?php include '../../includes/sidebar.php'; ?>
    <?php include '../../includes/topbar.php'; ?>
    <div class="dashboard-content">
        <h1>Editar Agendamento</h1>
        <form method="POST" class="form-card">
            <!-- campos preenchidos com $agendamento -->
            <div class="form-group">
                <label>Paciente</label>
                <select name="paciente_id" required>
                    <?php foreach ($pacientes as $p): ?>
                        <option value="<?php echo $p['id']; ?>" <?php echo $p['id']==$agendamento['paciente_id']?'selected':''; ?>><?php echo $p['nome']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Médico</label>
                <select name="medico_id" required>
                    <?php foreach ($medicos as $m): ?>
                        <option value="<?php echo $m['id']; ?>" <?php echo $m['id']==$agendamento['medico_id']?'selected':''; ?>><?php echo $m['nome']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-row">
                <div class="form-group col">
                    <label>Data</label>
                    <input type="date" name="data" value="<?php echo date('Y-m-d', strtotime($agendamento['data_hora'])); ?>" required>
                </div>
                <div class="form-group col">
                    <label>Hora</label>
                    <input type="time" name="hora" value="<?php echo date('H:i', strtotime($agendamento['data_hora'])); ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label>Tipo</label>
                <select name="tipo_consulta">
                    <option value="consulta" <?php echo $agendamento['tipo_consulta']=='consulta'?'selected':''; ?>>Consulta</option>
                    <option value="retorno" <?php echo $agendamento['tipo_consulta']=='retorno'?'selected':''; ?>>Retorno</option>
                    <option value="exame" <?php echo $agendamento['tipo_consulta']=='exame'?'selected':''; ?>>Exame</option>
                    <option value="procedimento" <?php echo $agendamento['tipo_consulta']=='procedimento'?'selected':''; ?>>Procedimento</option>
                </select>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="agendado" <?php echo $agendamento['status']=='agendado'?'selected':''; ?>>Agendado</option>
                    <option value="confirmado" <?php echo $agendamento['status']=='confirmado'?'selected':''; ?>>Confirmado</option>
                    <option value="em_andamento" <?php echo $agendamento['status']=='em_andamento'?'selected':''; ?>>Em Andamento</option>
                    <option value="concluido" <?php echo $agendamento['status']=='concluido'?'selected':''; ?>>Concluído</option>
                    <option value="cancelado" <?php echo $agendamento['status']=='cancelado'?'selected':''; ?>>Cancelado</option>
                </select>
            </div>
            <div class="form-group">
                <label>Observações</label>
                <textarea name="observacoes"><?php echo htmlspecialchars($agendamento['observacoes']); ?></textarea>
            </div>
            <div class="form-group">
                <label>Data de Retorno</label>
                <input type="date" name="data_retorno" value="<?php echo $agendamento['data_retorno']; ?>">
            </div>
            <button type="submit" class="btn-primary">Salvar</button>
            <a href="index.php" class="btn-secondary">Cancelar</a>
        </form>
    </div>
    <?php include '../../includes/footer.php'; ?>
</body>
</html>