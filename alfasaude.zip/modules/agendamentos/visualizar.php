<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("
    SELECT a.*, p.nome as paciente_nome, p.cpf, p.telefone, p.email,
           m.nome as medico_nome, m.crm, m.especialidade
    FROM agendamentos a
    JOIN pacientes p ON a.paciente_id = p.id
    JOIN medicos m ON a.medico_id = m.id
    WHERE a.id = ?
");
$stmt->execute([$id]);
$agendamento = $stmt->fetch();

if (!$agendamento) {
    header('Location: index.php?erro=nao_encontrado');
    exit;
}

// Buscar progresso do paciente
$stmt = $pdo->prepare("SELECT * FROM progresso_paciente WHERE agendamento_id = ?");
$stmt->execute([$id]);
$progresso = $stmt->fetch();

// Buscar prontuário vinculado (se existir)
$stmt = $pdo->prepare("SELECT id FROM prontuarios WHERE agendamento_id = ?");
$stmt->execute([$id]);
$prontuario_id = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Detalhes do Agendamento | <?php echo getNomeSistema(); ?></title>
    <link rel="stylesheet" href="../../assets/css/estilo.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include '../../includes/sidebar.php'; ?>
    <?php include '../../includes/topbar.php'; ?>

    <div class="dashboard-content">
        <div class="page-header">
            <h1><i class="fas fa-calendar-alt"></i> Detalhes do Agendamento</h1>
            <div class="page-actions">
                <a href="index.php" class="btn-secondary"><i class="fas fa-arrow-left"></i> Voltar</a>
                <?php if (hasPermissao('medico')): ?>
                    <a href="editar.php?id=<?php echo $id; ?>" class="btn-primary"><i class="fas fa-edit"></i> Editar</a>
                <?php endif; ?>
                <?php if (!$prontuario_id && $agendamento['status'] == 'confirmado'): ?>
                    <a href="../prontuarios/novo.php?agendamento_id=<?php echo $id; ?>" class="btn-success"><i class="fas fa-notes-medical"></i> Iniciar Atendimento</a>
                <?php endif; ?>
            </div>
        </div>

        <div class="details-grid">
            <div class="info-card">
                <h3><i class="fas fa-user-injured"></i> Paciente</h3>
                <p><strong>Nome:</strong> <?php echo htmlspecialchars($agendamento['paciente_nome']); ?></p>
                <p><strong>CPF:</strong> <?php echo $agendamento['cpf']; ?></p>
                <p><strong>Telefone:</strong> <?php echo $agendamento['telefone']; ?></p>
                <p><strong>E-mail:</strong> <?php echo $agendamento['email']; ?></p>
            </div>
            <div class="info-card">
                <h3><i class="fas fa-user-md"></i> Médico</h3>
                <p><strong>Nome:</strong> Dr(a). <?php echo htmlspecialchars($agendamento['medico_nome']); ?></p>
                <p><strong>CRM:</strong> <?php echo $agendamento['crm']; ?></p>
                <p><strong>Especialidade:</strong> <?php echo $agendamento['especialidade']; ?></p>
            </div>
            <div class="info-card">
                <h3><i class="fas fa-clock"></i> Data e Hora</h3>
                <p><strong>Data:</strong> <?php echo date('d/m/Y', strtotime($agendamento['data_hora'])); ?></p>
                <p><strong>Hora:</strong> <?php echo date('H:i', strtotime($agendamento['data_hora'])); ?></p>
                <p><strong>Tipo:</strong> <?php echo ucfirst($agendamento['tipo_consulta']); ?></p>
            </div>
            <div class="info-card">
                <h3><i class="fas fa-info-circle"></i> Status</h3>
                <p><span class="status-badge status-<?php echo $agendamento['status']; ?>"><?php echo ucfirst($agendamento['status']); ?></span></p>
                <?php if ($agendamento['data_retorno']): ?>
                    <p><strong>Data de retorno:</strong> <?php echo date('d/m/Y', strtotime($agendamento['data_retorno'])); ?></p>
                <?php endif; ?>
                <?php if ($agendamento['observacoes']): ?>
                    <p><strong>Observações:</strong><br><?php echo nl2br($agendamento['observacoes']); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($progresso): ?>
        <div class="info-card">
            <h3><i class="fas fa-qrcode"></i> Acompanhamento via QR Code</h3>
            <p>Hash: <?php echo $progresso['qrcode_hash']; ?></p>
            <p>Status do progresso: <span class="status-badge status-<?php echo $progresso['status']; ?>"><?php echo ucfirst($progresso['status']); ?></span></p>
            <p>Etapa atual: <?php echo $progresso['etapa'] ?: 'Aguardando'; ?></p>
            <?php if (file_exists('../../assets/qrcodes/'.$progresso['qrcode_hash'].'.png')): ?>
                <img src="../../assets/qrcodes/<?php echo $progresso['qrcode_hash']; ?>.png" alt="QR Code" style="max-width:150px;">
                <br>
                <a href="../../acompanhar.php?hash=<?php echo $progresso['qrcode_hash']; ?>" target="_blank" class="btn-small">Visualizar página pública</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if ($prontuario_id): ?>
        <div class="info-card">
            <h3><i class="fas fa-notes-medical"></i> Prontuário</h3>
            <p>Este atendimento já possui um prontuário.</p>
            <a href="../prontuarios/visualizar.php?id=<?php echo $prontuario_id; ?>" class="btn-primary">Ver Prontuário</a>
        </div>
        <?php endif; ?>

        <div class="form-actions">
            <?php if ($agendamento['status'] == 'agendado'): ?>
                <a href="confirmar.php?id=<?php echo $id; ?>" class="btn-success"><i class="fas fa-check"></i> Confirmar</a>
            <?php endif; ?>
            <?php if ($agendamento['status'] != 'cancelado' && $agendamento['status'] != 'concluido'): ?>
                <a href="cancelar.php?id=<?php echo $id; ?>" class="btn-danger" onclick="return confirm('Cancelar este agendamento?')"><i class="fas fa-times"></i> Cancelar</a>
            <?php endif; ?>
        </div>
    </div>

    <?php include '../../includes/footer.php'; ?>
</body>
</html>