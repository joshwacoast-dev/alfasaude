<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();

$filtro_data = $_GET['data'] ?? date('Y-m-d');
$filtro_medico = $_GET['medico_id'] ?? '';

$sql = "SELECT a.*, p.nome as paciente_nome, m.nome as medico_nome 
        FROM agendamentos a
        JOIN pacientes p ON a.paciente_id = p.id
        JOIN medicos m ON a.medico_id = m.id
        WHERE DATE(a.data_hora) = :data";
$params = [':data' => $filtro_data];

if (!empty($filtro_medico)) {
    $sql .= " AND a.medico_id = :medico";
    $params[':medico'] = $filtro_medico;
}
$sql .= " ORDER BY a.data_hora ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$agendamentos = $stmt->fetchAll();

// Lista de médicos para o filtro
$medicos = $pdo->query("SELECT id, nome FROM medicos WHERE ativo=1 ORDER BY nome")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Agendamentos | <?php echo getNomeSistema(); ?></title>
    <link rel="stylesheet" href="../../assets/css/estilo.css">
</head>
<body>
    <?php include '../../includes/sidebar.php'; ?>
    <?php include '../../includes/topbar.php'; ?>
    <div class="dashboard-content">
        <div class="page-header">
            <h1><i class="fas fa-calendar-alt"></i> Agendamentos</h1>
            <a href="novo.php" class="btn-primary"><i class="fas fa-plus"></i> Novo</a>
        </div>
        <div class="filters-card">
            <form method="GET" class="filters-form">
                <div class="form-group">
                    <label>Data:</label>
                    <input type="date" name="data" value="<?php echo $filtro_data; ?>">
                </div>
                <div class="form-group">
                    <label>Médico:</label>
                    <select name="medico_id">
                        <option value="">Todos</option>
                        <?php foreach ($medicos as $m): ?>
                            <option value="<?php echo $m['id']; ?>" <?php echo $filtro_medico==$m['id']?'selected':''; ?>><?php echo $m['nome']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn-filter">Filtrar</button>
            </form>
        </div>
        <div class="table-card">
            <table class="data-table">
                <thead>
                    <tr><th>Horário</th><th>Paciente</th><th>Médico</th><th>Tipo</th><th>Status</th><th>Ações</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($agendamentos as $a): ?>
                    <tr>
                        <td><?php echo date('H:i', strtotime($a['data_hora'])); ?></td>
                        <td><?php echo $a['paciente_nome']; ?></td>
                        <td><?php echo $a['medico_nome']; ?></td>
                        <td><?php echo ucfirst($a['tipo_consulta']); ?></td>
                        <td><span class="status-badge status-<?php echo $a['status']; ?>"><?php echo ucfirst($a['status']); ?></span></td>
                        <td>
                            <a href="visualizar.php?id=<?php echo $a['id']; ?>" class="btn-icon"><i class="fas fa-eye"></i></a>
                            <a href="editar.php?id=<?php echo $a['id']; ?>" class="btn-icon"><i class="fas fa-edit"></i></a>
                            <a href="confirmar.php?id=<?php echo $a['id']; ?>" class="btn-icon" title="Confirmar"><i class="fas fa-check"></i></a>
                            <a href="cancelar.php?id=<?php echo $a['id']; ?>" class="btn-icon" onclick="return confirm('Cancelar agendamento?')"><i class="fas fa-times"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php include '../../includes/footer.php'; ?>
</body>
</html>