<?php
require_once '../../config/database.php';
require_once '../../config/auth.php';
verificarLogin();

$medicos = $pdo->query("SELECT id, nome FROM medicos WHERE ativo=1 ORDER BY nome")->fetchAll();
$pacientes = $pdo->query("SELECT id, nome FROM pacientes WHERE ativo=1 ORDER BY nome")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $paciente_id = $_POST['paciente_id'];
    $medico_id = $_POST['medico_id'];
    $data = $_POST['data'];
    $hora = $_POST['hora'];
    $data_hora = $data . ' ' . $hora;
    $tipo_consulta = $_POST['tipo_consulta'];
    $observacoes = $_POST['observacoes'];
    $data_retorno = $_POST['data_retorno'] ?: null;

    $stmt = $pdo->prepare("INSERT INTO agendamentos (paciente_id, medico_id, data_hora, tipo_consulta, observacoes, data_retorno) VALUES (?,?,?,?,?,?)");
    if ($stmt->execute([$paciente_id, $medico_id, $data_hora, $tipo_consulta, $observacoes, $data_retorno])) {
        $agendamento_id = $pdo->lastInsertId();

        // Gerar hash para QR Code
        $hash = bin2hex(random_bytes(16));
        $stmt = $pdo->prepare("INSERT INTO progresso_paciente (paciente_id, agendamento_id, qrcode_hash) VALUES (?,?,?)");
        $stmt->execute([$paciente_id, $agendamento_id, $hash]);

        // Gerar QR Code (se a biblioteca estiver instalada)
        if (file_exists('../../vendor/autoload.php')) {
            require_once '../../vendor/autoload.php';
            use chillerlan\QRCode\QRCode;
            $qrcode = new QRCode();
            $qrcode->render('https://'.$_SERVER['HTTP_HOST'].'/alfa_saude/acompanhar.php?hash='.$hash, '../../assets/qrcodes/'.$hash.'.png');
        }

        header('Location: index.php?msg=sucesso');
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Novo Agendamento | <?php echo getNomeSistema(); ?></title>
    <link rel="stylesheet" href="../../assets/css/estilo.css">
</head>
<body>
    <?php include '../../includes/sidebar.php'; ?>
    <?php include '../../includes/topbar.php'; ?>
    <div class="dashboard-content">
        <h1>Novo Agendamento</h1>
        <form method="POST" class="form-card">
            <div class="form-group">
                <label>Paciente</label>
                <select name="paciente_id" required>
                    <option value="">Selecione</option>
                    <?php foreach ($pacientes as $p): ?>
                        <option value="<?php echo $p['id']; ?>"><?php echo $p['nome']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Médico</label>
                <select name="medico_id" required>
                    <option value="">Selecione</option>
                    <?php foreach ($medicos as $m): ?>
                        <option value="<?php echo $m['id']; ?>"><?php echo $m['nome']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-row">
                <div class="form-group col">
                    <label>Data</label>
                    <input type="date" name="data" required>
                </div>
                <div class="form-group col">
                    <label>Hora</label>
                    <input type="time" name="hora" required>
                </div>
            </div>
            <div class="form-group">
                <label>Tipo</label>
                <select name="tipo_consulta">
                    <option value="consulta">Consulta</option>
                    <option value="retorno">Retorno</option>
                    <option value="exame">Exame</option>
                    <option value="procedimento">Procedimento</option>
                </select>
            </div>
            <div class="form-group">
                <label>Observações</label>
                <textarea name="observacoes"></textarea>
            </div>
            <div class="form-group">
                <label>Data de Retorno (opcional)</label>
                <input type="date" name="data_retorno">
            </div>
            <button type="submit" class="btn-primary">Agendar</button>
            <a href="index.php" class="btn-secondary">Cancelar</a>
        </form>
    </div>
    <?php include '../../includes/footer.php'; ?>
</body>
</html>