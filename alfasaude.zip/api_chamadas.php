<?php
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');
error_reporting(E_ERROR); 
require_once 'config/database.php';

function querySegura($pdo, $sql) {
    try { return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC); } 
    catch (Exception $e) { return []; }
}

// 1. Quem está sendo chamado AGORA
$atual_raw = querySegura($pdo, "
    SELECT id, nome_paciente, senha, especialidade,
           COALESCE(sala, guiche, 'Guichê') as local_atendimento, 
           status, gravidade, preferencial,
           DATE_FORMAT(data_hora, '%Y-%m-%d %H:%i:%s') as data_hora,
           DATE_FORMAT(COALESCE(data_ultima_chamada, data_hora), '%Y-%m-%d %H:%i:%s') as data_ultima_chamada,
           TIMESTAMPDIFF(MINUTE, data_hora, NOW()) as tempo_espera_minutos
    FROM fila_chamadas 
    WHERE status = 'chamando' 
    ORDER BY FIELD(gravidade, 'vermelho', 'amarelo', 'azul', 'verde'),
             COALESCE(data_ultima_chamada, data_hora) DESC 
    LIMIT 1
");

// 2. Próximos da fila
$proximos = querySegura($pdo, "
    SELECT nome_paciente, senha, especialidade,
           COALESCE(sala, guiche, 'Guichê') as local_atendimento,
           gravidade, preferencial,
           TIMESTAMPDIFF(MINUTE, data_hora, NOW()) as tempo_espera_minutos
    FROM fila_chamadas 
    WHERE status = 'aguardando' 
    ORDER BY FIELD(gravidade, 'vermelho', 'amarelo', 'azul', 'verde'),
             data_hora ASC 
    LIMIT 5
");

// 3. Histórico (Últimos atendidos)
$ultimos = querySegura($pdo, "
    SELECT nome_paciente, senha, especialidade,
           COALESCE(sala, guiche, 'Guichê') as local_atendimento,
           gravidade, preferencial,
           TIMESTAMPDIFF(MINUTE, data_hora, COALESCE(data_ultima_chamada, data_hora)) as tempo_espera_minutos
    FROM fila_chamadas 
    WHERE status = 'atendido' 
    ORDER BY COALESCE(data_ultima_chamada, data_hora) DESC 
    LIMIT 5
");

echo json_encode([
    'atual' => !empty($atual_raw) ? $atual_raw[0] : null,
    'proximos' => $proximos,
    'ultimos' => $ultimos
]);
?>