<?php
// ============================================
// ARQUIVO: declaracoes.php
// DESCRIÇÃO: Listagem de declarações
// ============================================

// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config/database.php';
require_once 'config/auth.php';
verificarLogin();

// ============================================
// FILTROS
// ============================================
$paciente_id = isset($_GET['paciente_id']) ? intval($_GET['paciente_id']) : 0;
$medico_id   = isset($_GET['medico_id']) ? intval($_GET['medico_id']) : 0;
$data_inicio = $_GET['data_inicio'] ?? '';
$data_fim    = $_GET['data_fim'] ?? '';
$tipo        = $_GET['tipo'] ?? '';

// ============================================
// CONSULTA PRINCIPAL
// ============================================
$sql = "SELECT d.*, 
               p.nome as paciente_nome, 
               u.nome as medico_nome
        FROM declaracoes d
        JOIN pacientes p ON d.paciente_id = p.id
        JOIN usuarios u ON d.usuario_id = u.id
        WHERE 1=1";
$params = [];

if ($paciente_id > 0) {
    $sql .= " AND d.paciente_id = :paciente_id";
    $params[':paciente_id'] = $paciente_id;
}
if ($medico_id > 0) {
    $sql .= " AND d.usuario_id = :medico_id";
    $params[':medico_id'] = $medico_id;
}
if (!empty($data_inicio)) {
    $sql .= " AND DATE(d.data_emissao) >= :data_inicio";
    $params[':data_inicio'] = $data_inicio;
}
if (!empty($data_fim)) {
    $sql .= " AND DATE(d.data_emissao) <= :data_fim";
    $params[':data_fim'] = $data_fim;
}
if (!empty($tipo)) {
    $sql .= " AND d.tipo = :tipo";
    $params[':tipo'] = $tipo;
}

$sql .= " ORDER BY d.data_emissao DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$declaracoes = $stmt->fetchAll();

// ============================================
// LISTAS PARA OS FILTROS
// ============================================
$pacientes = $pdo->query("SELECT id, nome FROM pacientes WHERE ativo = 1 ORDER BY nome")->fetchAll();
$medicos   = $pdo->query("SELECT id, nome FROM usuarios WHERE tipo IN ('admin','medico') AND ativo = 1 ORDER BY nome")->fetchAll();

// ============================================
// DADOS DO USUÁRIO LOGADO (para sidebar)
// ============================================
$usuario_nome  = $_SESSION['usuario_nome']  ?? 'Usuário';
$usuario_tipo  = $_SESSION['usuario_tipo']  ?? 'usuario';
$usuario_iniciais = strtoupper(substr($usuario_nome, 0, 2));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Declarações | Alfa Saúde</title>
    <!-- Font Awesome, Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ===== TEMA ORIGINAL (copiado do dashboard) ===== */
        :root {
            --primary: #6f42c1;
            --primary-light: #6f42c1dd;
            --primary-dark: #6f42c1aa;
            --secondary: #20c997;
            --secondary-light: #20c997dd;
            --danger: #ff4757;
            --warning: #ff9f43;
            --info: #2e86de;
            --light: #f8f9fa;
            --dark: #343a40;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --border-radius: 12px;
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 8px 30px rgba(0, 0, 0, 0.12);
            --transition: all 0.3s ease;
            --sidebar-width: 280px;
            --topbar-height: 80px;
        }

        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family:'Poppins',sans-serif;
            background:linear-gradient(135deg,#f5f7fb 0%,#eef2f7 100%);
            color:var(--dark);
            line-height:1.6;
            min-height:100vh;
            overflow-x:hidden;
        }
        body.dark-theme {
            --light:#1a1d23;
            --dark:#f8f9fa;
            --gray:#adb5bd;
            --light-gray:#2d3239;
            background:linear-gradient(135deg,#121416 0%,#1a1d23 100%);
            color:#f8f9fa;
        }

        .dashboard-container { display:flex; min-height:100vh; position:relative; }
        .sidebar {
            width:var(--sidebar-width);
            background:linear-gradient(180deg,var(--primary) 0%,var(--primary-dark) 100%);
            color:white;
            display:flex; flex-direction:column; position:fixed; height:100vh; z-index:1000;
            transition:var(--transition); box-shadow:3px 0 20px rgba(0,0,0,0.1); overflow-y:auto;
        }
        .dark-theme .sidebar { box-shadow:3px 0 20px rgba(0,0,0,0.3); }
        .sidebar-header { padding:25px; border-bottom:1px solid rgba(255,255,255,0.15); background:rgba(255,255,255,0.05); position:sticky; top:0; }
        .logo { display:flex; align-items:center; gap:15px; }
        .logo-icon { width:45px; height:45px; background:rgba(255,255,255,0.2); border-radius:10px; display:flex; align-items:center; justify-content:center; }
        .logo-text h2 { font-size:18px; font-weight:700; }
        .logo-text p { font-size:12px; opacity:0.9; }
        .sidebar-menu { flex:1; padding:25px 0; }
        .menu-section { margin-bottom:25px; padding:0 25px; }
        .menu-section h3 { font-size:11px; text-transform:uppercase; letter-spacing:1.5px; opacity:0.7; margin-bottom:15px; font-weight:600; }
        .menu-section ul { list-style:none; }
        .menu-section a { display:flex; align-items:center; gap:15px; padding:12px 15px; color:rgba(255,255,255,0.85); text-decoration:none; border-radius:8px; transition:var(--transition); font-size:14px; }
        .menu-section a:hover, .menu-section a.active { background:rgba(255,255,255,0.12); color:white; }
        .menu-section a.active { background:rgba(255,255,255,0.18); font-weight:600; }
        .menu-section a.active::before { content:''; position:absolute; left:0; top:50%; transform:translateY(-50%); width:4px; height:60%; background:var(--secondary); border-radius:0 4px 4px 0; }
        .menu-section a i { font-size:16px; width:20px; text-align:center; }
        .user-profile { padding:20px; border-top:1px solid rgba(255,255,255,0.15); display:flex; align-items:center; gap:15px; background:rgba(255,255,255,0.05); position:sticky; bottom:0; }
        .user-avatar { width:45px; height:45px; border-radius:50%; background:linear-gradient(135deg,var(--primary-light),var(--secondary)); display:flex; align-items:center; justify-content:center; position:relative; }
        .avatar-placeholder { font-size:16px; font-weight:700; color:white; }
        .online-status { position:absolute; bottom:3px; right:3px; width:12px; height:12px; background:var(--secondary); border-radius:50%; border:2px solid var(--primary-dark); }
        .user-info h4 { font-size:14px; font-weight:600; }
        .user-info p { font-size:12px; opacity:0.9; }
        .user-actions a { color:rgba(255,255,255,0.8); font-size:16px; padding:8px; border-radius:6px; }
        .user-actions a:hover { background:rgba(255,255,255,0.15); color:white; }

        .main-content { flex:1; margin-left:var(--sidebar-width); transition:var(--transition); min-height:100vh; display:flex; flex-direction:column; }
        @media (max-width:1199px) { .main-content { margin-left:0; } }

        .top-bar {
            background:white; padding:15px 25px; box-shadow:var(--shadow); display:flex;
            justify-content:space-between; align-items:center; position:sticky; top:0; z-index:900;
            gap:15px; backdrop-filter:blur(10px); background:rgba(255,255,255,0.95); flex-wrap:wrap; min-height:var(--topbar-height);
        }
        .dark-theme .top-bar { background:rgba(26,29,35,0.95); }
        .top-bar-left { display:flex; align-items:center; gap:15px; flex:1; min-width:0; }
        .sidebar-toggle { display:none; background:var(--primary); border:none; color:white; font-size:18px; cursor:pointer; padding:10px; border-radius:8px; width:40px; height:40px; align-items:center; justify-content:center; }
        .sidebar-toggle:hover { background:var(--primary-dark); }
        @media (max-width:1199px) { .sidebar-toggle { display:flex; } }
        .search-bar { flex:1; min-width:200px; max-width:500px; position:relative; }
        .search-bar i { position:absolute; left:15px; top:50%; transform:translateY(-50%); color:var(--gray); z-index:1; }
        .search-bar input { width:100%; padding:12px 15px 12px 40px; border:2px solid var(--light-gray); border-radius:var(--border-radius); font-size:14px; font-family:'Poppins',sans-serif; transition:var(--transition); background:white; color:var(--dark); }
        .dark-theme .search-bar input { background:var(--light); border-color:#3d4249; }
        .search-bar input:focus { outline:none; border-color:var(--primary); }
        .top-bar-right { display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
        .notification-btn, .message-btn { position:relative; background:var(--light); border:none; font-size:16px; color:var(--gray); cursor:pointer; padding:10px; border-radius:8px; width:40px; height:40px; }
        .dark-theme .notification-btn, .dark-theme .message-btn { background:#2d3239; }
        .notification-btn:hover, .message-btn:hover { background:var(--primary); color:white; transform:translateY(-2px); }
        .notification-badge { position:absolute; top:-5px; right:-5px; background:var(--danger); color:white; font-size:10px; width:18px; height:18px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:2px solid white; }
        .theme-toggle { background:var(--light); border:none; width:40px; height:40px; border-radius:50%; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:var(--transition); font-size:16px; color:var(--gray); }
        .dark-theme .theme-toggle { background:#2d3239; }
        .theme-toggle:hover { background:var(--primary); color:white; transform:rotate(30deg); }
        .quick-actions { display:flex; gap:8px; flex-wrap:wrap; }
        .quick-action-btn { width:40px; height:40px; border-radius:50%; background:linear-gradient(135deg,var(--primary),var(--primary-light)); color:white; display:flex; align-items:center; justify-content:center; transition:var(--transition); font-size:16px; text-decoration:none; }
        .quick-action-btn:hover { transform:translateY(-3px) scale(1.1); box-shadow:0 6px 20px rgba(111,66,193,0.4); }

        .dashboard-content { padding:25px; flex:1; overflow-y:auto; }
        .page-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:30px; flex-wrap:wrap; gap:15px; }
        .page-header h1 { font-size:24px; font-weight:700; color:var(--dark); display:flex; align-items:center; gap:10px; }
        .dark-theme .page-header h1 { color:#f8f9fa; }

        .btn-primary, .btn-secondary { padding:12px 20px; border:none; border-radius:var(--border-radius); font-size:14px; font-weight:600; cursor:pointer; display:inline-flex; align-items:center; gap:8px; transition:var(--transition); text-decoration:none; }
        .btn-primary { background:var(--primary); color:white; }
        .btn-primary:hover { background:var(--primary-dark); transform:translateY(-2px); box-shadow:0 4px 15px rgba(111,66,193,0.4); }
        .btn-secondary { background:var(--light-gray); color:var(--dark); }
        .btn-secondary:hover { background:var(--gray); color:white; }
        .dark-theme .btn-secondary { background:#2d3239; color:#f8f9fa; }
        .dark-theme .btn-secondary:hover { background:#3d4249; }

        .filters-card { background:white; border-radius:var(--border-radius); padding:20px; margin-bottom:20px; box-shadow:var(--shadow); }
        .filters-form { display:grid; grid-template-columns:repeat(auto-fit, minmax(180px,1fr)); gap:15px; align-items:flex-end; }
        .form-group { margin-bottom:0; }
        .form-group label { display:block; margin-bottom:5px; font-weight:500; color:var(--gray); font-size:13px; }
        .form-group input, .form-group select { width:100%; padding:10px; border:2px solid var(--light-gray); border-radius:8px; font-family:'Poppins',sans-serif; background:white; color:var(--dark); }
        .dark-theme .form-group input, .dark-theme .form-group select { background:#2d3239; border-color:#3d4249; color:#f8f9fa; }
        .form-group input:focus, .form-group select:focus { outline:none; border-color:var(--primary); }
        .btn-filter { background:var(--primary); color:white; border:none; padding:10px 20px; border-radius:8px; cursor:pointer; font-weight:600; height:42px; transition:var(--transition); }
        .btn-filter:hover { background:var(--primary-dark); transform:translateY(-2px); }

        .table-card { background:white; border-radius:var(--border-radius); box-shadow:var(--shadow); overflow:hidden; }
        .dark-theme .table-card { background:#1a1d23; }
        .table-header { padding:20px; border-bottom:1px solid var(--light-gray); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:15px; }
        .dark-theme .table-header { border-bottom-color:#2d3239; }
        .table-header h3 { font-size:18px; font-weight:700; color:var(--dark); display:flex; align-items:center; gap:10px; }
        .dark-theme .table-header h3 { color:#f8f9fa; }
        .table-header h3 i { color:var(--primary); }
        .view-all { color:var(--primary); text-decoration:none; font-size:13px; font-weight:600; padding:6px 12px; border-radius:6px; transition:var(--transition); }
        .view-all:hover { background:var(--light); transform:translateX(3px); }

        .table-container { overflow-x:auto; }
        .data-table { width:100%; min-width:800px; border-collapse:collapse; }
        .data-table th { padding:15px 20px; text-align:left; font-weight:600; color:var(--gray); font-size:12px; text-transform:uppercase; letter-spacing:1px; border-bottom:2px solid var(--light-gray); background:#f8f9fa; }
        .dark-theme .data-table th { background:#2d3239; border-bottom-color:#3d4249; }
        .data-table td { padding:15px 20px; border-bottom:1px solid var(--light-gray); color:var(--dark); font-size:13px; vertical-align:middle; }
        .dark-theme .data-table td { color:#f8f9fa; border-bottom-color:#2d3239; }
        .data-table tbody tr:hover { background:rgba(111,66,193,0.02); }

        .patient-avatar-small { width:32px; height:32px; border-radius:50%; background:linear-gradient(135deg,var(--primary),var(--secondary)); color:white; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:12px; flex-shrink:0; }

        .badge {
            display:inline-block; padding:5px 10px; border-radius:15px; font-size:11px; font-weight:700;
        }
        .badge-comparecimento { background:rgba(46,134,222,0.15); color:var(--info); }
        .badge-atestado { background:rgba(32,201,151,0.15); color:var(--secondary); }
        .badge-declaracao { background:rgba(111,66,193,0.15); color:var(--primary); }
        .badge-outros { background:rgba(108,117,125,0.15); color:var(--gray); }

        .btn-icon { display:inline-flex; align-items:center; justify-content:center; width:32px; height:32px; border-radius:6px; color:var(--gray); transition:var(--transition); margin:0 2px; }
        .btn-icon:hover { background:var(--primary); color:white; }

        .empty-state { text-align:center; padding:40px; color:var(--gray); }

        .main-footer { background:white; padding:15px 25px; border-top:1px solid var(--light-gray); text-align:center; font-size:13px; color:var(--gray); margin-top:20px; }
        .dark-theme .main-footer { background:#1a1d23; border-top-color:#2d3239; }
        .footer-content { display:flex; align-items:center; justify-content:center; gap:10px; }
        .footer-content a { color:var(--primary); text-decoration:none; }

        .sidebar-overlay { display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:999; }
        .preloader { position:fixed; top:0; left:0; width:100%; height:100%; background:white; display:flex; align-items:center; justify-content:center; z-index:9999; transition:opacity 0.5s; }
        .dark-theme .preloader { background:#1a1d23; }
        .loader { text-align:center; }
        .loader i { font-size:50px; color:var(--primary); margin-bottom:20px; animation:bounce 1.5s infinite; }
        @keyframes bounce { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-15px);} }
        @media (max-width:1199px) {
            .sidebar { transform:translateX(-100%); width:300px; }
            .sidebar.active { transform:translateX(0); }
            .sidebar-toggle { display:flex; }
            .sidebar-overlay.active { display:block; }
        }
        @media (max-width:992px) { .filters-form { grid-template-columns:1fr 1fr; } }
        @media (max-width:768px) { .filters-form { grid-template-columns:1fr; } }
    </style>
</head>
<body>
    <div class="preloader" id="preloader"><div class="loader"><i class="fas fa-stethoscope"></i><div>Carregando...</div></div></div>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo"><div class="logo-icon"><i class="fas fa-stethoscope"></i></div><div class="logo-text"><h2>Alfa Saúde</h2><p>Gestão Clínica</p></div></div>
            </div>
            <div class="sidebar-menu">
                <div class="menu-section"><h3>Menu Principal</h3>
                    <ul>
                        <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                        <li><a href="agendamentos.php"><i class="fas fa-calendar-alt"></i> Agenda</a></li>
                        <li><a href="pacientes.php"><i class="fas fa-user-injured"></i> Pacientes</a></li>
                        <li><a href="usuarios.php"><i class="fas fa-user-md"></i> Usuários</a></li>
                    </ul>
                </div>
                <div class="menu-section"><h3>Atendimento</h3>
                    <ul>
                        <li><a href="prontuarios.php"><i class="fas fa-notes-medical"></i> Prontuários</a></li>
                        <li><a href="receituarios.php"><i class="fas fa-prescription"></i> Receituários</a></li>
                        <li><a href="declaracoes.php" class="active"><i class="fas fa-file-medical"></i> Declarações</a></li>
                    </ul>
                </div>
                <div class="menu-section"><h3>Administração</h3>
                    <ul>
                        <li><a href="clinica.php"><i class="fas fa-hospital"></i> Clínica</a></li>
                        <li><a href="relatorios.php"><i class="fas fa-chart-line"></i> Relatórios</a></li>
                    </ul>
                </div>
            </div>
            <div class="user-profile">
                <div class="user-avatar"><div class="avatar-placeholder"><?php echo $usuario_iniciais; ?></div><div class="online-status"></div></div>
                <div class="user-info"><h4><?php echo htmlspecialchars($usuario_nome); ?></h4><p><?php echo ucfirst($usuario_tipo); ?></p></div>
                <div class="user-actions"><a href="logout.php" title="Sair"><i class="fas fa-sign-out-alt"></i></a></div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <header class="top-bar">
                <div class="top-bar-left">
                    <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <div class="search-bar"><i class="fas fa-search"></i><input type="text" placeholder="Pesquisar..."></div>
                </div>
                <div class="top-bar-right">
                    <button class="notification-btn"><i class="fas fa-bell"></i><span class="notification-badge">0</span></button>
                    <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
                    <div class="quick-actions">
                        <?php if (hasPermissao('medico')): ?>
                            <a href="declaracoes/novo.php" class="quick-action-btn" title="Nova Declaração"><i class="fas fa-file-medical"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
            </header>

            <!-- Conteúdo -->
            <div class="dashboard-content">
                <!-- Mensagem flash -->
                <?php if (isset($_SESSION['flash'])): ?>
                    <div class="alert alert-<?php echo $_SESSION['flash']['tipo']; ?>" style="padding:15px; border-radius:8px; margin-bottom:20px; background:<?php echo $_SESSION['flash']['tipo']=='success'?'#20c997':'#ff4757'; ?>; color:white;">
                        <?php echo $_SESSION['flash']['msg']; ?>
                    </div>
                    <?php unset($_SESSION['flash']); ?>
                <?php endif; ?>

                <div class="page-header">
                    <h1><i class="fas fa-file-medical" style="color:var(--primary);"></i> Declarações</h1>
                    <?php if (hasPermissao('medico')): ?>
                        <a href="declaracoes/novo.php" class="btn-primary"><i class="fas fa-plus"></i> Nova Declaração</a>
                    <?php endif; ?>
                </div>

                <!-- Filtros -->
                <div class="filters-card">
                    <form method="GET" class="filters-form">
                        <div class="form-group">
                            <label>Paciente</label>
                            <select name="paciente_id">
                                <option value="">Todos</option>
                                <?php foreach ($pacientes as $p): ?>
                                    <option value="<?php echo $p['id']; ?>" <?php echo $paciente_id == $p['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($p['nome']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Médico</label>
                            <select name="medico_id">
                                <option value="">Todos</option>
                                <?php foreach ($medicos as $m): ?>
                                    <option value="<?php echo $m['id']; ?>" <?php echo $medico_id == $m['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($m['nome']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Data Início</label>
                            <input type="date" name="data_inicio" value="<?php echo htmlspecialchars($data_inicio); ?>">
                        </div>
                        <div class="form-group">
                            <label>Data Fim</label>
                            <input type="date" name="data_fim" value="<?php echo htmlspecialchars($data_fim); ?>">
                        </div>
                        <div class="form-group">
                            <label>Tipo</label>
                            <select name="tipo">
                                <option value="">Todos</option>
                                <option value="comparecimento" <?php echo $tipo == 'comparecimento' ? 'selected' : ''; ?>>Comparecimento</option>
                                <option value="atestado" <?php echo $tipo == 'atestado' ? 'selected' : ''; ?>>Atestado</option>
                                <option value="declaracao" <?php echo $tipo == 'declaracao' ? 'selected' : ''; ?>>Declaração</option>
                                <option value="outros" <?php echo $tipo == 'outros' ? 'selected' : ''; ?>>Outros</option>
                            </select>
                        </div>
                        <button type="submit" class="btn-filter"><i class="fas fa-filter"></i> Filtrar</button>
                    </form>
                </div>

                <!-- Tabela -->
                <div class="table-card">
                    <div class="table-header">
                        <h3><i class="fas fa-list"></i> Lista de Declarações</h3>
                        <span class="view-all">Total: <?php echo count($declaracoes); ?></span>
                    </div>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Paciente</th>
                                    <th>Médico</th>
                                    <th>Tipo</th>
                                    <th>Código</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($declaracoes) > 0): ?>
                                    <?php foreach ($declaracoes as $d): ?>
                                    <tr>
                                        <td><?php echo date('d/m/Y H:i', strtotime($d['data_emissao'])); ?></td>
                                        <td>
                                            <div style="display:flex; align-items:center; gap:10px;">
                                                <div class="patient-avatar-small"><?php echo strtoupper(substr($d['paciente_nome'],0,2)); ?></div>
                                                <strong><?php echo htmlspecialchars($d['paciente_nome']); ?></strong>
                                            </div>
                                        </td>
                                        <td><?php echo htmlspecialchars($d['medico_nome']); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo $d['tipo']; ?>">
                                                <?php echo ucfirst($d['tipo']); ?>
                                            </span>
                                        </td>
                                        <td><code><?php echo htmlspecialchars($d['codigo_verificacao']); ?></code></td>
                                        <td class="actions">
                                            <a href="declaracoes/visualizar.php?id=<?php echo $d['id']; ?>" class="btn-icon" title="Visualizar"><i class="fas fa-eye"></i></a>
                                            <?php if (hasPermissao('medico') && $_SESSION['usuario_id'] == $d['usuario_id']): ?>
                                                <a href="declaracoes/editar.php?id=<?php echo $d['id']; ?>" class="btn-icon" title="Editar"><i class="fas fa-edit"></i></a>
                                                <a href="declaracoes/excluir.php?id=<?php echo $d['id']; ?>" class="btn-icon" onclick="return confirm('Excluir esta declaração?')" title="Excluir"><i class="fas fa-trash"></i></a>
                                            <?php endif; ?>
                                            <a href="declaracoes/pdf.php?id=<?php echo $d['id']; ?>" class="btn-icon" target="_blank" title="Gerar PDF"><i class="fas fa-file-pdf"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="6" class="empty-state"><i class="fas fa-file-medical"></i><p>Nenhuma declaração encontrada.</p></td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <footer class="main-footer">
                <div class="footer-content"><p>desenvolvido por <a href="https://alfasistemas.dev.br" target="_blank">alfa sistemas s.a</a> (85) 2028-4584</p></div>
            </footer>
        </main>
    </div>

    <script>
        window.addEventListener('load', function() { setTimeout(() => { document.getElementById('preloader').style.opacity = '0'; setTimeout(() => document.getElementById('preloader').style.display = 'none', 500); }, 800); });
        const sidebarToggle = document.getElementById('sidebarToggle'), sidebar = document.getElementById('sidebar'), overlay = document.getElementById('sidebarOverlay');
        if (sidebarToggle) { sidebarToggle.addEventListener('click', () => { sidebar.classList.toggle('active'); overlay.classList.toggle('active'); }); overlay.addEventListener('click', () => { sidebar.classList.remove('active'); overlay.classList.remove('active'); }); }
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => { document.body.classList.toggle('dark-theme'); const icon = themeToggle.querySelector('i'); if (document.body.classList.contains('dark-theme')) { icon.className = 'fas fa-sun'; localStorage.setItem('theme', 'dark'); } else { icon.className = 'fas fa-moon'; localStorage.setItem('theme', 'light'); } });
            if (localStorage.getItem('theme') === 'dark') { document.body.classList.add('dark-theme'); themeToggle.querySelector('i').className = 'fas fa-sun'; }
        }
    </script>
</body>
</html>