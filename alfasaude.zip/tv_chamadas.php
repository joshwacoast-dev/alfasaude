<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'config/database.php';

try {
    $config = $pdo->query("SELECT * FROM config_chamada LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    if (!$config) {
        $config = [
            'mensagem_base' => 'O paciente [NOME], da especialidade [ESPECIALIDADE], por favor, dirigir-se ao [SALA].', 
            'video_fundo' => ''
        ];
    }
} catch (Exception $e) {
    $config = [
        'mensagem_base' => 'O paciente [NOME], da especialidade [ESPECIALIDADE], por favor, dirigir-se ao [SALA].', 
        'video_fundo' => ''
    ];
}

$video_url = $config['video_fundo'] ?? '';
$mensagem_base = $config['mensagem_base'] ?? 'O paciente [NOME], da especialidade [ESPECIALIDADE], por favor, dirigir-se ao [SALA].';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel TV - Alfa Saúde</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        html, body { 
            width: 100%; 
            height: 100%; 
            overflow: hidden;
            font-family: 'Poppins', sans-serif;
            background: #000;
        }

        :root {
            --verde: #20c997;
            --azul: #2e86de;
            --amarelo: #ff9f43;
            --vermelho: #ff4757;
        }

        #bg-video { 
            position: fixed; 
            top: 0; left: 0; 
            width: 100vw; 
            height: 100vh; 
            object-fit: cover; 
            z-index: 1; 
        }

        .video-fallback {
            position: fixed;
            top: 0; left: 0;
            width: 100vw; height: 100vh;
            background: linear-gradient(135deg, #1e1b4b 0%, #312e81 50%, #6f42c1 100%);
            z-index: 1;
        }

        .video-overlay {
            position: fixed;
            top: 0; left: 0; 
            width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.3);
            z-index: 2;
        }

        .tv-header {
            position: fixed;
            top: 0; left: 0;
            width: 100%;
            padding: 25px 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 10;
            background: linear-gradient(180deg, rgba(0,0,0,0.7) 0%, transparent 100%);
        }

        .tv-logo {
            display: flex;
            align-items: center;
            gap: 15px;
            color: white;
            font-size: 28px;
            font-weight: 800;
            text-shadow: 0 2px 10px rgba(0,0,0,0.5);
        }

        .tv-logo i {
            background: white;
            color: #6f42c1;
            padding: 10px;
            border-radius: 12px;
            font-size: 22px;
        }

        .tv-clock {
            color: white;
            font-size: 32px;
            font-weight: 700;
            background: rgba(111, 66, 193, 0.9);
            padding: 10px 25px;
            border-radius: 12px;
            font-variant-numeric: tabular-nums;
            box-shadow: 0 4px 20px rgba(111, 66, 193, 0.4);
        }

        .call-card {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0.8);
            background: white;
            color: #1e293b;
            padding: 50px 80px;
            border-radius: 30px;
            text-align: center;
            z-index: 20;
            box-shadow: 0 30px 80px rgba(0, 0, 0, 0.6);
            border: 8px solid #ccc;
            opacity: 0;
            pointer-events: none;
            /* Transição suave para entrada e saída */
            transition: all 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
            min-width: 700px;
        }

        .call-card.active {
            opacity: 1;
            transform: translate(-50%, -50%) scale(1);
            pointer-events: auto;
        }

        /* Classe para quando o card está saindo (opcional, para animação de saída diferente) */
        .call-card.exiting {
            opacity: 0;
            transform: translate(-50%, -50%) scale(0.9);
        }

        .call-card.pulsing {
            animation: pulse-card 1.5s infinite;
        }

        .call-card.gravidade-verde { border-color: var(--verde); }
        .call-card.gravidade-azul { border-color: var(--azul); }
        .call-card.gravidade-amarelo { border-color: var(--amarelo); }
        .call-card.gravidade-vermelho { border-color: var(--vermelho); }

        .call-card.gravidade-verde .call-senha { color: var(--verde); }
        .call-card.gravidade-azul .call-senha { color: var(--azul); }
        .call-card.gravidade-amarelo .call-senha { color: var(--amarelo); }
        .call-card.gravidade-vermelho .call-senha { color: var(--vermelho); }

        .call-card.gravidade-verde .call-icon { background: linear-gradient(135deg, var(--verde), #1baa80); }
        .call-card.gravidade-azul .call-icon { background: linear-gradient(135deg, var(--azul), #1e6bb8); }
        .call-card.gravidade-amarelo .call-icon { background: linear-gradient(135deg, var(--amarelo), #e68a00); }
        .call-card.gravidade-vermelho .call-icon { background: linear-gradient(135deg, var(--vermelho), #e04050); }

        @keyframes pulse-card {
            0% { box-shadow: 0 30px 80px rgba(0, 0, 0, 0.6), 0 0 0 0 rgba(111, 66, 193, 0.7); }
            50% { box-shadow: 0 30px 80px rgba(0, 0, 0, 0.6), 0 0 0 40px rgba(111, 66, 193, 0); }
            100% { box-shadow: 0 30px 80px rgba(0, 0, 0, 0.6), 0 0 0 0 rgba(111, 66, 193, 0); }
        }

        .call-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #6f42c1, #a855f7);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            margin: 0 auto 20px;
            box-shadow: 0 10px 30px rgba(111, 66, 193, 0.4);
        }

        .call-label { 
            font-size: 18px; 
            color: #6c757d; 
            text-transform: uppercase; 
            letter-spacing: 4px; 
            font-weight: 700; 
            margin-bottom: 15px; 
        }

        .call-senha { 
            font-size: 120px; 
            font-weight: 900; 
            color: #6f42c1; 
            line-height: 1; 
            margin-bottom: 10px;
            text-shadow: 0 4px 20px rgba(111, 66, 193, 0.2);
        }

        .call-nome { 
            font-size: 42px; 
            font-weight: 700; 
            color: #1e293b; 
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* ESTILO PARA ESPECIALIDADE */
        .call-especialidade {
            display: inline-block;
            background: #f1f5f9;
            color: #475569;
            padding: 8px 20px;
            border-radius: 50px;
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 20px;
            border: 1px solid #e2e8f0;
        }

        /* BADGE PREFERENCIAL GRANDE */
        .call-preferencial {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            padding: 12px 30px;
            border-radius: 25px;
            font-size: 22px;
            font-weight: 800;
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 1px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .call-preferencial.idoso { background: #e3f2fd; color: #1976d2; border: 2px solid #1976d2; }
        .call-preferencial.gestante { background: #fce4ec; color: #c2185b; border: 2px solid #c2185b; }
        .call-preferencial.deficiente { background: #f3e5f5; color: #7b1fa2; border: 2px solid #7b1fa2; }
        .call-preferencial.lactante { background: #fff3e0; color: #f57c00; border: 2px solid #f57c00; }

        /* TEMPO DE ESPERA */
        .call-tempo-espera {
            display: inline-block;
            background: rgba(108, 117, 125, 0.1);
            color: #6c757d;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 20px;
        }

        .call-local { 
            font-size: 28px; 
            background: linear-gradient(135deg, #6f42c1, #5a32a3);
            color: white; 
            padding: 15px 40px; 
            border-radius: 50px; 
            font-weight: 700; 
            display: inline-flex; 
            align-items: center; 
            gap: 12px;
            box-shadow: 0 8px 25px rgba(111, 66, 193, 0.4);
        }

        .history-panel {
            position: fixed;
            bottom: 40px;
            right: 40px;
            width: 340px;
            max-height: calc(100vh - 200px);
            background: rgba(15, 23, 42, 0.85);
            backdrop-filter: blur(15px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.15);
            z-index: 15;
            display: flex;
            flex-direction: column;
            padding: 25px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
        }

        .history-panel h3 {
            font-size: 18px;
            color: #a855f7;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 1px solid rgba(255,255,255,0.15);
            padding-bottom: 12px;
            font-weight: 700;
        }

        .history-list {
            overflow-y: auto;
            flex: 1;
        }

        .history-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            background: rgba(255, 255, 255, 0.08);
            border-radius: 10px;
            margin-bottom: 10px;
            border-left: 4px solid #ccc;
            transition: 0.3s;
        }

        .history-item.gravidade-verde { border-left-color: var(--verde); }
        .history-item.gravidade-azul { border-left-color: var(--azul); }
        .history-item.gravidade-amarelo { border-left-color: var(--amarelo); }
        .history-item.gravidade-vermelho { border-left-color: var(--vermelho); }

        .history-item:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateX(-3px);
        }

        .history-senha { 
            font-size: 22px; 
            font-weight: 800; 
            color: #cbd5e1; 
        }
        .history-nome { 
            font-size: 14px; 
            font-weight: 500; 
            color: #e2e8f0; 
            margin-top: 2px;
        }
        .history-info {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 4px;
        }
        .history-local { 
            font-size: 12px; 
            color: #94a3b8; 
            background: rgba(0,0,0,0.4); 
            padding: 4px 10px; 
            border-radius: 6px; 
            font-weight: 600;
        }
        .history-tempo {
            font-size: 11px;
            color: #64748b;
            font-weight: 600;
        }

        .history-preferencial {
            display: inline-block;
            font-size: 14px;
            margin-left: 5px;
        }

        #start-audio-btn { 
            position: fixed; 
            bottom: 40px; 
            left: 40px;
            background: linear-gradient(135deg, #20c997, #1baa80);
            color: white;
            padding: 18px 35px; 
            border: none; 
            border-radius: 50px; 
            font-size: 16px; 
            font-weight: 700; 
            cursor: pointer; 
            box-shadow: 0 10px 40px rgba(32, 201, 151, 0.5); 
            z-index: 100; 
            display: flex; 
            align-items: center; 
            gap: 12px;
            transition: 0.3s;
        }
        #start-audio-btn:hover { 
            transform: translateY(-3px);
            box-shadow: 0 15px 50px rgba(32, 201, 151, 0.6);
        }
        .hidden { display: none !important; }

        .idle-message {
            position: fixed;
            bottom: 50px;
            left: 50px;
            color: white;
            z-index: 10;
            text-shadow: 0 2px 10px rgba(0,0,0,0.5);
            transition: opacity 0.5s ease;
        }
        .idle-message h2 {
            font-size: 36px;
            font-weight: 800;
            margin-bottom: 5px;
        }
        .idle-message p {
            font-size: 18px;
            opacity: 0.9;
        }

        /* ESTILOS DO CLOSED CAPTION (LEGENDAS) */
        #closed-caption {
            position: fixed;
            bottom: 150px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 0, 0, 0.85);
            color: #ffffff;
            padding: 15px 40px;
            border-radius: 15px;
            font-size: 28px;
            font-weight: 600;
            text-align: center;
            z-index: 30;
            max-width: 80%;
            box-shadow: 0 4px 20px rgba(0,0,0,0.6);
            border: 2px solid rgba(255,255,255,0.2);
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s ease, transform 0.3s ease;
        }

        #closed-caption.visible {
            opacity: 1;
            transform: translateX(-50%) translateY(-10px);
        }

        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #6f42c1; border-radius: 3px; }
    </style>
</head>
<body>

    <?php if (!empty($video_url)): ?>
        <video id="bg-video" autoplay muted loop playsinline crossorigin="anonymous">
            <source src="<?= htmlspecialchars($video_url) ?>" type="video/mp4">
            <track kind="subtitles" srclang="pt-BR" label="Português" default>
        </video>
    <?php else: ?>
        <div class="video-fallback"></div>
    <?php endif; ?>
    
    <div class="video-overlay"></div>

    <div class="tv-header">
        <div class="tv-logo">
            <i class="fas fa-stethoscope"></i>
            <span>Painel TV</span>
        </div>
        <div class="tv-clock" id="clock">00:00:00</div>
    </div>

    <div class="idle-message" id="idle-message">
        <h2>Aguardando Chamadas</h2>
        <p>O próximo paciente será anunciado em instantes</p>
    </div>

    <div class="call-card" id="call-card">
        <div class="call-icon"><i class="fas fa-bullhorn"></i></div>
        <div class="call-label">Atenção</div>
        <div class="call-senha" id="tv-senha">---</div>
        <div class="call-nome" id="tv-nome">Aguardando...</div>
        
        <!-- Container para Especialidade -->
        <div id="tv-especialidade-container"></div>
        
        <div id="tv-preferencial-container"></div>
        <div id="tv-tempo-container"></div>
        <div class="call-local" id="tv-local"><i class="fas fa-door-open"></i> --</div>
    </div>

    <!-- Elemento de Legenda Flutuante -->
    <div id="closed-caption"></div>

    <div class="history-panel">
        <h3><i class="fas fa-history"></i> Últimos Chamados</h3>
        <div class="history-list" id="tv-ultimos-list">
            <p style="text-align:center; color:#94a3b8; padding:20px; font-size:14px;">Carregando...</p>
        </div>
    </div>

    <button id="start-audio-btn" onclick="iniciarAudio()">
        <i class="fas fa-volume-up"></i> Ativar Voz do Painel
    </button>

    <script>
        let audioAtivado = false;
        let ultimaDataChamada = null;
        let timerAutoHide = null; // Variável para controlar o tempo de exibição
        
        // A mensagem base deve conter [NOME], [ESPECIALIDADE] e [SALA]
        const MENSAGEM_BASE = `<?= addslashes($mensagem_base) ?>`;

        const iconesPreferencial = {
            'idoso': '👴',
            'gestante': '🤰',
            'deficiente': '♿',
            'lactante': '👶'
        };

        // Variáveis para controle de legenda no vídeo
        let videoTrack = null;

        function atualizarRelogio() {
            document.getElementById('clock').innerText = new Date().toLocaleTimeString('pt-BR');
        }
        setInterval(atualizarRelogio, 1000);
        atualizarRelogio();

        function iniciarAudio() {
            audioAtivado = true;
            document.getElementById('start-audio-btn').classList.add('hidden');
            
            // Inicializa track de legenda do vídeo se existir
            const video = document.getElementById('bg-video');
            if (video && video.textTracks.length > 0) {
                videoTrack = video.textTracks[0];
                videoTrack.mode = 'showing';
            }
            
            falar("Sistema de chamadas ativado com sucesso.");
        }

        // Função para adicionar legenda dinâmica ao vídeo
        function adicionarLegendaVideo(texto) {
            if (!videoTrack) return;

            // Limpa legendas anteriores
            while (videoTrack.cues.length > 0) {
                videoTrack.removeCue(videoTrack.cues[0]);
            }

            const video = document.getElementById('bg-video');
            const currentTime = video.currentTime;
            const duration = (texto.length * 0.15) + 2; 

            try {
                const cue = new VTTCue(currentTime, currentTime + duration, texto);
                cue.align = "center";
                cue.position = 50;
                cue.line = "auto"; 
                videoTrack.addCue(cue);
            } catch (e) {
                console.log("Erro ao adicionar cue:", e);
            }
        }

        function falar(texto) {
            if (!audioAtivado) return;
            
            // 1. Exibir Legenda HTML
            const captionEl = document.getElementById('closed-caption');
            if (captionEl) {
                captionEl.innerText = texto;
                captionEl.classList.add('visible');
            }

            // 2. Exibir Legenda no Vídeo
            adicionarLegendaVideo(texto);

            // 3. Falar o texto
            window.speechSynthesis.cancel();
            const utterance = new SpeechSynthesisUtterance(texto);
            utterance.lang = 'pt-BR';
            utterance.rate = 0.9;
            
            const voices = window.speechSynthesis.getVoices();
            const voz = voices.find(v => v.lang.includes('pt-BR') && (v.name.includes('Google') || v.name.includes('Brazil')));
            if (voz) utterance.voice = voz;
            
            // Esconde a legenda HTML quando terminar de falar
            utterance.onend = function() {
                if (captionEl) {
                    setTimeout(() => captionEl.classList.remove('visible'), 2000);
                }
            };

            window.speechSynthesis.speak(utterance);
        }

        // Função para esconder o cartão automaticamente
        function esconderCartao() {
            const callCard = document.getElementById('call-card');
            const idleMsg = document.getElementById('idle-message');
            
            // Adiciona classe para animação de saída (opcional) ou remove active direto
            callCard.classList.remove('active', 'pulsing', 'gravidade-verde', 'gravidade-azul', 'gravidade-amarelo', 'gravidade-vermelho');
            
            // Mostra mensagem de espera novamente
            idleMsg.style.display = 'block';
            
            // Limpa os dados visuais para não ficar "fantasma" se demorar a carregar o próximo
            document.getElementById('tv-especialidade-container').innerHTML = '';
        }

        async function atualizarPainel() {
            try {
                const response = await fetch('api_chamadas.php?t=' + new Date().getTime());
                const data = await response.json();
                
                const callCard = document.getElementById('call-card');
                const idleMsg = document.getElementById('idle-message');

                if (data.atual && data.atual.status === 'chamando') {
                    
                    // Se já estiver ativo e for a MESMA chamada, não faz nada (evita resetar o timer)
                    if (callCard.classList.contains('active') && ultimaDataChamada === data.atual.data_ultima_chamada) {
                        return; 
                    }

                    // Nova chamada detectada: Reseta timer anterior se existir
                    if (timerAutoHide) {
                        clearTimeout(timerAutoHide);
                    }

                    callCard.classList.remove('gravidade-verde', 'gravidade-azul', 'gravidade-amarelo', 'gravidade-vermelho');
                    
                    const gravidade = data.atual.gravidade || 'verde';
                    callCard.classList.add('gravidade-' + gravidade);
                    
                    callCard.classList.add('active');
                    idleMsg.style.display = 'none';
                    
                    document.getElementById('tv-senha').innerText = data.atual.senha;
                    document.getElementById('tv-nome').innerText = data.atual.nome_paciente;
                    document.getElementById('tv-local').innerHTML = `<i class="fas fa-door-open"></i> ${data.atual.local_atendimento}`;
                    
                    // --- EXIBIR ESPECIALIDADE NA TELA ---
                    const espContainer = document.getElementById('tv-especialidade-container');
                    if (data.atual.especialidade) {
                        espContainer.innerHTML = `<div class="call-especialidade"><i class="fas fa-user-md"></i> ${data.atual.especialidade}</div>`;
                    } else {
                        espContainer.innerHTML = '';
                    }
                    
                    // Badge PREFERENCIAL
                    const prefContainer = document.getElementById('tv-preferencial-container');
                    if (data.atual.preferencial && data.atual.preferencial !== 'nenhum') {
                        const icone = iconesPreferencial[data.atual.preferencial] || '';
                        prefContainer.innerHTML = `<div class="call-preferencial ${data.atual.preferencial}">${icone} PREFERENCIAL - ${data.atual.preferencial.toUpperCase()}</div>`;
                    } else {
                        prefContainer.innerHTML = '';
                    }
                    
                    // Tempo de espera
                    const tempoContainer = document.getElementById('tv-tempo-container');
                    if (data.atual.tempo_espera_minutos) {
                        tempoContainer.innerHTML = `<div class="call-tempo-espera"><i class="fas fa-clock"></i> Espera: ${data.atual.tempo_espera_minutos} min</div>`;
                    } else {
                        tempoContainer.innerHTML = '';
                    }
                    
                    // Lógica de Fala e Timer
                    if (data.atual.data_ultima_chamada && data.atual.data_ultima_chamada !== ultimaDataChamada) {
                        ultimaDataChamada = data.atual.data_ultima_chamada;
                        
                        let nome = data.atual.nome_paciente || 'Paciente';
                        let sala = data.atual.local_atendimento || 'Recepção';
                        let especialidade = data.atual.especialidade || 'Clínica Geral';
                        
                        let msg = MENSAGEM_BASE
                            .replace('[NOME]', nome)
                            .replace('[ESPECIALIDADE]', especialidade)
                            .replace('[SALA]', sala);
                        
                        if (data.atual.preferencial && data.atual.preferencial !== 'nenhum') {
                            msg += ' Atendimento preferencial.';
                        }
                        
                        callCard.classList.add('pulsing');
                        falar(msg);
                        
                        // Remove pulsing após 10s
                        setTimeout(() => {
                            callCard.classList.remove('pulsing');
                        }, 10000);

                        // --- NOVO: Configura o timer para sumir após 30 segundos ---
                        timerAutoHide = setTimeout(esconderCartao, 30000);
                    }
                } else {
                    // Se não há chamada ativa no banco, limpa tudo imediatamente
                    if (timerAutoHide) clearTimeout(timerAutoHide);
                    callCard.classList.remove('active', 'pulsing', 'gravidade-verde', 'gravidade-azul', 'gravidade-amarelo', 'gravidade-vermelho');
                    idleMsg.style.display = 'block';
                    document.getElementById('tv-especialidade-container').innerHTML = '';
                }

                // Atualiza histórico
                const ultimosList = document.getElementById('tv-ultimos-list');
                ultimosList.innerHTML = '';
                
                if (data.ultimos && data.ultimos.length > 0) {
                    data.ultimos.forEach(item => {
                        const gravidade = item.gravidade || 'verde';
                        const preferencial = item.preferencial && item.preferencial !== 'nenhum' ? iconesPreferencial[item.preferencial] || '' : '';
                        const tempo = item.tempo_espera_minutos ? `${item.tempo_espera_minutos}min` : '';
                        
                        ultimosList.innerHTML += `
                            <div class="history-item gravidade-${gravidade}">
                                <div>
                                    <div class="history-senha">${item.senha} ${preferencial}</div>
                                    <div class="history-nome">${item.nome_paciente}</div>
                                </div>
                                <div class="history-info">
                                    <div class="history-local"><i class="fas fa-check"></i> ${item.local_atendimento}</div>
                                    ${tempo ? `<div class="history-tempo"><i class="fas fa-clock"></i> ${tempo}</div>` : ''}
                                </div>
                            </div>`;
                    });
                } else {
                    ultimosList.innerHTML = '<p style="text-align:center; color:#94a3b8; padding:20px; font-size:14px;">Nenhum atendimento recente.</p>';
                }

            } catch (error) {
                console.error('Erro ao atualizar painel:', error);
            }
        }

        window.speechSynthesis.onvoiceschanged = () => {};
        setInterval(atualizarPainel, 3000);
        atualizarPainel();
    </script>
</body>
</html>