<?php
// ============================================
// ARQUIVO: agendamentos/cancelar.php
// DESCRIÇÃO: Cancela um agendamento existente
// ============================================

// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/database.php';
require_once '../config/auth.php';
verificarLogin();

// Apenas médicos e admin podem cancelar
if (!hasPermissao('medico')) {
    header('Location: ../agendamentos.php?erro=permissao');
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    header('Location: ../agendamentos.php?erro=id_invalido');
    exit;
}

// Buscar agendamento
$stmt = $pdo->prepare("SELECT status FROM agendamentos WHERE id = ?");
$stmt->execute([$id]);
$agendamento = $stmt->fetch();

if (!$agendamento) {
    // Se não existir, redireciona com mensagem de erro
    session_start();
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Agendamento não encontrado.'];
    header('Location: ../agendamentos.php');
    exit;
}

// Verificar se já está cancelado ou concluído
if ($agendamento['status'] === 'cancelado') {
    session_start();
    $_SESSION['flash'] = ['tipo' => 'warning', 'msg' => 'Agendamento já estava cancelado.'];
    header('Location: ../agendamentos.php');
    exit;
}

if ($agendamento['status'] === 'concluido') {
    session_start();
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Agendamentos concluídos não podem ser cancelados.'];
    header('Location: ../agendamentos.php');
    exit;
}

// Atualizar status para cancelado
try {
    $stmt = $pdo->prepare("UPDATE agendamentos SET status = 'cancelado' WHERE id = ?");
    if ($stmt->execute([$id])) {
        session_start();
        $_SESSION['flash'] = ['tipo' => 'success', 'msg' => 'Agendamento cancelado com sucesso!'];
    } else {
        session_start();
        $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Erro ao cancelar agendamento.'];
    }
} catch (PDOException $e) {
    session_start();
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Erro no banco de dados: ' . $e->getMessage()];
}

header('Location: ../agendamentos.php');
exit;