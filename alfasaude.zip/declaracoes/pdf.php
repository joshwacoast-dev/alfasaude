<?php
// ============================================
// ARQUIVO: declaracoes/pdf.php
// DESCRIÇÃO: Versão para impressão da declaração (HTML)
// ============================================

// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/database.php';
require_once '../config/auth.php';
verificarLogin();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    die('ID inválido.');
}

// Buscar dados da declaração com paciente e médico
$stmt = $pdo->prepare("
    SELECT d.*,
           p.nome as paciente_nome, p.cpf as paciente_cpf, p.data_nascimento as paciente_data_nascimento,
           u.nome as medico_nome, u.crm as medico_crm, u.especialidade as medico_especialidade
    FROM declaracoes d
    JOIN pacientes p ON d.paciente_id = p.id
    JOIN usuarios u ON d.usuario_id = u.id
    WHERE d.id = ?
");
$stmt->execute([$id]);
$declaracao = $stmt->fetch();

if (!$declaracao) {
    die('Declaração não encontrada.');
}

// Buscar dados da clínica
$clinica = $pdo->query("SELECT * FROM clinica LIMIT 1")->fetch();

// Mapeamento dos tipos
$tipos = [
    'comparecimento' => 'Comparecimento',
    'atestado'       => 'Atestado',
    'declaracao'     => 'Declaração',
    'outros'         => 'Outros'
];
$tipo_display = $tipos[$declaracao['tipo']] ?? ucfirst($declaracao['tipo']);

// Função para formatar data
function formatarData($data) {
    return $data ? date('d/m/Y', strtotime($data)) : '';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Declaração #<?php echo $id; ?> - <?php echo htmlspecialchars($clinica['nome'] ?? 'Alfa Saúde'); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Arial', 'Helvetica', sans-serif;
            background: #f5f5f5;
            padding: 20px;
            line-height: 1.5;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            border-radius: 8px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #6f42c1;
        }
        .logo {
            max-height: 80px;
            margin-bottom: 10px;
        }
        .clinica-nome {
            font-size: 24px;
            font-weight: bold;
            color: #6f42c1;
            margin: 5px 0;
        }
        .clinica-info {
            font-size: 13px;
            color: #666;
        }
        .titulo-documento {
            text-align: center;
            font-size: 20px;
            font-weight: bold;
            color: #6f42c1;
            margin: 30px 0 20px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .info-row {
            margin-bottom: 10px;
            display: flex;
        }
        .info-label {
            width: 140px;
            font-weight: 600;
            color: #555;
        }
        .info-value {
            flex: 1;
            color: #333;
        }
        .conteudo {
            margin: 30px 0;
            padding: 20px;
            background: #f9f9f9;
            border-left: 4px solid #6f42c1;
            font-size: 14px;
            white-space: pre-wrap;
            line-height: 1.8;
        }
        .assinatura {
            margin-top: 50px;
            text-align: right;
        }
        .assinatura-linha {
            margin-top: 40px;
            width: 300px;
            margin-left: auto;
            border-top: 1px solid #333;
            padding-top: 10px;
            text-align: center;
            font-size: 14px;
        }
        .assinatura-nome {
            font-weight: bold;
        }
        .footer {
            margin-top: 40px;
            text-align: center;
            font-size: 11px;
            color: #888;
            border-top: 1px solid #ddd;
            padding-top: 15px;
        }
        .codigo-verificacao {
            background: #f0f0f0;
            padding: 8px 15px;
            border-radius: 20px;
            font-family: monospace;
            display: inline-block;
            margin-top: 10px;
        }
        @media print {
            body {
                background: white;
                padding: 0;
            }
            .container {
                box-shadow: none;
                padding: 20px;
            }
            .no-print {
                display: none;
            }
        }
        .btn-print {
            display: block;
            width: 200px;
            margin: 20px auto 0;
            padding: 12px;
            background: #6f42c1;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
        }
        .btn-print:hover {
            background: #4a1e8a;
        }
        .no-print {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <?php if (!empty($clinica['logo']) && file_exists('../assets/img/' . $clinica['logo'])): ?>
                <img src="../assets/img/<?php echo $clinica['logo']; ?>" alt="Logo" class="logo">
            <?php endif; ?>
            <div class="clinica-nome"><?php echo htmlspecialchars($clinica['nome'] ?? 'Alfa Saúde'); ?></div>
            <div class="clinica-info">
                <?php echo htmlspecialchars($clinica['endereco'] ?? ''); ?><br>
                Tel: <?php echo htmlspecialchars($clinica['telefone'] ?? ''); ?> | E-mail: <?php echo htmlspecialchars($clinica['email'] ?? ''); ?>
            </div>
        </div>

        <div class="titulo-documento"><?php echo $tipo_display; ?></div>

        <div class="info-row">
            <span class="info-label">Paciente:</span>
            <span class="info-value"><strong><?php echo htmlspecialchars($declaracao['paciente_nome']); ?></strong></span>
        </div>
        <?php if ($declaracao['paciente_cpf']): ?>
        <div class="info-row">
            <span class="info-label">CPF:</span>
            <span class="info-value"><?php echo htmlspecialchars($declaracao['paciente_cpf']); ?></span>
        </div>
        <?php endif; ?>
        <?php if ($declaracao['paciente_data_nascimento']): ?>
        <div class="info-row">
            <span class="info-label">Data Nasc.:</span>
            <span class="info-value"><?php echo formatarData($declaracao['paciente_data_nascimento']); ?></span>
        </div>
        <?php endif; ?>

        <div class="info-row">
            <span class="info-label">Médico:</span>
            <span class="info-value">Dr(a). <?php echo htmlspecialchars($declaracao['medico_nome']); ?></span>
        </div>
        <?php if ($declaracao['medico_crm']): ?>
        <div class="info-row">
            <span class="info-label">CRM:</span>
            <span class="info-value"><?php echo htmlspecialchars($declaracao['medico_crm']); ?></span>
        </div>
        <?php endif; ?>
        <?php if ($declaracao['medico_especialidade']): ?>
        <div class="info-row">
            <span class="info-label">Especialidade:</span>
            <span class="info-value"><?php echo htmlspecialchars($declaracao['medico_especialidade']); ?></span>
        </div>
        <?php endif; ?>

        <div class="info-row">
            <span class="info-label">Data da emissão:</span>
            <span class="info-value"><?php echo date('d/m/Y H:i', strtotime($declaracao['data_emissao'])); ?></span>
        </div>

        <div class="info-row">
            <span class="info-label">Código de verificação:</span>
            <span class="info-value"><span class="codigo-verificacao"><?php echo htmlspecialchars($declaracao['codigo_verificacao']); ?></span></span>
        </div>

        <div class="conteudo">
            <?php echo nl2br(htmlspecialchars($declaracao['conteudo'])); ?>
        </div>

        <div class="assinatura">
            <div class="assinatura-linha">
                <div class="assinatura-nome">Dr(a). <?php echo htmlspecialchars($declaracao['medico_nome']); ?></div>
                <div><?php echo htmlspecialchars($declaracao['medico_crm'] ?? ''); ?></div>
            </div>
        </div>

        <div class="footer">
            Documento gerado em <?php echo date('d/m/Y H:i:s'); ?> por <?php echo htmlspecialchars($_SESSION['usuario_nome'] ?? 'Sistema'); ?>.<br>
            Válido apenas com a assinatura digital do médico responsável.<br>
            desenvolvido por <a href="https://alfasistemas.dev.br" target="_blank" style="color:#6f42c1; text-decoration:none;">alfa sistemas s.a</a> (85) 2028-4584
        </div>

        <div class="no-print">
            <button class="btn-print" onclick="window.print();"><i class="fas fa-print"></i> Imprimir / Salvar PDF</button>
        </div>
    </div>

    <!-- Font Awesome para o ícone de impressão (opcional) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</body>
</html>