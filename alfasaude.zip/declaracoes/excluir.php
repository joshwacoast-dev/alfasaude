<?php
// ============================================
// ARQUIVO: declaracoes/excluir.php
// DESCRIÇÃO: Exclui (fisicamente) uma declaração
// ============================================

// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Iniciar sessão se necessário
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';
require_once '../config/auth.php';
verificarLogin();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'ID inválido.'];
    header('Location: ../declaracoes.php');
    exit;
}

// Buscar dados da declaração para verificar permissão
$stmt = $pdo->prepare("SELECT usuario_id FROM declaracoes WHERE id = ?");
$stmt->execute([$id]);
$declaracao = $stmt->fetch();

if (!$declaracao) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Declaração não encontrada.'];
    header('Location: ../declaracoes.php');
    exit;
}

// Verificar permissão: apenas o médico que criou ou administrador podem excluir
if (!hasPermissao('admin') && $_SESSION['usuario_id'] != $declaracao['usuario_id']) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Você não tem permissão para excluir esta declaração.'];
    header('Location: ../declaracoes.php');
    exit;
}

// Exclusão física (permanente)
try {
    $stmt = $pdo->prepare("DELETE FROM declaracoes WHERE id = ?");
    if ($stmt->execute([$id])) {
        $_SESSION['flash'] = ['tipo' => 'success', 'msg' => 'Declaração excluída com sucesso!'];
    } else {
        $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Erro ao excluir declaração.'];
    }
} catch (PDOException $e) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Erro no banco de dados: ' . $e->getMessage()];
}

header('Location: ../declaracoes.php');
exit;