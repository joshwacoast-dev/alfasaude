<?php
// ============================================
// ARQUIVO: declaracoes/editar.php
// DESCRIÇÃO: Edição de uma declaração existente
// ============================================

// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/database.php';
require_once '../config/auth.php';
verificarLogin();

// Apenas médicos e admin podem editar declarações
if (!hasPermissao('medico')) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Você não tem permissão para editar declarações.'];
    header('Location: ../declaracoes.php');
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'ID inválido.'];
    header('Location: ../declaracoes.php');
    exit;
}

// Buscar dados da declaração
$stmt = $pdo->prepare("SELECT * FROM declaracoes WHERE id = ?");
$stmt->execute([$id]);
$declaracao = $stmt->fetch();

if (!$declaracao) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Declaração não encontrada.'];
    header('Location: ../declaracoes.php');
    exit;
}

// Verificar permissão: apenas o médico que criou ou admin podem editar
if (!hasPermissao('admin') && $_SESSION['usuario_id'] != $declaracao['usuario_id']) {
    $_SESSION['flash'] = ['tipo' => 'error', 'msg' => 'Você não tem permissão para editar esta declaração.'];
    header('Location: ../declaracoes.php');
    exit;
}

// ============================================
// BUSCAR LISTAS AUXILIARES
// ============================================
$pacientes = $pdo->query("SELECT id, nome FROM pacientes WHERE ativo = 1 ORDER BY nome")->fetchAll();

// Tipos de declaração
$tipos = [
    'comparecimento' => 'Comparecimento',
    'atestado'       => 'Atestado',
    'declaracao'     => 'Declaração',
    'outros'         => 'Outros'
];

// ============================================
// PROCESSAR FORMULÁRIO
// ============================================
$erros = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $paciente_id = intval($_POST['paciente_id'] ?? 0);
    $tipo        = $_POST['tipo'] ?? 'comparecimento';
    $conteudo    = trim($_POST['conteudo'] ?? '');

    // Validações
    if ($paciente_id <= 0) $erros[] = "Selecione um paciente.";
    if (empty($conteudo)) $erros[] = "O conteúdo da declaração é obrigatório.";
    if (!array_key_exists($tipo, $tipos)) $tipo = 'comparecimento';

    if (empty($erros)) {
        // Verificar se o paciente existe
        $checkPaciente = $pdo->prepare("SELECT id FROM pacientes WHERE id = ? AND ativo = 1");
        $checkPaciente->execute([$paciente_id]);
        if (!$checkPaciente->fetch()) $erros[] = "Paciente inválido ou inativo.";
    }

    if (empty($erros)) {
        try {
            $stmt = $pdo->prepare("UPDATE declaracoes SET paciente_id = ?, tipo = ?, conteudo = ? WHERE id = ?");
            if ($stmt->execute([$paciente_id, $tipo, $conteudo, $id])) {
                $_SESSION['flash'] = ['tipo' => 'success', 'msg' => 'Declaração atualizada com sucesso!'];
                header('Location: ../declaracoes.php');
                exit;
            } else {
                $erros[] = "Erro ao atualizar declaração. Tente novamente.";
            }
        } catch (PDOException $e) {
            $erros[] = "Erro no banco de dados: " . $e->getMessage();
        }
    }
} else {
    // Pré-preencher campos para exibição no formulário
    $_POST['paciente_id'] = $declaracao['paciente_id'];
    $_POST['tipo']        = $declaracao['tipo'];
    $_POST['conteudo']    = $declaracao['conteudo'];
}

// ============================================
// DADOS DO USUÁRIO LOGADO (para sidebar)
// ============================================
$usuario_logado_nome  = $_SESSION['usuario_nome']  ?? 'Usuário';
$usuario_logado_tipo  = $_SESSION['usuario_tipo']  ?? 'usuario';
$usuario_logado_iniciais = strtoupper(substr($usuario_logado_nome, 0, 2));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Declaração | Alfa Saúde</title>
    <!-- Font Awesome, Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ===== TEMA ORIGINAL (mesmo dos outros) ===== */
        :root {
            --primary: #6f42c1;
            --primary-light: #6f42c1dd;
            --primary-dark: #6f42c1aa;
            --secondary: #20c997;
            --secondary-light: #20c997dd;
            --danger: #ff4757;
            --warning: #ff9f43;
            --info: #2e86de;
            --light: #f8f9fa;
            --dark: #343a40;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --border-radius: 12px;
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 8px 30px rgba(0, 0, 0, 0.12);
            --transition: all 0.3s ease;
            --sidebar-width: 280px;
            --topbar-height: 80px;
        }

        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family:'Poppins',sans-serif;
            background:linear-gradient(135deg,#f5f7fb 0%,#eef2f7 100%);
            color:var(--dark);
            line-height:1.6;
            min-height:100vh;
            overflow-x:hidden;
        }
        body.dark-theme {
            --light:#1a1d23;
            --dark:#f8f9fa;
            --gray:#adb5bd;
            --light-gray:#2d3239;
            background:linear-gradient(135deg,#121416 0%,#1a1d23 100%);
            color:#f8f9fa;
        }

        .dashboard-container { display:flex; min-height:100vh; position:relative; }
        .sidebar {
            width:var(--sidebar-width);
            background:linear-gradient(180deg,var(--primary) 0%,var(--primary-dark) 100%);
            color:white;
            display:flex; flex-direction:column; position:fixed; height:100vh; z-index:1000;
            transition:var(--transition); box-shadow:3px 0 20px rgba(0,0,0,0.1); overflow-y:auto;
        }
        .dark-theme .sidebar { box-shadow:3px 0 20px rgba(0,0,0,0.3); }
        .sidebar-header { padding:25px; border-bottom:1px solid rgba(255,255,255,0.15); background:rgba(255,255,255,0.05); position:sticky; top:0; }
        .logo { display:flex; align-items:center; gap:15px; }
        .logo-icon { width:45px; height:45px; background:rgba(255,255,255,0.2); border-radius:10px; display:flex; align-items:center; justify-content:center; }
        .logo-text h2 { font-size:18px; font-weight:700; }
        .logo-text p { font-size:12px; opacity:0.9; }
        .sidebar-menu { flex:1; padding:25px 0; }
        .menu-section { margin-bottom:25px; padding:0 25px; }
        .menu-section h3 { font-size:11px; text-transform:uppercase; letter-spacing:1.5px; opacity:0.7; margin-bottom:15px; font-weight:600; }
        .menu-section ul { list-style:none; }
        .menu-section a { display:flex; align-items:center; gap:15px; padding:12px 15px; color:rgba(255,255,255,0.85); text-decoration:none; border-radius:8px; transition:var(--transition); font-size:14px; }
        .menu-section a:hover, .menu-section a.active { background:rgba(255,255,255,0.12); color:white; }
        .menu-section a.active { background:rgba(255,255,255,0.18); font-weight:600; }
        .menu-section a.active::before { content:''; position:absolute; left:0; top:50%; transform:translateY(-50%); width:4px; height:60%; background:var(--secondary); border-radius:0 4px 4px 0; }
        .menu-section a i { font-size:16px; width:20px; text-align:center; }
        .user-profile { padding:20px; border-top:1px solid rgba(255,255,255,0.15); display:flex; align-items:center; gap:15px; background:rgba(255,255,255,0.05); position:sticky; bottom:0; }
        .user-avatar { width:45px; height:45px; border-radius:50%; background:linear-gradient(135deg,var(--primary-light),var(--secondary)); display:flex; align-items:center; justify-content:center; position:relative; }
        .avatar-placeholder { font-size:16px; font-weight:700; color:white; }
        .online-status { position:absolute; bottom:3px; right:3px; width:12px; height:12px; background:var(--secondary); border-radius:50%; border:2px solid var(--primary-dark); }
        .user-info h4 { font-size:14px; font-weight:600; }
        .user-info p { font-size:12px; opacity:0.9; }
        .user-actions a { color:rgba(255,255,255,0.8); font-size:16px; padding:8px; border-radius:6px; }
        .user-actions a:hover { background:rgba(255,255,255,0.15); color:white; }

        .main-content { flex:1; margin-left:var(--sidebar-width); transition:var(--transition); min-height:100vh; display:flex; flex-direction:column; }
        @media (max-width:1199px) { .main-content { margin-left:0; } }

        .top-bar {
            background:white; padding:15px 25px; box-shadow:var(--shadow); display:flex;
            justify-content:space-between; align-items:center; position:sticky; top:0; z-index:900;
            gap:15px; backdrop-filter:blur(10px); background:rgba(255,255,255,0.95); flex-wrap:wrap; min-height:var(--topbar-height);
        }
        .dark-theme .top-bar { background:rgba(26,29,35,0.95); }
        .top-bar-left { display:flex; align-items:center; gap:15px; flex:1; min-width:0; }
        .sidebar-toggle { display:none; background:var(--primary); border:none; color:white; font-size:18px; cursor:pointer; padding:10px; border-radius:8px; width:40px; height:40px; align-items:center; justify-content:center; }
        .sidebar-toggle:hover { background:var(--primary-dark); }
        @media (max-width:1199px) { .sidebar-toggle { display:flex; } }
        .search-bar { flex:1; min-width:200px; max-width:500px; position:relative; }
        .search-bar i { position:absolute; left:15px; top:50%; transform:translateY(-50%); color:var(--gray); z-index:1; }
        .search-bar input { width:100%; padding:12px 15px 12px 40px; border:2px solid var(--light-gray); border-radius:var(--border-radius); font-size:14px; font-family:'Poppins',sans-serif; transition:var(--transition); background:white; color:var(--dark); }
        .dark-theme .search-bar input { background:var(--light); border-color:#3d4249; }
        .search-bar input:focus { outline:none; border-color:var(--primary); }
        .top-bar-right { display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
        .notification-btn, .message-btn { position:relative; background:var(--light); border:none; font-size:16px; color:var(--gray); cursor:pointer; padding:10px; border-radius:8px; width:40px; height:40px; }
        .dark-theme .notification-btn, .dark-theme .message-btn { background:#2d3239; }
        .notification-btn:hover, .message-btn:hover { background:var(--primary); color:white; transform:translateY(-2px); }
        .notification-badge { position:absolute; top:-5px; right:-5px; background:var(--danger); color:white; font-size:10px; width:18px; height:18px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:2px solid white; }
        .theme-toggle { background:var(--light); border:none; width:40px; height:40px; border-radius:50%; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:var(--transition); font-size:16px; color:var(--gray); }
        .dark-theme .theme-toggle { background:#2d3239; }
        .theme-toggle:hover { background:var(--primary); color:white; transform:rotate(30deg); }
        .quick-actions { display:flex; gap:8px; flex-wrap:wrap; }
        .quick-action-btn { width:40px; height:40px; border-radius:50%; background:linear-gradient(135deg,var(--primary),var(--primary-light)); color:white; display:flex; align-items:center; justify-content:center; transition:var(--transition); font-size:16px; text-decoration:none; }
        .quick-action-btn:hover { transform:translateY(-3px) scale(1.1); box-shadow:0 6px 20px rgba(111,66,193,0.4); }

        .dashboard-content { padding:25px; flex:1; overflow-y:auto; }
        .page-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:30px; flex-wrap:wrap; gap:15px; }
        .page-header h1 { font-size:24px; font-weight:700; color:var(--dark); display:flex; align-items:center; gap:10px; }
        .dark-theme .page-header h1 { color:#f8f9fa; }

        .btn-primary, .btn-secondary { padding:12px 20px; border:none; border-radius:var(--border-radius); font-size:14px; font-weight:600; cursor:pointer; display:inline-flex; align-items:center; gap:8px; transition:var(--transition); text-decoration:none; }
        .btn-primary { background:var(--primary); color:white; }
        .btn-primary:hover { background:var(--primary-dark); transform:translateY(-2px); box-shadow:0 4px 15px rgba(111,66,193,0.4); }
        .btn-secondary { background:var(--light-gray); color:var(--dark); }
        .btn-secondary:hover { background:var(--gray); color:white; }
        .dark-theme .btn-secondary { background:#2d3239; color:#f8f9fa; }
        .dark-theme .btn-secondary:hover { background:#3d4249; }

        .form-card {
            background:white; border-radius:var(--border-radius); padding:30px; box-shadow:var(--shadow);
            max-width:800px; margin:0 auto;
        }
        .dark-theme .form-card { background:#1a1d23; }
        .form-group { margin-bottom:20px; }
        .form-group label { display:block; margin-bottom:5px; font-weight:600; color:var(--dark); }
        .dark-theme .form-group label { color:#f8f9fa; }
        .form-group input, .form-group select, .form-group textarea {
            width:100%; padding:12px; border:2px solid var(--light-gray); border-radius:8px;
            font-family:'Poppins',sans-serif; transition:var(--transition);
            background:white; color:var(--dark);
        }
        .dark-theme .form-group input, .dark-theme .form-group select, .dark-theme .form-group textarea {
            background:#2d3239; border-color:#3d4249; color:#f8f9fa;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline:none; border-color:var(--primary);
        }
        .form-row { display:grid; grid-template-columns:1fr 1fr; gap:20px; }
        .form-actions { display:flex; gap:15px; justify-content:flex-end; margin-top:30px; }

        .alert {
            padding:15px; border-radius:8px; margin-bottom:20px; background:var(--danger); color:white;
            display:flex; align-items:center; gap:10px;
        }
        .alert i { font-size:20px; }
        .alert ul { margin-left:20px; }

        .small-note {
            font-size:12px; color:var(--gray); margin-top:5px;
        }
        .dark-theme .small-note { color:#adb5bd; }

        .readonly-field {
            background-color: var(--light-gray);
            cursor: not-allowed;
        }
        .dark-theme .readonly-field {
            background-color: #2d3239;
        }

        .main-footer {
            background:white; padding:15px 25px; border-top:1px solid var(--light-gray);
            text-align:center; font-size:13px; color:var(--gray);
        }
        .dark-theme .main-footer { background:#1a1d23; border-top-color:#2d3239; }
        .footer-content { display:flex; align-items:center; justify-content:center; gap:10px; }
        .footer-content a { color:var(--primary); text-decoration:none; }

        .sidebar-overlay { display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:999; }
        .preloader { position:fixed; top:0; left:0; width:100%; height:100%; background:white; display:flex; align-items:center; justify-content:center; z-index:9999; transition:opacity 0.5s; }
        .dark-theme .preloader { background:#1a1d23; }
        .loader { text-align:center; }
        .loader i { font-size:50px; color:var(--primary); margin-bottom:20px; animation:bounce 1.5s infinite; }
        @keyframes bounce { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-15px);} }
        @media (max-width:1199px) {
            .sidebar { transform:translateX(-100%); width:300px; }
            .sidebar.active { transform:translateX(0); }
            .sidebar-toggle { display:flex; }
            .sidebar-overlay.active { display:block; }
        }
        @media (max-width:992px) { .form-row { grid-template-columns:1fr; } }
        @media (max-width:768px) { .form-actions { flex-direction:column; } .btn-primary, .btn-secondary { width:100%; justify-content:center; } }
    </style>
</head>
<body>
    <div class="preloader" id="preloader"><div class="loader"><i class="fas fa-stethoscope"></i><div>Carregando...</div></div></div>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo"><div class="logo-icon"><i class="fas fa-stethoscope"></i></div><div class="logo-text"><h2>Alfa Saúde</h2><p>Gestão Clínica</p></div></div>
            </div>
            <div class="sidebar-menu">
                <div class="menu-section"><h3>Menu Principal</h3>
                    <ul>
                        <li><a href="../dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                        <li><a href="../agendamentos.php"><i class="fas fa-calendar-alt"></i> Agenda</a></li>
                        <li><a href="../pacientes.php"><i class="fas fa-user-injured"></i> Pacientes</a></li>
                        <li><a href="../usuarios.php"><i class="fas fa-user-md"></i> Usuários</a></li>
                    </ul>
                </div>
                <div class="menu-section"><h3>Atendimento</h3>
                    <ul>
                        <li><a href="../prontuarios.php"><i class="fas fa-notes-medical"></i> Prontuários</a></li>
                        <li><a href="../receituarios.php"><i class="fas fa-prescription"></i> Receituários</a></li>
                        <li><a href="../declaracoes.php" class="active"><i class="fas fa-file-medical"></i> Declarações</a></li>
                    </ul>
                </div>
                <div class="menu-section"><h3>Administração</h3>
                    <ul>
                        <li><a href="../clinica.php"><i class="fas fa-hospital"></i> Clínica</a></li>
                        <li><a href="../relatorios.php"><i class="fas fa-chart-line"></i> Relatórios</a></li>
                    </ul>
                </div>
            </div>
            <div class="user-profile">
                <div class="user-avatar"><div class="avatar-placeholder"><?php echo $usuario_logado_iniciais; ?></div><div class="online-status"></div></div>
                <div class="user-info"><h4><?php echo htmlspecialchars($usuario_logado_nome); ?></h4><p><?php echo ucfirst($usuario_logado_tipo); ?></p></div>
                <div class="user-actions"><a href="../logout.php" title="Sair"><i class="fas fa-sign-out-alt"></i></a></div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <header class="top-bar">
                <div class="top-bar-left">
                    <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <div class="search-bar"><i class="fas fa-search"></i><input type="text" placeholder="Pesquisar..."></div>
                </div>
                <div class="top-bar-right">
                    <button class="notification-btn"><i class="fas fa-bell"></i><span class="notification-badge">0</span></button>
                    <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
                    <div class="quick-actions">
                        <a href="novo.php" class="quick-action-btn" title="Nova Declaração"><i class="fas fa-file-medical"></i></a>
                    </div>
                </div>
            </header>

            <!-- Conteúdo -->
            <div class="dashboard-content">
                <div class="page-header">
                    <h1><i class="fas fa-edit" style="color:var(--primary);"></i> Editar Declaração #<?php echo $id; ?></h1>
                    <a href="../declaracoes.php" class="btn-secondary"><i class="fas fa-arrow-left"></i> Voltar</a>
                </div>

                <?php if (!empty($erros)): ?>
                    <div class="alert"><i class="fas fa-exclamation-circle"></i><ul><?php foreach ($erros as $erro): ?><li><?php echo htmlspecialchars($erro); ?></li><?php endforeach; ?></ul></div>
                <?php endif; ?>

                <form method="POST" class="form-card">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Paciente *</label>
                            <select name="paciente_id" required>
                                <option value="">Selecione um paciente</option>
                                <?php foreach ($pacientes as $p): ?>
                                    <option value="<?php echo $p['id']; ?>" <?php echo ($_POST['paciente_id'] == $p['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($p['nome']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Tipo *</label>
                            <select name="tipo" required>
                                <?php foreach ($tipos as $valor => $rotulo): ?>
                                    <option value="<?php echo $valor; ?>" <?php echo ($_POST['tipo'] == $valor) ? 'selected' : ''; ?>>
                                        <?php echo $rotulo; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Médico Responsável</label>
                        <?php
                        // Buscar nome do médico atual (não editável)
                        $stmt_med = $pdo->prepare("SELECT nome FROM usuarios WHERE id = ?");
                        $stmt_med->execute([$declaracao['usuario_id']]);
                        $med_nome = $stmt_med->fetchColumn();
                        ?>
                        <input type="text" class="readonly-field" value="<?php echo htmlspecialchars($med_nome); ?>" readonly disabled>
                        <input type="hidden" name="medico_id" value="<?php echo $declaracao['usuario_id']; ?>">
                    </div>

                    <div class="form-group">
                        <label>Conteúdo da Declaração *</label>
                        <textarea name="conteudo" rows="10" required><?php echo htmlspecialchars($_POST['conteudo']); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label>Código de Verificação (não alterável)</label>
                        <input type="text" class="readonly-field" value="<?php echo htmlspecialchars($declaracao['codigo_verificacao']); ?>" readonly disabled>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn-primary"><i class="fas fa-save"></i> Salvar</button>
                        <a href="../declaracoes.php" class="btn-secondary"><i class="fas fa-times"></i> Cancelar</a>
                    </div>
                </form>
            </div>

            <!-- Footer -->
            <footer class="main-footer">
                <div class="footer-content"><p>desenvolvido por <a href="https://alfasistemas.dev.br" target="_blank">alfa sistemas s.a</a> (85) 2028-4584</p></div>
            </footer>
        </main>
    </div>

    <script>
        window.addEventListener('load', function() { setTimeout(() => { document.getElementById('preloader').style.opacity = '0'; setTimeout(() => document.getElementById('preloader').style.display = 'none', 500); }, 800); });
        const sidebarToggle = document.getElementById('sidebarToggle'), sidebar = document.getElementById('sidebar'), overlay = document.getElementById('sidebarOverlay');
        if (sidebarToggle) { sidebarToggle.addEventListener('click', () => { sidebar.classList.toggle('active'); overlay.classList.toggle('active'); }); overlay.addEventListener('click', () => { sidebar.classList.remove('active'); overlay.classList.remove('active'); }); }
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => { document.body.classList.toggle('dark-theme'); const icon = themeToggle.querySelector('i'); if (document.body.classList.contains('dark-theme')) { icon.className = 'fas fa-sun'; localStorage.setItem('theme', 'dark'); } else { icon.className = 'fas fa-moon'; localStorage.setItem('theme', 'light'); } });
            if (localStorage.getItem('theme') === 'dark') { document.body.classList.add('dark-theme'); themeToggle.querySelector('i').className = 'fas fa-sun'; }
        }
    </script>
</body>
</html>