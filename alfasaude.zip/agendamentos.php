<?php
// Ativar exibição de erros (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config/database.php';
require_once 'config/auth.php';
verificarLogin();

// ============================================
// FUNÇÕES AUXILIARES (caso não estejam no database.php)
// ============================================
if (!function_exists('getClinica')) {
    function getClinica() {
        global $pdo;
        $stmt = $pdo->query("SELECT * FROM clinica LIMIT 1");
        return $stmt->fetch();
    }
}

if (!function_exists('getCoresTema')) {
    function getCoresTema() {
        global $pdo;
        try {
            $stmt = $pdo->query("SELECT cor_primaria, cor_secundaria FROM clinica LIMIT 1");
            $cores = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($cores) {
                return [
                    'primaria' => $cores['cor_primaria'],
                    'secundaria' => $cores['cor_secundaria']
                ];
            }
        } catch (Exception $e) {}
        return ['primaria' => '#6f42c1', 'secundaria' => '#20c997'];
    }
}

$clinica = getClinica();
$cores = getCoresTema();

// ============================================
// PROCESSAMENTO DE FILTROS
// ============================================
$filtro_data = $_GET['data'] ?? date('Y-m-d');
$filtro_paciente = $_GET['paciente_id'] ?? '';
$filtro_medico = $_GET['usuario_id'] ?? '';
$filtro_status = $_GET['status'] ?? '';

$where = [];
$params = [];

if (!empty($filtro_data)) {
    $where[] = "DATE(a.data_hora) = :data";
    $params[':data'] = $filtro_data;
}
if (!empty($filtro_paciente)) {
    $where[] = "a.paciente_id = :paciente";
    $params[':paciente'] = $filtro_paciente;
}
if (!empty($filtro_medico)) {
    $where[] = "a.usuario_id = :medico";
    $params[':medico'] = $filtro_medico;
}
if (!empty($filtro_status)) {
    $where[] = "a.status = :status";
    $params[':status'] = $filtro_status;
}

$sql = "SELECT a.*, p.nome as paciente_nome, p.telefone, u.nome as medico_nome
        FROM agendamentos a
        JOIN pacientes p ON a.paciente_id = p.id
        JOIN usuarios u ON a.usuario_id = u.id";
if (!empty($where)) {
    $sql .= " WHERE " . implode(" AND ", $where);
}
$sql .= " ORDER BY a.data_hora DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$agendamentos = $stmt->fetchAll();

// ============================================
// DADOS PARA FILTROS (listas)
// ============================================
$pacientes = $pdo->query("SELECT id, nome FROM pacientes WHERE ativo = 1 ORDER BY nome")->fetchAll();
$medicos = $pdo->query("SELECT id, nome FROM usuarios WHERE ativo = 1 ORDER BY nome")->fetchAll();

// Status disponíveis
$status_list = ['agendado', 'confirmado', 'em_andamento', 'concluido', 'cancelado'];

// ============================================
// DADOS DO USUÁRIO LOGADO
// ============================================
$usuario_nome = $_SESSION['usuario_nome'] ?? 'Usuário';
$usuario_tipo = $_SESSION['usuario_tipo'] ?? 'usuario';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamentos | <?php echo htmlspecialchars($clinica['nome'] ?? 'Alfa Saúde'); ?></title>
    <!-- Font Awesome, Google Fonts, Chart.js (opcional) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ===== VARIÁVEIS GLOBAIS ===== */
        :root {
            --primary: <?php echo $cores['primaria']; ?>;
            --primary-light: <?php echo $cores['primaria']; ?>dd;
            --primary-dark: <?php echo $cores['primaria']; ?>aa;
            --secondary: <?php echo $cores['secundaria']; ?>;
            --secondary-light: <?php echo $cores['secundaria']; ?>dd;
            --danger: #ff4757;
            --warning: #ff9f43;
            --info: #2e86de;
            --light: #f8f9fa;
            --dark: #343a40;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --border-radius: 12px;
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 8px 30px rgba(0, 0, 0, 0.12);
            --transition: all 0.3s ease;
            --sidebar-width: 280px;
            --topbar-height: 80px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fb 0%, #eef2f7 100%);
            color: var(--dark);
            line-height: 1.6;
            min-height: 100vh;
            overflow-x: hidden;
        }

        body.dark-theme {
            --light: #1a1d23;
            --dark: #f8f9fa;
            --gray: #adb5bd;
            --light-gray: #2d3239;
            background: linear-gradient(135deg, #121416 0%, #1a1d23 100%);
            color: #f8f9fa;
        }

        /* ===== LAYOUT PRINCIPAL ===== */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
            position: relative;
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            z-index: 1000;
            transition: var(--transition);
            box-shadow: 3px 0 20px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
        }

        .dark-theme .sidebar {
            box-shadow: 3px 0 20px rgba(0, 0, 0, 0.3);
        }

        .sidebar-header {
            padding: 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.15);
            background: rgba(255, 255, 255, 0.05);
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-icon {
            width: 45px;
            height: 45px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            flex-shrink: 0;
        }

        .logo-icon i {
            font-size: 22px;
        }

        .logo-text h2 {
            font-size: 18px;
            font-weight: 700;
            margin: 0;
            letter-spacing: 0.5px;
            line-height: 1.2;
        }

        .logo-text p {
            font-size: 12px;
            opacity: 0.9;
            margin: 3px 0 0 0;
            font-weight: 300;
        }

        .sidebar-menu {
            flex: 1;
            padding: 25px 0;
            overflow-y: auto;
        }

        .menu-section {
            margin-bottom: 25px;
            padding: 0 25px;
        }

        .menu-section h3 {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            opacity: 0.7;
            margin-bottom: 15px;
            font-weight: 600;
        }

        .menu-section ul {
            list-style: none;
        }

        .menu-section li {
            margin-bottom: 5px;
        }

        .menu-section a {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 15px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            border-radius: 8px;
            transition: var(--transition);
            position: relative;
            font-weight: 500;
            font-size: 14px;
        }

        .menu-section a:hover,
        .menu-section a.active {
            background: rgba(255, 255, 255, 0.12);
            color: white;
        }

        .menu-section a.active {
            background: rgba(255, 255, 255, 0.18);
            font-weight: 600;
        }

        .menu-section a.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 4px;
            height: 60%;
            background: var(--secondary);
            border-radius: 0 4px 4px 0;
        }

        .menu-section a i {
            font-size: 16px;
            width: 20px;
            text-align: center;
        }

        .menu-badge {
            margin-left: auto;
            background: var(--secondary);
            color: white;
            font-size: 11px;
            padding: 3px 8px;
            border-radius: 10px;
            font-weight: 600;
            min-width: 20px;
            text-align: center;
        }

        .menu-badge.new {
            background: var(--danger);
        }

        .menu-badge.alert {
            background: var(--warning);
        }

        .user-profile {
            padding: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.15);
            display: flex;
            align-items: center;
            gap: 15px;
            background: rgba(255, 255, 255, 0.05);
            position: sticky;
            bottom: 0;
        }

        .user-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            overflow: hidden;
            background: linear-gradient(135deg, var(--primary-light), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            flex-shrink: 0;
        }

        .avatar-placeholder {
            font-size: 16px;
            font-weight: 700;
            color: white;
        }

        .online-status {
            position: absolute;
            bottom: 3px;
            right: 3px;
            width: 12px;
            height: 12px;
            background: var(--secondary);
            border-radius: 50%;
            border: 2px solid var(--primary-dark);
        }

        .user-info {
            flex: 1;
            min-width: 0;
        }

        .user-info h4 {
            font-size: 14px;
            font-weight: 600;
            margin: 0 0 4px 0;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .user-info p {
            font-size: 12px;
            opacity: 0.9;
            margin: 0;
            font-weight: 400;
        }

        .user-actions a {
            color: rgba(255, 255, 255, 0.8);
            font-size: 16px;
            transition: var(--transition);
            padding: 8px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .user-actions a:hover {
            background: rgba(255, 255, 255, 0.15);
            color: white;
        }

        /* ===== CONTEÚDO PRINCIPAL ===== */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            transition: var(--transition);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        @media (max-width: 1199px) {
            .main-content {
                margin-left: 0;
            }
        }

        /* ===== TOP BAR ===== */
        .top-bar {
            background: white;
            padding: 15px 25px;
            box-shadow: var(--shadow);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 900;
            gap: 15px;
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95);
            flex-wrap: wrap;
            min-height: var(--topbar-height);
        }

        .dark-theme .top-bar {
            background: rgba(26, 29, 35, 0.95);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        }

        .top-bar-left {
            display: flex;
            align-items: center;
            gap: 15px;
            flex: 1;
            min-width: 0;
        }

        .sidebar-toggle {
            display: none;
            background: var(--primary);
            border: none;
            color: white;
            font-size: 18px;
            cursor: pointer;
            padding: 10px;
            border-radius: 8px;
            transition: var(--transition);
            flex-shrink: 0;
            width: 40px;
            height: 40px;
            align-items: center;
            justify-content: center;
        }

        .sidebar-toggle:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }

        .search-bar {
            flex: 1;
            min-width: 200px;
            max-width: 500px;
            position: relative;
        }

        .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            font-size: 14px;
            z-index: 1;
        }

        .search-bar input {
            width: 100%;
            padding: 12px 15px 12px 40px;
            border: 2px solid var(--light-gray);
            border-radius: var(--border-radius);
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            transition: var(--transition);
            background: white;
            color: var(--dark);
        }

        .dark-theme .search-bar input {
            background: var(--light);
            border-color: #3d4249;
            color: var(--dark);
        }

        .search-bar input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(111, 66, 193, 0.15);
        }

        .top-bar-right {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .notification-btn,
        .message-btn {
            position: relative;
            background: var(--light);
            border: none;
            font-size: 16px;
            color: var(--gray);
            cursor: pointer;
            padding: 10px;
            border-radius: 8px;
            transition: var(--transition);
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .dark-theme .notification-btn,
        .dark-theme .message-btn {
            background: #2d3239;
        }

        .notification-btn:hover,
        .message-btn:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-2px);
        }

        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            font-size: 10px;
            font-weight: 700;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid white;
        }

        .dark-theme .notification-badge {
            border-color: #1a1d23;
        }

        .theme-toggle {
            background: var(--light);
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
            font-size: 16px;
            color: var(--gray);
        }

        .dark-theme .theme-toggle {
            background: #2d3239;
        }

        .theme-toggle:hover {
            background: var(--primary);
            color: white;
            transform: rotate(30deg);
        }

        .quick-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .quick-action-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: none;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
            font-size: 16px;
            text-decoration: none;
        }

        .quick-action-btn:hover {
            transform: translateY(-3px) scale(1.1);
            box-shadow: 0 6px 20px rgba(111, 66, 193, 0.4);
        }

        /* ===== CONTEÚDO DO DASHBOARD ===== */
        .dashboard-content {
            padding: 25px;
            flex: 1;
            overflow-y: auto;
        }

        /* ===== CABEÇALHO DA PÁGINA ===== */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .page-header h1 {
            font-size: 24px;
            font-weight: 700;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .page-header h1 i {
            color: var(--primary);
        }

        .btn-primary {
            background: var(--primary);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
            text-decoration: none;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .btn-secondary {
            background: var(--light-gray);
            color: var(--dark);
            border: none;
            padding: 10px 15px;
            border-radius: var(--border-radius);
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: var(--transition);
            text-decoration: none;
        }

        .btn-secondary:hover {
            background: var(--gray);
            color: white;
        }

        .btn-icon {
            background: transparent;
            border: none;
            color: var(--gray);
            font-size: 16px;
            cursor: pointer;
            padding: 5px;
            border-radius: 4px;
            transition: var(--transition);
            text-decoration: none;
            display: inline-flex;
        }

        .btn-icon:hover {
            color: var(--primary);
            background: rgba(111, 66, 193, 0.1);
        }

        .btn-icon.btn-delete:hover {
            color: var(--danger);
            background: rgba(255, 71, 87, 0.1);
        }

        /* ===== FILTROS ===== */
        .filters-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 20px;
            margin-bottom: 25px;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }

        .dark-theme .filters-card {
            background: #1a1d23;
            border-color: #2d3239;
        }

        .filters-form {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: flex-end;
        }

        .form-group {
            flex: 1 1 200px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-size: 12px;
            font-weight: 600;
            color: var(--gray);
            text-transform: uppercase;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px 12px;
            border: 2px solid var(--light-gray);
            border-radius: 8px;
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            transition: var(--transition);
            background: white;
            color: var(--dark);
        }

        .dark-theme .form-group input,
        .dark-theme .form-group select {
            background: #2d3239;
            border-color: #3d4249;
            color: #f8f9fa;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--primary);
        }

        .btn-filter {
            background: var(--primary);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
            height: 42px;
        }

        .btn-filter:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }

        .btn-clear {
            background: var(--light-gray);
            color: var(--dark);
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
            text-decoration: none;
            height: 42px;
        }

        .dark-theme .btn-clear {
            background: #2d3239;
            color: #f8f9fa;
        }

        .btn-clear:hover {
            background: var(--gray);
            color: white;
        }

        /* ===== TABELA ===== */
        .table-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }

        .dark-theme .table-card {
            background: #1a1d23;
            border-color: #2d3239;
        }

        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .data-table {
            width: 100%;
            min-width: 800px;
            border-collapse: collapse;
        }

        .data-table th {
            padding: 15px 20px;
            text-align: left;
            font-weight: 600;
            color: var(--gray);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-bottom: 2px solid var(--light-gray);
            white-space: nowrap;
            background: #f8f9fa;
        }

        .dark-theme .data-table th {
            background: #2d3239;
            border-bottom-color: #3d4249;
        }

        .data-table td {
            padding: 15px 20px;
            border-bottom: 1px solid var(--light-gray);
            color: var(--dark);
            font-size: 13px;
            vertical-align: middle;
        }

        .dark-theme .data-table td {
            color: #f8f9fa;
            border-bottom-color: #2d3239;
        }

        .data-table tbody tr:hover {
            background: rgba(111, 66, 193, 0.02);
        }

        .dark-theme .data-table tbody tr:hover {
            background: rgba(111, 66, 193, 0.05);
        }

        .patient-cell {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .patient-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 14px;
            flex-shrink: 0;
        }

        .patient-info {
            min-width: 0;
        }

        .patient-info strong {
            font-weight: 600;
            font-size: 14px;
            display: block;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .patient-info small {
            font-size: 12px;
            color: var(--gray);
        }

        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }

        .status-agendado {
            background: rgba(255, 159, 67, 0.15);
            color: var(--warning);
        }

        .status-confirmado {
            background: rgba(46, 134, 222, 0.15);
            color: var(--info);
        }

        .status-em_andamento {
            background: rgba(32, 201, 151, 0.15);
            color: var(--secondary);
        }

        .status-concluido {
            background: rgba(32, 201, 151, 0.15);
            color: var(--secondary);
        }

        .status-cancelado {
            background: rgba(255, 71, 87, 0.15);
            color: var(--danger);
        }

        .actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 50px;
            margin-bottom: 15px;
            opacity: 0.3;
        }

        .empty-state h4 {
            font-size: 16px;
            margin-bottom: 10px;
            color: var(--dark);
        }

        .dark-theme .empty-state h4 {
            color: #f8f9fa;
        }

        /* ===== RODAPÉ ===== */
        .main-footer {
            background: white;
            padding: 15px 25px;
            border-top: 1px solid var(--light-gray);
            text-align: center;
            font-size: 13px;
            color: var(--gray);
        }

        .dark-theme .main-footer {
            background: #1a1d23;
            border-top-color: #2d3239;
        }

        .footer-content {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .footer-content a {
            color: var(--primary);
            text-decoration: none;
        }

        /* ===== OVERLAY DO SIDEBAR ===== */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
            backdrop-filter: blur(3px);
        }

        /* ===== RESPONSIVIDADE ===== */
        @media (max-width: 1199px) {
            .sidebar {
                transform: translateX(-100%);
                width: 300px;
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .sidebar-toggle {
                display: flex;
            }
            .sidebar-overlay.active {
                display: block;
            }
        }

        @media (max-width: 768px) {
            .dashboard-content {
                padding: 15px;
            }
            .page-header h1 {
                font-size: 20px;
            }
            .filters-form {
                flex-direction: column;
                align-items: stretch;
            }
            .form-group {
                width: 100%;
            }
            .btn-filter, .btn-clear {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="fas fa-stethoscope"></i>
                    </div>
                    <div class="logo-text">
                        <h2><?php echo htmlspecialchars($clinica['nome'] ?? 'Alfa Saúde'); ?></h2>
                        <p>Gestão Clínica</p>
                    </div>
                </div>
            </div>

            <div class="sidebar-menu">
                <div class="menu-section">
                    <h3>Menu Principal</h3>
                    <ul>
                        <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                        <li><a href="agendamentos.php" class="active"><i class="fas fa-calendar-alt"></i> Agenda</a></li>
                        <li><a href="pacientes.php"><i class="fas fa-user-injured"></i> Pacientes</a></li>
                        <li><a href="usuarios.php"><i class="fas fa-user-md"></i> Usuários</a></li>
                    </ul>
                </div>
                <div class="menu-section">
                    <h3>Atendimento</h3>
                    <ul>
                        <li><a href="prontuarios.php"><i class="fas fa-notes-medical"></i> Prontuários</a></li>
                        <li><a href="receituarios.php"><i class="fas fa-prescription"></i> Receituários</a></li>
                        <li><a href="declaracoes.php"><i class="fas fa-file-medical"></i> Declarações</a></li>
                    </ul>
                </div>
                <?php if ($usuario_tipo === 'admin'): ?>
                <div class="menu-section">
                    <h3>Administração</h3>
                    <ul>
                        <li><a href="clinica.php"><i class="fas fa-hospital"></i> Clínica</a></li>
                        <li><a href="relatorios.php"><i class="fas fa-chart-line"></i> Relatórios</a></li>
                    </ul>
                </div>
                <?php endif; ?>
            </div>

            <div class="user-profile">
                <div class="user-avatar">
                    <div class="avatar-placeholder"><?php echo strtoupper(substr($usuario_nome, 0, 2)); ?></div>
                    <div class="online-status"></div>
                </div>
                <div class="user-info">
                    <h4><?php echo htmlspecialchars($usuario_nome); ?></h4>
                    <p><?php echo ucfirst($usuario_tipo); ?></p>
                </div>
                <div class="user-actions">
                    <a href="logout.php" title="Sair"><i class="fas fa-sign-out-alt"></i></a>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <header class="top-bar">
                <div class="top-bar-left">
                    <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <div class="search-bar">
                        <i class="fas fa-search"></i>
                        <input type="text" id="searchInput" placeholder="Pesquisar agendamentos...">
                    </div>
                </div>
                <div class="top-bar-right">
                    <button class="notification-btn"><i class="fas fa-bell"></i><span class="notification-badge"><?php echo count($agendamentos); ?></span></button>
                    <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
                    <div class="quick-actions">
                        <a href="pacientes/novo.php" class="quick-action-btn" title="Novo Paciente"><i class="fas fa-user-plus"></i></a>
                        <a href="agendamentos/novo.php" class="quick-action-btn" title="Novo Agendamento"><i class="fas fa-calendar-plus"></i></a>
                    </div>
                </div>
            </header>

            <!-- Dashboard Content -->
            <div class="dashboard-content">
                <div class="page-header">
                    <h1><i class="fas fa-calendar-alt"></i> Agendamentos</h1>
                    <a href="agendamentos/novo.php" class="btn-primary"><i class="fas fa-plus"></i> Novo Agendamento</a>
                </div>

                <!-- Filtros -->
                <div class="filters-card">
                    <form method="GET" class="filters-form">
                        <div class="form-group">
                            <label>Data</label>
                            <input type="date" name="data" value="<?php echo htmlspecialchars($filtro_data); ?>">
                        </div>
                        <div class="form-group">
                            <label>Paciente</label>
                            <select name="paciente_id">
                                <option value="">Todos</option>
                                <?php foreach ($pacientes as $p): ?>
                                    <option value="<?php echo $p['id']; ?>" <?php echo $filtro_paciente == $p['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($p['nome']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Médico</label>
                            <select name="usuario_id">
                                <option value="">Todos</option>
                                <?php foreach ($medicos as $m): ?>
                                    <option value="<?php echo $m['id']; ?>" <?php echo $filtro_medico == $m['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($m['nome']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <select name="status">
                                <option value="">Todos</option>
                                <?php foreach ($status_list as $s): ?>
                                    <option value="<?php echo $s; ?>" <?php echo $filtro_status == $s ? 'selected' : ''; ?>>
                                        <?php echo ucfirst($s); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" class="btn-filter"><i class="fas fa-filter"></i> Filtrar</button>
                        <a href="agendamentos.php" class="btn-clear"><i class="fas fa-times"></i> Limpar</a>
                    </form>
                </div>

                <!-- Tabela de Agendamentos -->
                <div class="table-card">
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Paciente</th>
                                    <th>Médico</th>
                                    <th>Data/Hora</th>
                                    <th>Tipo</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($agendamentos) > 0): ?>
                                    <?php foreach ($agendamentos as $a): ?>
                                    <tr>
                                        <td>
                                            <div class="patient-cell">
                                                <div class="patient-avatar"><?php echo strtoupper(substr($a['paciente_nome'],0,2)); ?></div>
                                                <div class="patient-info">
                                                    <strong><?php echo htmlspecialchars($a['paciente_nome']); ?></strong>
                                                    <?php if (!empty($a['telefone'])): ?>
                                                        <small><?php echo htmlspecialchars($a['telefone']); ?></small>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?php echo htmlspecialchars($a['medico_nome']); ?></td>
                                        <td><?php echo date('d/m/Y H:i', strtotime($a['data_hora'])); ?></td>
                                        <td><?php echo ucfirst($a['tipo_consulta']); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo $a['status']; ?>">
                                                <?php echo ucfirst($a['status']); ?>
                                            </span>
                                        </td>
                                        <td class="actions">
                                            <a href="agendamentos/visualizar.php?id=<?php echo $a['id']; ?>" class="btn-icon" title="Visualizar"><i class="fas fa-eye"></i></a>
                                            <?php if ($usuario_tipo === 'admin' || $usuario_tipo === 'medico'): ?>
                                                <a href="agendamentos/editar.php?id=<?php echo $a['id']; ?>" class="btn-icon" title="Editar"><i class="fas fa-edit"></i></a>
                                                <?php if ($a['status'] !== 'cancelado' && $a['status'] !== 'concluido'): ?>
                                                    <a href="agendamentos/cancelar.php?id=<?php echo $a['id']; ?>" class="btn-icon btn-delete" onclick="return confirm('Cancelar este agendamento?')" title="Cancelar"><i class="fas fa-times"></i></a>
                                                <?php endif; ?>
                                                <?php if ($a['status'] === 'agendado'): ?>
                                                    <a href="agendamentos/confirmar.php?id=<?php echo $a['id']; ?>" class="btn-icon" title="Confirmar"><i class="fas fa-check"></i></a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6">
                                            <div class="empty-state">
                                                <i class="fas fa-calendar-times"></i>
                                                <h4>Nenhum agendamento encontrado</h4>
                                                <p>Tente ajustar os filtros ou criar um novo agendamento.</p>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <footer class="main-footer">
                <div class="footer-content">
                    <p>desenvolvido por <a href="https://alfasistemas.dev.br" target="_blank">alfa sistemas s.a</a> (85) 2028-4584</p>
                    <?php if (!empty($clinica['logo'])): ?>
                        <img src="assets/img/<?php echo $clinica['logo']; ?>" alt="Logo" height="30">
                    <?php endif; ?>
                </div>
            </footer>
        </main>
    </div>

    <script>
        // Sidebar toggle
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('active');
                overlay.classList.toggle('active');
            });
            overlay.addEventListener('click', () => {
                sidebar.classList.remove('active');
                overlay.classList.remove('active');
            });
        }

        // Theme toggle
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark-theme');
                const icon = themeToggle.querySelector('i');
                if (document.body.classList.contains('dark-theme')) {
                    icon.className = 'fas fa-sun';
                    localStorage.setItem('theme', 'dark');
                } else {
                    icon.className = 'fas fa-moon';
                    localStorage.setItem('theme', 'light');
                }
            });
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-theme');
                themeToggle.querySelector('i').className = 'fas fa-sun';
            }
        }

        // Busca rápida (filtro na tabela pelo input de pesquisa)
        document.getElementById('searchInput')?.addEventListener('keyup', function() {
            const term = this.value.toLowerCase();
            const rows = document.querySelectorAll('.data-table tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(term) ? '' : 'none';
            });
        });
    </script>
</body>
</html>